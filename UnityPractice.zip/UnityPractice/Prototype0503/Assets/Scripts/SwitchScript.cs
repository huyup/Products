﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
/// <summary>
/// これはトラップスイッチをコントロールするクラスです。
/// </summary>
public class SwitchScript : MonoBehaviour
{
    // Use this for initialization
    GameObject stone;

    public bool fallenDownFlag = false;

    void Start()
    {
        if (SceneManager.GetActiveScene().name == "Stage2"||
            SceneManager.GetActiveScene().name == "Stage1")
            stone = GameObject.Find("Stone");
        
    }

    // Update is called once per frame
    void Update()
    {
    }


    private void OnCollisionEnter(Collision collision)
    {
        #region Stage1
        if (SceneManager.GetActiveScene().name == "Stage1")
        {
            if (collision.gameObject.name == "Player")
            {

                //プレイヤーがスイッチを踏んだら、岩を落下させ、スイッチの色を赤に変える。
                if (this.GetComponent<Renderer>().material.color.r < 20)
                {
                    GetComponent<Renderer>().material.color += new Color(1, 0, 0);
                    stone.GetComponent<Rigidbody>().isKinematic = false;
                    stone.GetComponent<Rigidbody>().AddForce(0, -3, 0);
                }


            }
        }
        #endregion

        #region Stage2||Stage3
        if (SceneManager.GetActiveScene().name == "Stage2"||
            SceneManager.GetActiveScene().name == "Stage3")
        {
            if (collision.gameObject.name == "Player")
            {
                fallenDownFlag = true;
            }
            if (collision.gameObject.name == "Ghost")
            {
                fallenDownFlag = true;
            }
        }
        #endregion
    }
    private void OnCollisionStay(Collision collision)
    {
        if (SceneManager.GetActiveScene().name == "Stage2" ||
            SceneManager.GetActiveScene().name == "Stage3")
        {
            if (collision.gameObject.name == "Player")
            {
                fallenDownFlag = true;
            }

            if (collision.gameObject.name == "Ghost")
            {
                fallenDownFlag = true;
            }
        }
    }
    private void OnCollisionExit(Collision collision)
    {
        if (SceneManager.GetActiveScene().name == "Stage2" ||
            SceneManager.GetActiveScene().name == "Stage3")
        {
            if (collision.gameObject.name == "Player")
            {
                fallenDownFlag = false;
            }

            if (collision.gameObject.name == "Ghost")
            {
                fallenDownFlag = false;
            }
        }
    }
}
