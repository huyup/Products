﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
/// <summary>
/// これはReplay機能のクラスです
/// </summary>

public class Data
{
    public bool m_Jump;
    public float h;
    public bool crouch;
    public float time;
}
enum PlayerState
{
    Move,
    Idle,
}
public class ReplayScript : MonoBehaviour
{
    #region フィールド
    /// <summary>
    /// 時間
    /// </summary>
    //これは現在の時間を記録するカウンターです
    //シーンが再ロードされても、0からスタートする
    float now_timeCount;

//ねっぽ　ここから
    /// <summary>
    /// 今のステージナンバー
    /// </summary>
    public string nowStageNum;

    public float p_NowTimeCount
    {
        get { return now_timeCount; }
    }
//ねっぽ　ここまで

    /// <summary>
    /// プレイヤー情報を一時保存するList動的配列
    /// </summary>
    private List<Data> dataList = new List<Data>();

    //立ち留まる時間
    private float idle_Time;
    private PlayerState player_NowState;

    /// <summary>
    ///プレイヤーオブジェ
    /// </summary>
    GameObject player;
    GameObject player_body;

    /// <summary>
    /// ゴーストオブジェ
    /// </summary>
    GameObject ghost;
    bool ghostExist_Flag;

    /// <summary>
    /// ゴーストが消えるエフェクト
    /// </summary>
    GameObject Eff_Disapear;
    ParticleSystem ParSys_Disapear;
    bool eff_Playable;

    /// <summary>
    /// REPLAY機能
    /// </summary>
    bool doReplay;
    //REPLAYするときに、一回だけ値をセットするフラグ
    bool setReplayValue;

    bool deadForZeroLife;
    Vector3 death_Pos;

    #region プレイヤーの情報を再保存＆＆取り出す配列
    //プレイヤー情報を保存する配列
    public const int MAXTIME = 5000;

    int arrayCount;
    //h
    float[] hs = new float[MAXTIME];
    //m_jump
    bool[] jumps = new bool[MAXTIME];
    //crouch
    bool[] crouchs = new bool[MAXTIME];
    //Time
    float[] times = new float[MAXTIME];

    //h
    float[] new_hs = new float[MAXTIME];
    //m_jump
    bool[] new_jumps = new bool[MAXTIME];
    //crouch
    bool[] new_crouchs = new bool[MAXTIME];
    //Time
    float[] new_times = new float[MAXTIME];
    #endregion
    
    #endregion

    #region 初期化
    void Start()
    {
        /*if (Time.timeSinceLevelLoad < 0)
        {
            PlayerPrefs.DeleteAll();
        }*/
        InitializeObj();
        InitializeFlag();
        InitializeTime();
        InitializeOtherValue();
        
        InitializePlayerDataArray();
    }

    #region 初期化関数
    void InitializeObj()
    {
        Eff_Disapear = GameObject.Find("Disapear");
        player = GameObject.Find("Player");
        ghost = GameObject.Find("Ghost");

        ParSys_Disapear = Eff_Disapear.GetComponent<ParticleSystem>();
    }
    void InitializeFlag()
    {
        ghostExist_Flag = false;
        deadForZeroLife = false;
        setReplayValue = true;
        doReplay = false;
        eff_Playable = true;
        deadForZeroLife = PlayerPrefsX.GetBool("deadForZeroLife");
    }
    void InitializeTime()
    {
        now_timeCount = 0;
        idle_Time = 0;
    }
    void InitializeOtherValue()
    {
        //nowStageNum = "1";
        Time.fixedDeltaTime = 0.016f;
        death_Pos = PlayerPrefsX.GetVector3("DeathPos");
        ghost.SetActive(false);
    }
    void InitializePlayerDataArray()
    {
        for (int i = 0; i < MAXTIME; i++)
        {
            hs[i] = new float();
            jumps[i] = new bool();
            crouchs[i] = new bool();
            times[i] = new float();

            new_hs[i] = new float();
            new_jumps[i] = new bool();
            new_crouchs[i] = new bool();
            new_times[i] = new float();
        }
    }
    #endregion

    public void ResetPlayerPrafs()
    {
        for(int i=0;i<MAXTIME;i++)
        {
            hs[i] = 0;
            times[i] = 0;
            jumps[i] = false;
            crouchs[i] = false;
        }
        //移動情報をplayerPrefsXに保存
        PlayerPrefsX.SetFloatArray("Hs", hs);
        PlayerPrefsX.SetFloatArray("Times", times);
        PlayerPrefsX.SetBoolArray("jumps", jumps);
        PlayerPrefsX.SetBoolArray("crounchs", crouchs);
        PlayerPrefs.SetInt("Count", 0);

        //死亡位置を保存
        death_Pos = Vector3.zero;
        PlayerPrefsX.SetVector3("DeathPos", death_Pos);

        //Playerprefsxの中のreplayFlagをon
        doReplay = false;
        PlayerPrefsX.SetBool("ReplayFlag", doReplay);

        //特定の位置で消滅させるフラグをオンにする
        deadForZeroLife = false;
        PlayerPrefsX.SetBool("deadForZeroLife", deadForZeroLife);

        InitializeObj();
        InitializeFlag();
        InitializeTime();
        InitializeOtherValue();

        InitializePlayerDataArray();
    }
    #endregion

    #region　Fixed更新
    // Update is called once per frame
    void FixedUpdate()
    {

//ねっぽ　ここから
        //現在の時刻を記録
        if (Time.timeSinceLevelLoad < 0)
            return;
        now_timeCount = Time.timeSinceLevelLoad;
//ねっぽ　ここまで

        #region Replay
        //REPLAYするかどうかをチェック
        doReplay = PlayerPrefsX.GetBool("ReplayFlag");

        if (doReplay)
        {
            DoReplay();
            ghost.SetActive(true);
        }
        else
        {
            ghost.SetActive(false);
        }
        #endregion

        #region 情報保存
        //プレイヤーが移動しているかどうかをチェック
        CheckPlayerIdleState();

        if (player_NowState == PlayerState.Move)
        {
            //もし保存できる最大値以下だったら
            //フレームごとに、プレイヤーの情報を保存する
            if (dataList.Count < MAXTIME)
            {
                dataList.Add(GetData());
            }
            else
            {
                Debug.Log("MaxWarining");
            }
        }
        //Debug.Log(dataList.Count);
        if (player_NowState == PlayerState.Idle)
        {
            //止まったら、移動するまでの時間を記録する。
            idle_Time += Time.deltaTime;
        }

        //保存用の配列に値を再代入する
        for (int i = 0; i < dataList.Count; i++)
        {
            hs[i] = dataList[i].h;
            jumps[i] = dataList[i].m_Jump;
            crouchs[i] = dataList[i].crouch;
            times[i] = dataList[i].time;
        }
        #endregion

        CheckPlayerLife();

        if (deadForZeroLife)
        {
            GhostDisapear();
        }
    }
    #endregion

    #region 関数
    /// <summary>
    /// これは移動情報を動的配列に保存するメソッドです
    /// Data型を返す
    /// </summary>
    /// <returns></returns>
    private Data GetData()
    {
        Data d = new Data();
        //現在の時間-停止状態の全時間帯=ゴーストが実際に動く時間
        d.time = now_timeCount - idle_Time;
        d.h = player.GetComponent<ThirdPersonUserControl>().h;
        d.crouch = player.GetComponent<ThirdPersonUserControl>().crouch;
        d.m_Jump = player.GetComponent<ThirdPersonUserControl>().m_Jump;
        return d;
    }

    /// <summary>
    /// これはプレイヤーの移動状態をチェックするメソッドです。
    /// 停止ならlayer_NowState = PlayerState.Idle;逆ー＞layer_NowState = PlayerState.Move
    /// </summary>
    public void CheckPlayerIdleState()
    {
        if (player.gameObject.GetComponent<ThirdPersonUserControl>().v == 0 &&
player.gameObject.GetComponent<ThirdPersonUserControl>().h == 0 &&
!player.gameObject.GetComponent<ThirdPersonUserControl>().m_Jump)
        {
            player_NowState = PlayerState.Idle;
        }
        else
        {
            player_NowState = PlayerState.Move;
        }
    }

    /// <summary>
    /// これはゴーストをエフェクトで消滅させるメソッド
    /// 前回の死亡位置と比較して、その範囲内なら、移動を停止させ、エフェクトを再生させる
    /// </summary>
    public void GhostDisapear()
    {
        if ((death_Pos.x - ghost.transform.position.x > -0.1f && death_Pos.x - ghost.transform.position.x < 0.1f) &&
            (death_Pos.y - ghost.transform.position.y > -0.1f && death_Pos.y - ghost.transform.position.y < 0.1f) &&
            (death_Pos.z - ghost.transform.position.z > -0.1f && death_Pos.z - ghost.transform.position.z < 0.1f))
        {
            //移動を停止
            ghost.GetComponent<GhostController>().v = 0;
            ghost.GetComponent<GhostController>().h = 0;
            ghost.GetComponent<GhostController>().m_Jump = false;
            ghost.GetComponent<GhostController>().crouch = false;

            //エフェクト位置をゴースト現在位置まで移動
            Eff_Disapear.transform.position = ghost.transform.position;

            //エフェクト再生
            if (eff_Playable)
            {
                ParSys_Disapear.Play();
                eff_Playable = false;
            }

            doReplay = false;
            ghostExist_Flag = false;

            player_body = ghost.transform.Find("EthanBody").gameObject;

            player_body.SetActive(false);
        }

    }

    /// <summary>
    /// これはライフ数が０になったときの処理メソッド
    /// </summary>
    public void CheckPlayerLife()
    {
        if (player.GetComponent<PlayerLifeControl>().lifeCount == 0)
        {
            //移動情報をplayerPrefsXに保存
            PlayerPrefsX.SetFloatArray("Hs", hs);
            PlayerPrefsX.SetFloatArray("Times", times);
            PlayerPrefsX.SetBoolArray("jumps", jumps);
            PlayerPrefsX.SetBoolArray("crounchs", crouchs);
            PlayerPrefs.SetInt("Count", dataList.Count);

            //死亡位置を保存
            death_Pos = player.transform.position;
            PlayerPrefsX.SetVector3("DeathPos", death_Pos);

            //Playerprefsxの中のreplayFlagをon
            doReplay = true;
            PlayerPrefsX.SetBool("ReplayFlag", doReplay);

            //特定の位置で消滅させるフラグをオンにする
            deadForZeroLife = true;
            PlayerPrefsX.SetBool("deadForZeroLife", deadForZeroLife);

            //シーンをロード
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
    
    /// <summary>
    /// これはリプレイ時にゴーストを再生させるメソッド
    /// </summary>
    public void DoReplay()
    {
        //一回だけ値を保存する
        if (setReplayValue)
        {
            //リプレイするとき取り出す
            ghostExist_Flag = true;
            //新しい配列に入れる
            arrayCount = PlayerPrefs.GetInt("Count");
            new_hs = PlayerPrefsX.GetFloatArray("Hs");
            new_times = PlayerPrefsX.GetFloatArray("Times");
            new_jumps = PlayerPrefsX.GetBoolArray("jumps");
            new_crouchs = PlayerPrefsX.GetBoolArray("crounchs");
            setReplayValue = false;
        }

        //配列内の要素をチェックする
        //現在の時間と一致したら、その情報量をゴーストに代入する
        for (int i = 0; i < arrayCount; i++)
        {
            if (now_timeCount - new_times[i] >= Time.deltaTime)
            {
                MoveGhost(i);
                ghost.GetComponent<TrailRenderer>().time += Time.time;
            }
        }
    }

    /// <summary>
    /// これはゴーストを移動させるメソッド
    /// </summary>
    /// <param name="i"></param>
    public void MoveGhost(int i)
    {
        if (ghostExist_Flag)
        {
            ghost.GetComponent<GhostController>().h = new_hs[i];
            ghost.GetComponent<GhostController>().m_Jump = new_jumps[i];
            ghost.GetComponent<GhostController>().crouch = new_crouchs[i];
        }
    }

    /// <summary>
    /// これはプレイヤーかゴーストが範囲外にいるときの処理メソッドです
    /// </summary>
    /// <param name="collision"></param>
    public void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            //プレイヤーのライフ数をゼロまで減らせる
            player.GetComponent<PlayerLifeControl>().lifeCount = 0;
        }
        if (collision.gameObject.tag == "Ghost")
        {
            //ゴーストを消滅させる
            ghostExist_Flag = false;
            ghost.GetComponent<GhostController>().v = 0;
            ghost.GetComponent<GhostController>().h = 0;
            ghost.GetComponent<GhostController>().m_Jump = false;
            ghost.GetComponent<GhostController>().crouch = false;
            player_body = ghost.transform.Find("EthanBody").gameObject;
            player_body.SetActive(false);
        }
    }
    #endregion
}