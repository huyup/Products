﻿これはUnityを使った練習作品です。

まだまだ途中しかできていません。

プレイする前に：
　Unityをインストールする必要があります。UnityのエディタでAssets/Scenesの中から、
Loading、Stage1、Stage2、Stage3の一つを選んでプレイすることができます。Loadingからスタートすると、
Loading->Stage1->Stage2->Stage3の順でプレイすることができます。

操作方法：
　キーボードのW+A+S+Dで移動、Hでジャンプする