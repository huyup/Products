using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


public enum Direction
{
    Right,
    Left,
}
namespace PersonalGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Monkey : Microsoft.Xna.Framework.DrawableGameComponent
    {

        #region �t�B�[���h
        //�e�X�g���[�h
        private bool testMode;


        //�o�g���X�^�[�g�̃t���O
        public bool battleStart;

        //�}�l�[�W���ϐ�
        public GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        ContentManager content;

        //���l
        private int alpha = 255;

        //�`��\���ǂ������`�F�b�N����t���O
        public bool drawEnable = true;

        /*�e�N�X�`��*/
        private Texture2D TestRecImg;

        public Texture2D monkeyImg;
        private Texture2D monkeyImg_Stone;
        public Texture2D monkeyImg_Init;
        private Texture2D monkeyImg_Attack;

        private Texture2D heartImg;
        private Texture2D heart_EmptyImg;
        private Texture2D heart_HalfEmptyImg;

        private Texture2D bananaBombImg;
        private Texture2D bananaCountIconImg;
        private AnimatedTexture2D BombEffectImg;

        private Texture2D SkateboardImg;
        private Texture2D SKateboardIconImg;
        private Texture2D SkateboardImg_Boost;

        /*�n�ʂ̈ʒu*/
        private float groundY = 700;

        /// <summary>
        /// ��_���[�W
        /// </summary>
        public bool isHit = false;
        public int hp;
        private Vector2 center;
        private float radius;

        /// <summary>
        /// �_��
        /// </summary>
        private bool isFlashing = false;
        private TimeSpan flashTime = TimeSpan.Zero;
        DateTime flashStartTime = DateTime.MinValue;

        /// <summary>
        /// �|�W�V����
        /// </summary>
        public Vector2 Position
        {
            set { position = value; }
            get { return position; }
        }
        private Vector2 position = new Vector2(130, 700);

        /// <summary>
        /// ���S�_�̃|�W�V����
        /// </summary>
        public Vector2 CenterPos
        {
            set { centerPos = value; }
            get { return centerPos; }
        }
        private Vector2 centerPos;

        /// <summary>
        /// �ړ�
        /// </summary>
        /*�������̑��x*/
        private float VY;
        private float VX = 0f;

        /*���E�ړ����̌���*/
        private Direction direction;

        /// <summary>
        /// �U��
        /// </summary>
        /*��*/
        public bool swordHitEnable = false;
        public bool attackEnable = false;
        private DateTime attackST_s;
        private TimeSpan attackElpasedT_s;

        /*�o�i�i���e*/
        //�o�i�i���g�p�\���ǂ������`�F�b�N
        public bool haveBananaBomb = false;

        private Vector2 bananaPos;
        //�c�e��
        public int usefulBananaBombCount = 3;

        //�Ǘ��p
        public bool bananaBombDrawEnable = false;
        public bool useBananaBomb = false;
        private bool bananaOnFloor = false;

        private DateTime bananaBombStartTime;
        //������p
        public Rectangle bananaBombRec;
        public bool bananaBombHitEnable = false;
        //���F����Ԃ�
        private int bananaColorGreen_Count = 255;
        private int bananaColorBlue_Count = 255;
        //�������̈ړ��Ɏg��������
        private float VX_b = 0;
        private float VY_b = 0;
        private float accelX_b = 0;
        private float accelY_b = 0;
        private float bananaAngle;

        /// <summary>
        /// �W�����v
        /// </summary>
        //�O�p�W�����v���s�ł��鋗��
        private float wall_distance = 5.0f;
        //�W�����v����Ƃ��̏����x
        private float jump_speed = -22;
        //�d��
        private float jump_accel = 1.5f;
        //��i�W�����v����Ƃ��̏����x
        private float double_Jump_VY = 10;
        //�W�����v������
        public int jumpCount = 0;
        //�ő�W�����v��
        private int maxJumpCount = 2;
        //���ɏ���Ă��邩�ǂ���
        public bool onfloor = false;

        /// <summary>
        /// �X�P�[�g�{�[�g
        /// </summary>
        //�g����܂ł̎���
        private DateTime skateBoardEndTime;
        private TimeSpan skateBoardUseful_TimeSpan;

        //������
        private Direction skateBoardDirection = Direction.Right;
        private Vector2 skateboardPos = new Vector2(300, 750);

        //�Ǘ��p
        public bool haveSkateBoard = false;
        public bool skateBoardEnable = true;
        public bool skateBoardHitEnable = false;
        public bool useSkateBoard = false;
        public bool onSkateBoard = false;
        public bool skateBoardBoost = false;

        //������
        private float skateboardVX = 0.0f;
        private float skateboard_max_speed = 8.0f;
        private float skateboardAccel = 0.3f;

        /// <summary>
        /// ����p�����`
        /// </summary>
        private Rectangle testRec;
        public Rectangle swordRec;
        public Rectangle rectangle;
        public Rectangle skateboardRec;

        /// <summary>
        /// �U��q
        /// </summary>
        //�U��q�̕߂܂������ǂ������`�F�b�N����t���O
        private bool onPendulum = false;
        private bool onPendulum2 = false;

        /// <summary>
        /// ���[�v�~
        /// </summary>
        //���[�v�~�ɓ��������ǂ������`�F�b�N����t���O
        public bool inroopCircle = false;

        //���[�v�~�ɓ��邽�߂̍ŒZ����
        float roopCircle_Distance = 0;

        //���[�v�~�ɓ������Ƃ��̉�]��
        private float angle = 0;
        private float angle2 = 0;
        private float angle3 = 0;

        //�e�X�g���[�h�p�t�H���g
        private SpriteFont font;

        #endregion

        #region �R���X�g���N�^
        public Monkey(Game game, ContentManager content)
            : base(game)
        {
            this.content = content;
            // TODO: Construct any child components here
        }
        #endregion

        #region ������
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            hp = 6;
            base.Initialize();
        }
        #endregion

        #region �R���e���c�̓ǂݍ���
        protected override void LoadContent()
        {
            this.spriteBatch = new SpriteBatch(GraphicsDevice);

            //��
            monkeyImg = content.Load<Texture2D>(@"Content\Scene3\Monkey_Stone");
            monkeyImg_Init = content.Load<Texture2D>(@"Content\Scene3\Monkey");
            monkeyImg_Attack = content.Load<Texture2D>(@"Content\Scene3\MONKEY_ATTACK3");
            monkeyImg = content.Load<Texture2D>(@"Content\Scene3\Monkey_Stone");

            //�X�P�[�g�{�[�g
            SkateboardImg = content.Load<Texture2D>(@"Content\Scene3\Skateboard");
            SkateboardImg_Boost = content.Load<Texture2D>(@"Content\Scene3\Skateboard_Boost");
            SKateboardIconImg = content.Load<Texture2D>(@"Content\Scene3\skateBoardIcon");

            //�n�[�g
            heartImg = content.Load<Texture2D>(@"Content\Scene3\Heart");
            heart_EmptyImg = content.Load<Texture2D>(@"Content\Scene3\Heart_Empty");
            heart_HalfEmptyImg = content.Load<Texture2D>(@"Content\Scene3\Heart_HalfEmpty");

            //�o�i�i���e
            bananaBombImg = content.Load<Texture2D>(@"Content\Scene3\BananaBomb");
            BombEffectImg = new AnimatedTexture2D(content.Load<Texture2D>(@"Content\Scene3\BananaBombEffect"), 1, 8, 10);
            bananaCountIconImg = content.Load<Texture2D>(@"Content\Scene3\BananaCountIcon");

            TestRecImg = content.Load<Texture2D>(@"Content\Scene3\TESTRect");
            font = content.Load<SpriteFont>(@"Content\ScenarioFont");
            base.LoadContent();
        }
        #endregion

        #region �p��
        protected override void UnloadContent()
        {
            base.UnloadContent();
        }
        #endregion

        #region �X�V
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            #region �����蔻��̍X�V
            //���W�̍X�V
            centerPos = new Vector2(position.X + monkeyImg.Width / 2 * 1.8f, position.Y + monkeyImg.Height / 2 * 1.8f);
            bananaBombRec = new Rectangle((int)bananaPos.X - 50 * (int)1.8,
(int)bananaPos.Y - 90 * (int)1.8,
150 * (int)1.8,
150 * (int)1.8);

            if (direction == Direction.Right)
            {
                if (!attackEnable)
                {
                    swordRec = new Rectangle((int)position.X + 30 * (int)1.8,
        (int)position.Y + 0 * (int)1.8,
        56 * (int)1.8,
        30 * (int)1.8);
                    //�ʏ�
                    if (!inroopCircle)
                    {
                        rectangle = new Rectangle((int)position.X + 40 * (int)1.8,
        (int)position.Y + 40 * (int)1.8,
        40 * (int)1.8,
        70 * (int)1.8);
                        center.X = position.X + 40 * 1.8f + 20 * 1.8f;
                        center.Y = position.Y + 40 * 1.8f + 35 * 1.8f;
                    }

                    //���[�v�~�ɂ���Ƃ�
                    else
                    {
                        rectangle = new Rectangle((int)position.X - 10 * (int)1.8,
(int)position.Y + 20 * (int)1.8,
20 * (int)1.0,
20 * (int)1.0);
                        center.X = position.X - 10 * 1.8f + 20 * 1.0f;
                        center.Y = position.Y + 40 * 1.8f + 20 * 1.0f;
                    }
                }
                //�U���̂Ƃ�
                else
                {
                    swordRec = new Rectangle((int)position.X + 95 * (int)1.8,
    (int)position.Y + 60 * (int)1.8,
    40 * (int)1.8,
    30 * (int)1.8);
                    rectangle = new Rectangle((int)position.X + 40 * (int)1.8,
(int)position.Y + 40 * (int)1.8,
40 * (int)1.8,
70 * (int)1.8);
                    center.X = position.X + 40 * 1.8f + 20 * 1.8f;
                    center.Y = position.Y + 40 * 1.8f + 35 * 1.8f;
                }
            }
            if (direction == Direction.Left)
            {
                if (!attackEnable)
                {
                    swordRec = new Rectangle((int)position.X + 20 * (int)1.8,
        (int)position.Y + 0 * (int)1.8,
        56 * (int)1.8,
        30 * (int)1.8);
                    if (!inroopCircle)
                    {
                        rectangle = new Rectangle((int)position.X + 20 * (int)1.8,
    (int)position.Y + 40 * (int)1.8,
    40 * (int)1.8,
    70 * (int)1.8);
                        center.X = position.X + 20 * 1.8f + 20 * 1.8f;
                        center.Y = position.Y + 40 * 1.8f + 35 * 1.8f;
                    }
                    else
                    {
                        rectangle = new Rectangle((int)position.X - 30 * (int)1.8,
(int)position.Y + 30 * (int)1.8,
40 * (int)1.0,
50 * (int)1.0);
                        center.X = position.X - 30 * 1.8f + 20 * 1.8f;
                        center.Y = position.Y + 30 * 1.8f + 25 * 1.8f;
                    }
                }
                else
                {
                    swordRec = new Rectangle((int)position.X + 15 * (int)1.8,
(int)position.Y + 60 * (int)1.8,
40 * (int)1.8,
30 * (int)1.8);
                    rectangle = new Rectangle((int)position.X + 60 * (int)1.8,
(int)position.Y + 40 * (int)1.8,
40 * (int)1.8,
70 * (int)1.8);
                    center.X = position.X + 60 * 1.8f + 20 * 1.8f;
                    center.Y = position.Y + 40 * 1.8f + 35 * 1.8f;
                }
            }
            skateboardRec = new Rectangle((int)skateboardPos.X + 30 * (int)1.3,
(int)skateboardPos.Y + 0 * (int)1.3,
100 * (int)1.3,
50 * (int)1.3);
            radius = 20 * 1.8f;
            #endregion

            //�������
            if (position.X < 0)
                position.X = 0;
            if (position.X > 1300)
                position.X = 1300;

            position.X += VX;

            //�X�P�[�g�{�[�g
            if (haveSkateBoard)
            {
                UseSkateBoard();
            }
            if (!inroopCircle&&battleStart)
            {
                //�ړ�
                MoveAndJump();

                //�U��
                SwordAttack();

                //�o�i�i�U��
                if (haveBananaBomb)
                {
                    BananaBombAttack();
                    BombEffectImg.Play();
                    BombEffectImg.Update((float)gameTime.ElapsedGameTime.TotalSeconds);
                }
            }
            if (InputManager.IsJustKeyDown(Keys.D3))
            {
                if (!testMode)
                    testMode = true;
            }
            if (InputManager.IsJustKeyDown(Keys.D4))
            {
                if (testMode)
                    testMode = false;
            }
            if (!testMode)
            {
                Damage();
            }
            base.Update(gameTime);
        }
        #endregion

        #region ���\�b�h

        #region �X�P�[�g�{�[�g
        private void UseSkateBoard()
        {
            //�v���C���[���X�P�[�g�{�[�g�̏�ɂ��邩�ǂ������`�F�b�N
            if (rectangle.Intersects(skateboardRec) && useSkateBoard)
            {
                onSkateBoard = true;
            }
            //������Ƃ��̍��W����
            if (onSkateBoard && jumpCount == 0 && !inroopCircle)
            {
                onSkateBoard = true;
                position.X = skateboardPos.X;
                position.Y = skateboardPos.Y - 80;
            }
            //�W�����v����Ƃ��A�X�P�[�g�{�[�g���痣���
            if (jumpCount > 0)
            {
                onSkateBoard = false;
            }
            //K�L�[���������Ƃ��A�X�P�[�g�{�[�g���v���C���[�̉��ɏo��
            if (InputManager.IsKeyDown(Keys.K) &&
                useSkateBoard == false &&
                direction == Direction.Right &&
                skateBoardEnable == true)
            {
                useSkateBoard = true;
                skateBoardHitEnable = true;
                skateBoardBoost = false;
                skateboard_max_speed = 8.0f;
                skateboardAccel = 0.3f;
                skateboardVX = 0.0f;
                skateBoardDirection = Direction.Right;
            }
            if (InputManager.IsKeyDown(Keys.K) &&
                useSkateBoard == false &&
                direction == Direction.Left &&
                skateBoardEnable == true)
            {
                useSkateBoard = true;
                skateBoardHitEnable = true;
                skateBoardBoost = false;
                skateboard_max_speed = -8.0f;
                skateboardAccel = -0.3f;
                skateboardVX = 0.0f;
                skateBoardDirection = Direction.Left;
            }
            #region �X�P�[�g�{�[�g�̈ړ�
            if (useSkateBoard)
            {
                skateboardVX += skateboardAccel;
                skateboardPos.X += skateboardVX;

                if (skateBoardDirection == Direction.Right)
                {
                    if (skateboardVX > skateboard_max_speed)
                        skateboardVX = skateboard_max_speed;
                    if (skateboardPos.X > 1350)
                    {
                        skateBoardEndTime = DateTime.Now;
                        skateBoardEnable = false;
                        useSkateBoard = false;
                        onSkateBoard = false;
                    }
                }
                else
                {
                    if (skateboardVX < skateboard_max_speed)
                        skateboardVX = skateboard_max_speed;
                    if (skateboardPos.X < 0)
                    {
                        skateBoardEndTime = DateTime.Now;
                        skateBoardEnable = false;
                        useSkateBoard = false;
                        onSkateBoard = false;
                    }
                }
            }
            else
            {
                skateboardPos.X = position.X;
                skateboardPos.Y = groundY + 50;
                useSkateBoard = false;
            }

            skateBoardUseful_TimeSpan = DateTime.Now - skateBoardEndTime;
            int secondCount = (int)skateBoardUseful_TimeSpan.TotalSeconds;
            if (15 - secondCount == 0)
            {
                skateBoardEnable = true;
                skateBoardEndTime = DateTime.MinValue;
            }
            #endregion
        }
        #endregion

        #region �ړ�&�W�����v
        private void MoveAndJump()
        {

            if (jumpCount == 0)
            {
                onfloor = false;
                MoveFunction();
                //�W�����v&&��э~��
                if (InputManager.IsJustKeyDown(Keys.J) && !InputManager.IsJustKeyDown(Keys.S))
                {
                    jumpCount = 1;
                    VY = jump_speed;
                }
                if (InputManager.IsJustKeyDown(Keys.J) && InputManager.IsKeyDown(Keys.S) && position.Y < groundY)
                {
                    jumpCount = 1;
                    VY = 0;
                }

            }
            else
            {
                VY += jump_accel;

                position.Y += VY;

                //��i�W�����v
                if (Math.Abs(VY) < double_Jump_VY &&
                    InputManager.IsJustKeyDown(Keys.J) &&
                    jumpCount < maxJumpCount)
                {
                    VY = jump_speed;
                    jumpCount++;
                }
                //�O�p�W�����v
                if ((VX <= 0 && position.X < wall_distance || VX > 0 && position.X > 1300 - wall_distance) &&
                    InputManager.IsJustKeyDown(Keys.J) &&
                    jumpCount < maxJumpCount)
                {
                    VX = -VX;
                    VY = jump_speed;
                    jumpCount++;
                }
                if (position.Y > groundY && VY > 0)
                {
                    jumpCount = 0;
                    position.Y = groundY;
                }
                if (VY < 0 && !InputManager.IsKeyDown(Keys.J))
                {
                    VY = 0;
                    VY = -VY;
                }
                if (InputManager.IsKeyDown(Keys.D))
                {
                    position.X += VX;
                    direction = Direction.Right;
                }
                if (InputManager.IsKeyDown(Keys.A))
                {
                    position.X += VX;
                    direction = Direction.Left;
                }
            }
        }
        private void MoveFunction()
        {
            //���E�ړ�
            if (InputManager.IsKeyDown(Keys.D))
            {
                VX = 3.5f;
                direction = Direction.Right;
            }
            else
            {
                VX = 0;
            }
            if (InputManager.IsKeyDown(Keys.A))
            {
                VX = -3.5f;
                direction = Direction.Left;
            }
        }
        public void CheckOnFloor(ref Mover[] mover, int moverCount)
        {
            //������O�ꂽ�Ƃ��̏���
            if (jumpCount == 0)
            {
                for (int i = 0; i < moverCount; i++)
                {
                    if ((Math.Abs(mover[i].moverCenterPos.X - centerPos.X) < mover[i].mover_max_X) &&
                        mover[i].moverCenterPos.Y - centerPos.Y < mover[i].mover_min_Y)
                    {
                        onfloor = true;
                    }
                }
                if (position.Y < groundY && !onfloor && !onSkateBoard && !onPendulum && !onPendulum2)
                {
                    jumpCount = 1;
                    VY = 0;
                }
            }
            else
            {
                for (int i = 0; i < moverCount; i++)
                {
                    if (VY > 0 &&
                        Math.Abs(mover[i].moverCenterPos.X - centerPos.X) < mover[i].mover_max_X &&
                        (mover[i].moverCenterPos.Y - centerPos.Y) > mover[i].mover_min_Y - 30 &&
                        (mover[i].moverCenterPos.Y - centerPos.Y) <= mover[i].mover_max_Y)
                    {
                        jumpCount = 0;
                        if (mover[i].moverType == MOVERTYPE.Type1)
                        {
                            position.Y = mover[i].moverCenterPos.Y - mover[i].mover_min_Y;
                        }
                        if (mover[i].moverType == MOVERTYPE.Type2)
                        {
                            position.Y = mover[i].moverCenterPos.Y - mover[i].mover_min_Y + 5;
                        }
                    }
                }
            }
        }
        #endregion

        #region ���[�v�~
        public void CheckRoopCircle(Vector2 roopPos, float roopCircleRadius, float roopImgWidth)
        {
            if (skateBoardDirection == Direction.Right)
            {
                roopCircle_Distance = 50.0f;
            }
            else
            {
                roopCircle_Distance = 150.0f;
            }
            if (Math.Abs(roopPos.X - position.X) < roopCircle_Distance && onSkateBoard && InputManager.IsKeyDown(Keys.W))
            {
                inroopCircle = true;
            }
            if (inroopCircle)
            {
                int aa = 150;
                roopCircleRadius = roopImgWidth * 1.6f / 2;

                skateBoardBoost = true;

                if (skateBoardDirection == Direction.Right)
                {
                    position.X = (roopPos.X + aa + 20) + roopCircleRadius * (float)Math.Cos((-angle + 0.25f) * Math.PI * 2);
                    position.Y = (roopPos.Y + aa + 150) + roopCircleRadius * (float)Math.Sin((-angle + 0.25f) * Math.PI * 2);

                    skateboardPos.X = (roopPos.X + aa + 30) + roopCircleRadius * (float)Math.Cos((-angle + 0.25f) * Math.PI * 2);
                    skateboardPos.Y = (roopPos.Y + aa + 150) + roopCircleRadius * (float)Math.Sin((-angle + 0.25f) * Math.PI * 2);

                    angle += 0.008f;
                    angle2 -= 3;
                    angle3 -= 3f;
                }
                else
                {
                    position.X = (roopPos.X + aa + 20) + roopCircleRadius * (float)Math.Cos((-angle + 0.25f) * Math.PI * 2);
                    position.Y = (roopPos.Y + aa + 165) + roopCircleRadius * (float)Math.Sin((-angle + 0.25f) * Math.PI * 2);

                    skateboardPos.X = (roopPos.X + aa + 30) + roopCircleRadius * (float)Math.Cos((-angle + 0.25f) * Math.PI * 2);
                    skateboardPos.Y = (roopPos.Y + aa + 140) + roopCircleRadius * (float)Math.Sin((-angle + 0.25f) * Math.PI * 2);

                    angle -= 0.01f;
                    angle2 += 3.0f;
                    angle3 += 3.3f;
                }


                if (skateBoardDirection == Direction.Right)
                {
                    if (angle > 1)
                    {
                        skateboard_max_speed = 12.0f;
                        skateboardAccel = 5.0f;
                        inroopCircle = false;
                    }
                }
                if (skateBoardDirection == Direction.Left)
                {
                    if (angle < -1)
                    {
                        skateboard_max_speed = -12.0f;
                        skateboardAccel = -5.0f;
                        inroopCircle = false;
                    }
                }
            }
            else
            {
                if (skateboardPos.Y < groundY + 50)
                {
                    skateboardPos.Y += 3;
                }
                else
                {
                    skateboardPos.Y = groundY + 50;
                }
                angle = 0;
                angle2 = 0;
                angle3 = 0;
            }
        }
        #endregion

        #region �U��q
        public void CheckOnPendulum(ref Pendulum[] pendulum, int pendulumCount)
        {
            for (int i = 0; i < pendulumCount; i++)
            {
                //�U��q�ɕ߂܂������ǂ����̂����蔻��
                if (pendulum[i].PendulumRec.Intersects(rectangle) && !pendulum[i].secondJump)
                {
                    pendulum[i].onPendulum = true;
                    this.onPendulum = true;
                    //�o������W�����v�J�E���g�����Z�b�g
                    if (pendulum[i].resetJumpCount)
                    {
                        jumpCount = 0;
                        pendulum[i].resetJumpCount = false;
                    }
                }
                //���ꂽ�Ƃ��@�W�����v�J�E���g�����Z�b�g
                if (onPendulum && jumpCount > 0)
                {
                    pendulum[i].resetJumpCount = true;
                    pendulum[i].secondJump = true;
                }
                if (Math.Abs(position.X - pendulum[i].PendulumBottomPos.X) > 100)
                {
                    pendulum[i].secondJump = false;
                }
                //�߂܂����Ƃ��̍��W����
                if (pendulum[i].onPendulum)
                {
                    if (jumpCount == 0)
                    {
                        position.X = pendulum[i].PendulumBottomPos.X - 30;
                        position.Y = pendulum[i].PendulumBottomPos.Y + 30;
                    }
                    else
                    {
                        pendulum[i].onPendulum = false;
                        this.onPendulum = false;
                    }
                }
            }
            testRec = pendulum[0].PendulumRec;
        }
        #endregion

        #region �U��
        public void SwordAttack()
        {
            if (!attackEnable && !onPendulum && !onPendulum2)
            {
                if (InputManager.IsJustKeyDown(Keys.H))
                {
                    attackEnable = true;
                    swordHitEnable = true;
                    attackST_s = DateTime.Now;
                }
            }
            if (attackEnable)
            {
                attackElpasedT_s = DateTime.Now - attackST_s;
                if (attackElpasedT_s.TotalSeconds < 0.5)
                {
                    monkeyImg = monkeyImg_Attack;
                }
                else
                {
                    monkeyImg = monkeyImg_Init;
                    attackEnable = false;
                }
            }
        }
        public void BananaBombAttack()
        {
            if (InputManager.IsJustKeyDown(Keys.L) && !useBananaBomb && usefulBananaBombCount > 0)
            {
                //�p�������炷
                if (usefulBananaBombCount > 0)
                    usefulBananaBombCount--;
                //�t���O
                useBananaBomb = true;
                bananaBombDrawEnable = true;
                bananaOnFloor = false;
                bananaBombHitEnable = true;
                //���e��������ꂽ����
                bananaBombStartTime = DateTime.Now;
                //�G�t�F�N�g�C���[�W�����Z�b�g
                BombEffectImg.Reset();
                //�c����
                accelY_b = 2f;
                bananaPos.Y = position.Y + 30;
                VY_b = -20.0f;
                if (InputManager.IsKeyDown(Keys.S))
                {
                    accelX_b = 0;
                    bananaPos.X = position.X + 50;
                    VX_b = 0;
                }
                else
                {
                    //�E����
                    if (direction == Direction.Right)
                    {
                        accelX_b = 0.5f;
                        bananaPos.X = position.X + 50;
                        if (onSkateBoard)
                        {
                            VX_b = 8.0f + skateboardVX;
                        }
                        else
                        {
                            VX_b = 8.0f;
                        }
                    }
                    //������
                    if (direction == Direction.Left)
                    {
                        accelX_b = -0.5f;
                        bananaPos.X = position.X - 50;
                        if (onSkateBoard)
                        {
                            VX_b = -8.0f + skateboardVX;
                        }
                        else
                        {
                            VX_b = -8.0f;
                        }
                    }
                }

            }
            if (useBananaBomb)
            {
                if (bananaColorGreen_Count > 70)
                    bananaColorGreen_Count -= 2;
                if (bananaColorBlue_Count > 70)
                    bananaColorBlue_Count -= 2;
                if (bananaAngle > -100)
                    bananaAngle -= 5f;
                if ((DateTime.Now - bananaBombStartTime).TotalSeconds > 1.5)
                {
                    bananaColorBlue_Count = 255;
                    bananaColorGreen_Count = 255;
                    VY_b = 0;
                    accelX_b = 0;
                    VX_b = 0;
                    accelY_b = 0;
                    bananaAngle = 0;

                    //�����̃A�j���[�V�����ɕύX
                    bananaBombDrawEnable = false;
                }
                //1.0s���������㌳�ɖ߂�
                if ((DateTime.Now - bananaBombStartTime).TotalSeconds > 1.8)
                {
                    bananaBombStartTime = DateTime.MaxValue;
                    useBananaBomb = false;
                }
                if (bananaOnFloor)
                {
                    VY_b = 0;
                    accelY_b = 0;
                    VX_b = 0;
                    accelX_b = 0;
                }
                //�o�i�i�̏�O����
                if (bananaPos.Y > 800)
                {
                    bananaOnFloor = true;
                    bananaPos.Y = 820;
                }
                else
                {
                    VY_b += accelY_b;
                    bananaPos.Y += VY_b;
                }
                if (bananaPos.X < 0)
                {
                    bananaPos.X = 0;
                    VX_b = 0;
                    accelX_b = 0;
                }
                if (bananaPos.X > 1330)
                {
                    bananaPos.X = 1330;
                    VX_b = 0;
                    accelX_b = 0;
                }
                VX_b += accelX_b;
                bananaPos.X += VX_b;
            }


        }
        public void CheckBananaOnFloor(ref Mover[] mover2, int moverCount)
        {
            Vector2 bananaCenterPos;
            bananaCenterPos.X = bananaPos.X + bananaBombImg.Width * 1.3f / 2;
            bananaCenterPos.Y = bananaPos.Y + bananaBombImg.Height * 1.3f / 2;
            //������O�ꂽ�Ƃ��̏���
            for (int i = 0; i < moverCount; i++)
            {
                if (VY_b > 0 &&
                    Math.Abs(mover2[i].moverCenterPos.X - bananaCenterPos.X) < mover2[i].mover_max_X &&
                    (mover2[i].moverCenterPos.Y - bananaCenterPos.Y) > mover2[i].mover_min_Y &&
                    (mover2[i].moverCenterPos.Y - bananaCenterPos.Y) <= mover2[i].mover_max_Y)
                {
                    if (mover2[i].moverType == MOVERTYPE.Type3)
                    {
                        bananaPos.Y = mover2[i].moverCenterPos.Y - mover2[i].mover_min_Y - 10;
                        bananaOnFloor = true;
                    }
                    if (mover2[i].moverType == MOVERTYPE.Type4)
                    {
                        bananaPos.Y = mover2[i].moverCenterPos.Y - mover2[i].mover_min_Y + 30;
                        bananaOnFloor = true;
                    }
                }
            }
            //Debug.WriteLine(mover2[0].mover_min_Y);
        }
        #endregion

        #region ��_���[�W�̓_��&&��_���[�W
        private void Damage()
        {
            if (isHit)
            {
                if (!isFlashing)
                    hp--;
                isFlashing = true;
                flashStartTime = DateTime.Now;
                isHit = false;
            }
            if (isFlashing)
            {
                flashTime = DateTime.Now - flashStartTime;

                if ((flashTime.TotalSeconds >= 0 && flashTime.TotalSeconds < 0.2) || (flashTime.TotalSeconds >= 0.4 && flashTime.TotalSeconds < 0.6))
                {
                    drawEnable = false;
                }
                else
                {
                    drawEnable = true;
                }
                if (flashTime.TotalSeconds >= 1.2)
                {
                    drawEnable = true;
                    isFlashing = false;
                }
            }
        }
        public void CheckHit(Bat[] bat)
        {
            for (int i = 0; i < bat.GetLength(0); i++)
            {
                if (bat[i].rectangle.Intersects(rectangle))
                {
                    if (!isFlashing && bat[i].drawEnable && bat[i].alpha > 200)
                        isHit = true;
                }
            }
        }
        public void CheckHit(Rectangle coreRec)
        {
            if (coreRec.Intersects(rectangle))
            {
                if (!isFlashing)
                    isHit = true;
            }
        }
        public void CheckHit(Rectangle bossRec, Rectangle bossRec2, Rectangle bossRec3)
        {
            if (bossRec.Intersects(rectangle) || bossRec2.Intersects(rectangle) || bossRec3.Intersects(rectangle))
            {
                if (!isFlashing)
                    isHit = true;
            }
        }
        public void CheckHit(Rectangle bossRec, Rectangle bossRec2, Rectangle bossRec3, Rectangle bossRec4)
        {
            if (bossRec.Intersects(rectangle) || bossRec2.Intersects(rectangle) || bossRec3.Intersects(rectangle) || bossRec4.Intersects(rectangle))
            {
                if (!isFlashing)
                    isHit = true;
            }
        }


        #endregion

        #region �~�Ɛ��̂����蔻��p
        public void CircleLineCollisionFunction(Vector2 LineSt, Vector2 LineEd)
        {
            Vector2 AB = LineEd - LineSt;
            Vector2 AP = center - LineSt;

            float D = Math.Abs(AB.X * AP.Y - AB.Y * AP.X);
            float L = AB.Length();

            float H = D / L;

            if (H <= radius)
            {
                isHit = true;
            }
        }
        #endregion

        #region �A�C�e���Q�b�g
        public void CheckItemGet(Rectangle[] itemRec, ref bool[] itemEnable)
        {
            for (int i = 0; i < itemRec.GetLength(0); i++)
            {
                if (itemRec[i].Intersects(rectangle) && itemEnable[i])
                {

                    usefulBananaBombCount++;
                    itemEnable[i] = false;
                }

            }
        }
        #endregion
        #endregion

        #region �`�揈��
        public override void Draw(GameTime gameTime)
        {
            this.spriteBatch.Begin();
            //spriteBatch.Draw(TestRecImg, rectangle, Color.White);
            //spriteBatch.Draw(TestRecImg, bananaBombRec, Color.White);
            //spriteBatch.Draw(TestRecImg, swordRec, Color.White);

            #region �o�i�i���e
            if ((DateTime.Now - bananaBombStartTime).TotalSeconds > 1.5 && useBananaBomb)
            {
                BombEffectImg.DrawFrame(spriteBatch, bananaPos - new Vector2(150, 200), 1.5f, 255);
            }
            if (bananaBombDrawEnable)
            {
                spriteBatch.Draw(bananaBombImg, bananaPos, null, new Color(255, bananaColorGreen_Count, bananaColorBlue_Count, 255), MathHelper.ToRadians(bananaAngle), Vector2.Zero, 1.3f, SpriteEffects.None, 0.0f);
            }
            #endregion

            #region �X�P�[�g�{�[�g
            if (useSkateBoard)
            {
                if (!inroopCircle)
                {
                    if (skateBoardDirection == Direction.Right)
                    {
                        if (!skateBoardBoost)
                        {
                            spriteBatch.Draw(SkateboardImg, skateboardPos, null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.3f, SpriteEffects.None, 0.0f);
                        }
                        else
                        {
                            spriteBatch.Draw(SkateboardImg_Boost, skateboardPos - new Vector2(70, 0), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.3f, SpriteEffects.None, 0.0f);
                        }
                    }
                    else
                    {
                        if (!skateBoardBoost)
                        {
                            spriteBatch.Draw(SkateboardImg, skateboardPos, null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.3f, SpriteEffects.FlipHorizontally, 0.0f);
                        }
                        else
                        {
                            spriteBatch.Draw(SkateboardImg_Boost, skateboardPos - new Vector2(00, 0), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.3f, SpriteEffects.FlipHorizontally, 0.0f);
                        }
                    }
                }
                if (inroopCircle)
                {
                    if (skateBoardDirection == Direction.Right)
                    {
                        spriteBatch.Draw(SkateboardImg, skateboardPos, null, Color.Red, MathHelper.ToRadians(angle2), new Vector2(0, 50), 1.3f, SpriteEffects.None, 0.0f);
                    }
                    else
                    {
                        spriteBatch.Draw(SkateboardImg, skateboardPos, null, Color.Red, MathHelper.ToRadians(angle2), new Vector2(0, 50), 1.3f, SpriteEffects.FlipHorizontally, 0.0f);
                    }
                }
            }
            #endregion

            #region �v���C���[
            if (drawEnable)
            {
                if (direction == Direction.Right)
                {
                    if (!inroopCircle)
                        spriteBatch.Draw(monkeyImg, position, null, new Color(255, 255, 255, alpha), MathHelper.ToRadians(0), Vector2.Zero, 1.8f, SpriteEffects.None, 0.0f);
                    if (inroopCircle)
                    {
                        spriteBatch.Draw(monkeyImg, position, null, new Color(255, 255, 255, alpha), MathHelper.ToRadians(angle3), new Vector2(monkeyImg.Width / 2 - 30, monkeyImg.Height / 2 + 55), 1.8f, SpriteEffects.None, 0.0f);
                    }
                }
                else if (direction == Direction.Left)
                {
                    if (!inroopCircle)
                        spriteBatch.Draw(monkeyImg, position, null, new Color(255, 255, 255, alpha), MathHelper.ToRadians(0), Vector2.Zero, 1.8f, SpriteEffects.FlipHorizontally, 0.0f);
                    else
                        spriteBatch.Draw(monkeyImg, position, null, new Color(255, 255, 255, alpha), MathHelper.ToRadians(angle3), new Vector2(monkeyImg.Width / 2 - 30, monkeyImg.Height / 2 + 50), 1.8f, SpriteEffects.FlipHorizontally, 0.0f);
                }
            }
            #endregion

            #region �n�[�g�̕`��
            switch (hp)
            {
                case 0:
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(10, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(50, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(90, 10, 30, 30), Color.White);
                    break;
                case 1:
                    spriteBatch.Draw(heart_HalfEmptyImg, new Rectangle(10, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(50, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(90, 10, 30, 30), Color.White);
                    break;
                case 2:
                    spriteBatch.Draw(heartImg, new Rectangle(10, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(50, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(90, 10, 30, 30), Color.White);
                    break;
                case 3:
                    spriteBatch.Draw(heartImg, new Rectangle(10, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_HalfEmptyImg, new Rectangle(50, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(90, 10, 30, 30), Color.White);
                    break;
                case 4:
                    spriteBatch.Draw(heartImg, new Rectangle(10, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heartImg, new Rectangle(50, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(90, 10, 30, 30), Color.White);
                    break;
                case 5:
                    spriteBatch.Draw(heartImg, new Rectangle(10, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heartImg, new Rectangle(50, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_HalfEmptyImg, new Rectangle(90, 10, 30, 30), Color.White);
                    break;
                case 6:
                    spriteBatch.Draw(heartImg, new Rectangle(10, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heartImg, new Rectangle(50, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heartImg, new Rectangle(90, 10, 30, 30), Color.White);
                    break;
                default:
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(10, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(50, 10, 30, 30), Color.White);
                    spriteBatch.Draw(heart_EmptyImg, new Rectangle(90, 10, 30, 30), Color.White);
                    break;

            }
            #endregion

            if (haveBananaBomb)
            {
                spriteBatch.Draw(bananaCountIconImg, new Rectangle(120, 55, 30, 47), Color.White);
                spriteBatch.DrawString(font, "�c��:" + usefulBananaBombCount + "�R", new Vector2(105, 115), Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.7f, SpriteEffects.None, 0.0f);

            }
            if (haveSkateBoard)
            {
                if (skateBoardEnable)
                {
                    if (!useSkateBoard)
                    {
                        spriteBatch.DrawString(font, "�g�p�\", new Vector2(10, 114), Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.7f, SpriteEffects.None, 0.0f);
                    }
                    else
                    {
                        spriteBatch.DrawString(font, " -- : --", new Vector2(10, 114), Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.7f, SpriteEffects.None, 0.0f);
                    }
                }
                else
                {
                    spriteBatch.DrawString(font, " 00 : " + Convert.ToInt32((15 - skateBoardUseful_TimeSpan.TotalSeconds)), new Vector2(10, 115), Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.7f, SpriteEffects.None, 0.0f);
                }

                spriteBatch.Draw(SKateboardIconImg, new Rectangle(20, 43, 50, 80), Color.White);
            }

            //�f�o�b�O�ϐ�
            //spriteBatch.DrawString(font, "fT" + Convert.ToString(flashStartTime), new Vector2(500, 350), Color.Aqua);
            //spriteBatch.DrawString(font, "bananaAngle" + Convert.ToString(bananaAngle), new Vector2(500, 50), Color.Aqua);
            //spriteBatch.DrawString(font, "VX_b" + Convert.ToString(VX_b), new Vector2(500, 200), Color.Aqua);
            spriteBatch.End();

            base.Draw(gameTime);
        }
        #endregion
    }
}
