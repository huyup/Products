using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;
public enum BUYSELECTIONS
{
    Buy,
    NoToBuy,
    Init,

}
public enum ChoiceWhich
{
    ChoiceRight,
    ChoiceLeft,
    Init,
}
namespace PersonalGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Player : Microsoft.Xna.Framework.GameComponent
    {
        /// <summary>
        /// �v���C���[�̃e�N�X�`���A�j��
        /// </summary>
        public AnimatedTexture2DSelectFrames animatedTexture;

        public static Game game;
        //�e���|�[�g�J�t���O
        public bool isTeleport = false;

        //�傫��
        public float scale = 2.5f;

        /// <summary>
        /// �ړ�����̃t���O
        /// </summary>
        private bool UpKeyIsDown = false;
        private bool DownKeyIsDown = false;
        private bool LeftKeyIsDown = false;
        private bool RightKeyIsDown = false;

        /// <summary>
        /// �ړ��֎~�̃t���O
        /// </summary>
        public bool LeftKeyEnable = true;
        public bool UpKeyEnable = true;
        public bool RightKeyEnable = true;

        //��b�A�N�V�����̃t���O
        public bool hitAndEnter = false;

        //��b�E�B���h�E
        public Texture2D selectWindows;


        //���ڈȍ~�̐ڐG
        public bool encounterFirst = false;

        //���ڈȍ~�̐ڐG
        public bool encounterAgain = false;

        /// <summary>
        /// �~�Ɛ��̏Փ˃t���O
        /// </summary>
        public bool isHitLine1 = false;
        public bool isHitLine2 = false;
        public bool isHitLine3 = false;
        public bool isHitLine4 = false;
        public bool isHitLine5 = false;

        /// <summary>
        /// �A�C�e��
        /// </summary>
        public const int maxItem = 5;
        public Item[] item = new Item[maxItem];

        /*�A�C�e���w���I��*/
        public BUYSELECTIONS buySelection=BUYSELECTIONS.Init;
        public ChoiceWhich choiceSelection = ChoiceWhich.Init;
        /*�A�C�e���Q�b�g�t���O*/
        public bool getItem = true;

        /// <summary>
        /// �v���C���[�̃|�W�V����
        /// </summary>
        public Vector2 Position
        {
            set { position = value; }
            get { return position; }
        }
        private Vector2 position;

        /// <summary>
        /// �v���C���[���ړ�������t���O
        /// </summary>
        public bool MovePlayerFlag
        {
            set { movePlayerFlag = value; }
            get { return movePlayerFlag; }
        }
        private bool movePlayerFlag = true;

        /// <summary>
        /// �v���C���[��I��������t���O
        /// </summary>

        /// <summary>
        /// �v���C���[�̃��l
        /// </summary>
        public int Alpha
        {
            set { alpha = value; }
            get { return alpha; }
        }
        private int alpha = 255;


        /// <summary>
        /// �H�}�[�N�e�N�X�`��
        /// </summary>
        public Texture2D questionMarkImg;

        public Player(Game game)
            : base(game)
        {
            // TODO: Construct any child components here
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here

            //�v���C���[�̃|�W�V����������
            position = new Vector2(1100, 900);

            //�v���C���[�̃A�C�e��������
            for (int i = 0; i < maxItem; i++)
            {
                item[i] = new Item();
                item[i].name = "��";
                item[i].position = Vector2.Zero;
                item[i].Img = null;
            }
            base.Initialize();
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            //�e�N�X�`���A�j���V���[���̍X�V����

            animatedTexture.Update((float)gameTime.ElapsedGameTime.TotalSeconds);
            // TODO: Add your update code here

            #region �V�[���P�̏���ړ�����
            if (position.Y > 660)
            {
                isHitLine2 = false;
                isHitLine3 = false;
                isHitLine4 = false;
                isHitLine5 = false;
                isHitLine1 = CircleLineCollisionFunction(position, 20, new Vector2(850, 660), new Vector2(1180, 1200));
            }
            else if (position.Y <= 660 && position.Y >= 420)
            {
                isHitLine1 = false;
                isHitLine4 = false;
                isHitLine5 = false;
                isHitLine2 = CircleLineCollisionFunction(position, 20, new Vector2(206, 420), new Vector2(850, 660));
                isHitLine3 = CircleLineCollisionFunction(position, 20, new Vector2(530, 420), new Vector2(1250, 620));

            }
            else if (position.Y <= 420 && position.Y >= 300)
            {
                isHitLine1 = false;
                isHitLine2 = false;
                isHitLine3 = false;
                isHitLine4 = CircleLineCollisionFunction(position, 10, new Vector2(206, 410), new Vector2(780, 300));
                isHitLine5 = CircleLineCollisionFunction(position, 10, new Vector2(640, 375), new Vector2(990, 300));
            }
            #endregion


            base.Update(gameTime);
        }

        #region ���\�b�h
        #region �ړ�
        public void PlayerMoveFunction()
        {
            //�����L�[�Ō����ƈʒu�𒲐�
            #region ���̒i�̈ړ�
            if (position.Y > 420)
            {
                if (isHitLine1 || isHitLine2)
                {
                    if (Keyboard.GetState().IsKeyDown(Keys.A))
                    {
                        if (!LeftKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 3, 4, 5, 4 });
                    }
                    if (Keyboard.GetState().IsKeyDown(Keys.S))
                    {
                        if (!DownKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 0, 1, 2, 1 });
                    }
                }
                else
                {
                    if (Keyboard.GetState().IsKeyDown(Keys.A))
                    {
                        if (LeftKeyEnable)
                            position.X = position.X - 2.5f;
                        if (!LeftKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 3, 4, 5, 4 });
                    }
                    if (Keyboard.GetState().IsKeyDown(Keys.S))
                    {
                        position.Y = position.Y + 2.5f;
                        if (!DownKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 0, 1, 2, 1 });
                    }
                }
                if (isHitLine3)
                {
                    if (Keyboard.GetState().IsKeyDown(Keys.D))
                    {
                        if (!RightKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 6, 7, 8, 7 });
                    }
                    if (Keyboard.GetState().IsKeyDown(Keys.W))
                    {
                        if (!UpKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 9, 10, 11, 10 });
                    }
                }
                else
                {
                    if (Keyboard.GetState().IsKeyDown(Keys.D))
                    {
                        if (RightKeyEnable)
                            position.X = position.X + 2.5f;
                        if (!RightKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 6, 7, 8, 7 });
                    }
                    if (Keyboard.GetState().IsKeyDown(Keys.W))
                    {
                        if (UpKeyEnable)
                            position.Y = position.Y - 2.5f;
                        if (!UpKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 9, 10, 11, 10 });
                    }
                }
            }
            #endregion
            else if (position.Y <= 420 && position.Y > 250)
            {
                if (isHitLine4)
                {
                    if (Keyboard.GetState().IsKeyDown(Keys.A))
                    {
                        if (!LeftKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 3, 4, 5, 4 });
                    }
                    if (Keyboard.GetState().IsKeyDown(Keys.W))
                    {
                        if (!UpKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 9, 10, 11, 10 });
                    }
                }
                else
                {
                    if (Keyboard.GetState().IsKeyDown(Keys.A))
                    {
                        if (LeftKeyEnable)
                            position.X = position.X - 2.5f;
                        if (!LeftKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 3, 4, 5, 4 });
                    }
                    if (Keyboard.GetState().IsKeyDown(Keys.W))
                    {
                        position.Y = position.Y - 2.5f;
                        if (!UpKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 9, 10, 11, 10 });
                    }
                }
                if (isHitLine5)
                {
                    if (Keyboard.GetState().IsKeyDown(Keys.S))
                    {
                        if (!DownKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 0, 1, 2, 1 });
                    }
                    if (Keyboard.GetState().IsKeyDown(Keys.D))
                    {
                        if (!RightKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 6, 7, 8, 7 });
                    }
                }
                else
                {
                    if (Keyboard.GetState().IsKeyDown(Keys.S))
                    {
                        position.Y = position.Y + 2.5f;
                        if (!DownKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 0, 1, 2, 1 });
                    }
                    if (Keyboard.GetState().IsKeyDown(Keys.D))
                    {
                        position.X = position.X + 2.5f;
                        if (!RightKeyIsDown)
                            animatedTexture.SetFrames(new int[] { 6, 7, 8, 7 });
                    }
                }
            }
            //�L�[���͂̍X�V
            DownKeyIsDown = Keyboard.GetState().IsKeyDown(Keys.S);
            LeftKeyIsDown = Keyboard.GetState().IsKeyDown(Keys.A);
            RightKeyIsDown = Keyboard.GetState().IsKeyDown(Keys.D);
            UpKeyIsDown = Keyboard.GetState().IsKeyDown(Keys.W);

            //�����L�[�������Ă��Ȃ�������A�j���[�V�������~�߂�
            if (!DownKeyIsDown && !LeftKeyIsDown && !RightKeyIsDown && !UpKeyIsDown)
            {
                if (!movePlayerFlag)
                {
                    //�\������t���[���𗧂��G�ɐݒ肷��
                    animatedTexture.SetCurrentFrameNumber(animatedTexture.GetFrames()[1]);
                    animatedTexture.Pause();
                }
                else
                    animatedTexture.Play();
            }
            else
                animatedTexture.Play();


        }
        #endregion

        #region �ړ��͈�
        public void CheckMoveableEdge(int width, int height)
        {

            //�ړ��͈�
            if (position.X > width - 80)
                position.X = width - 80;
            if (position.X < 0)
                position.X = 0;
            if (position.Y > height - 85)
                position.Y = height - 85;
            if (position.Y < 0)
                position.Y = 0;
        }
        #endregion

        #region ����Ɉړ�
        public void MoveIntoGame(ref bool sceneStartFlag, Scene scene)
        {
            if (scene == Scene.InGame_Scene1)
            {
                if (MovePlayerFlag)
                {
                    if (position.Y == 900)
                        animatedTexture.SetFrames(new int[] { 9, 10, 11, 10 });
                    if (position.Y > 700)
                        position = position - new Vector2(0, 1);
                    else
                    {
                        MovePlayerFlag = false;
                        sceneStartFlag = true;
                    }
                }
            }
            else if (scene == Scene.InGame_Scene2)
            {
                if (MovePlayerFlag)
                {
                    alpha = 255;
                    if (position.Y == 900)
                        animatedTexture.SetFrames(new int[] { 9, 10, 11, 10 });
                    if (position.Y > 750)
                    {
                        animatedTexture.Play();
                        position = position - new Vector2(0, 1);
                    }
                    else
                    {
                        animatedTexture.Pause();
                        MovePlayerFlag = false;
                        sceneStartFlag = true;
                    }
                }
            }
        }
        #endregion

        #region ��O�Ɉړ�
        public void Disapear()
        {
            position = new Vector2(610, 900);
        }
        #endregion

        #region �e���|�[�g
        public void CheckTeleport()
        {
            if (position.Y <= 300)
            {
                isTeleport = true;
                if (alpha >= 0)
                    alpha -= 5;
            }
        }
        #endregion

        #region �~�Ɛ��̂����蔻��p
        private bool CircleLineCollisionFunction(Vector2 Center, float radius, Vector2 LineSt, Vector2 LineEd)
        {
            Vector2 AB = LineEd - LineSt;
            Vector2 AP = Center - LineSt;

            float D = Math.Abs(AB.X * AP.Y - AB.Y * AP.X);
            float L = AB.Length();

            float H = D / L;

            if (H <= radius)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Npc�Ƃ̐ڐG����
        public void CheckRecEncounter(Rectangle Npcrect,ref bool NpcHit,string NpcName,ref int NpcCount)
        {
            Rectangle player_Rect;
            player_Rect = new Rectangle((int)position.X, (int)position.Y, 32, 32);

            //�v���C���[��Npc�̐����`���ڐG����Ƃ�
            if (Npcrect.Intersects(player_Rect))
            {
                if (NpcName == "BlackSanta")
                {
                    //����̕����L�[�𖳌��ɂ���
                    UpKeyEnable = false;
                    RightKeyEnable = false;
                }
                if (NpcName == "Santa")
                {
                    //����̕����L�[�𖳌��ɂ���
                    LeftKeyEnable = false;
                }
                //H�L�[�������Ƃ��A�񐔃J�E���g�𑝂₵�A�Θb�E�B���h�E�Y���J��
                if (InputManager.IsJustKeyDown(Keys.H) && !hitAndEnter)
                {
                    hitAndEnter = true;
                    NpcHit = true;
                    NpcCount++;
                }
            }
                //���ꂽ�Ƃ��A�����L�[��L���ɂ���
            else
            {
                if (NpcName == "BlackSanta")
                {
                    //����̕����L�[�𖳌��ɂ���
                    UpKeyEnable = true;
                    RightKeyEnable = true;
                }
                if (NpcName == "Santa")
                {
                    //����̕����L�[�𖳌��ɂ���
                    LeftKeyEnable = true;
                }
                hitAndEnter = false;
                NpcHit = false;
            }
        }
        #endregion

        #endregion

    }
}
