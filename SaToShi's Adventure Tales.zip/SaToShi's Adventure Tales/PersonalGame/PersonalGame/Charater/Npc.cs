using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;
namespace PersonalGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Npc : Microsoft.Xna.Framework.DrawableGameComponent
    {
        //�}�l�[�W���ϐ�
        public GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        ContentManager content;

        /// <summary>
        /// Npc�̃e�N�X�`���A�j��
        /// </summary>
        public AnimatedTexture2D animatedTexture;

        /// <summary>
        /// Npc�̃e�N�X�`��
        /// </summary>
        public Texture2D Img;


        /// <summary>
        /// Npc�̖��O
        /// </summary>
        public String Name
        {
            set { name = value; }
            get { return name; }
        }
        private String name;

        /// <summary>
        /// Npc�̃|�W�V����
        /// </summary>
        public Vector2 Position
        {
            set { position = value; }
            get { return position; }
        }
        private Vector2 position;

        /// <summary>
        /// Npc�̂����蔻��p�����`
        /// </summary>
        public Rectangle rectangle;

        /// <summary>
        /// Npc�̃��l
        /// </summary>
        public int Alpha
        {
            set { alpha = value; }
            get { return alpha; }
        }
        private int alpha;

        /// <summary>
        /// �Z���t
        /// </summary>
        public bool hitAndEnter;

        public string selif;
        public string selif2;

        /*�Θb�񐔃J�E���g*/
        public int encounterCount;


        /*�E�B���h�E�e�N�X�`��*/
        public Texture2D selifWindowsImg;

        /*�Z���t�̃t�H���g*/
        public SpriteFont selifFont;
        public SpriteFont selifFont2;

        /*�Z���t�E�B���h�E�Y�̊J�t���O*/
        public bool showSelifWindows;
        public bool showSelifWindows2;

        /// <summary>
        /// �v���C���[�̑I���t���O
        /// </summary>
        public bool yesSelected;
        public bool noSelected;
        public bool giveNoneSelected;

        public Npc(Game game)
            : base(game)
        {
            this.content = game.Content;
        }

        #region ������
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            InitializeCoodinateAndSelif();
            base.Initialize();
        }
        private void InitializeCoodinateAndSelif()
        {
            if (name == "Santa")
            {
                //�Z���t�̏�����
                selif = "�T�g�V�I" + "\n" + "�o�i�i��炦�I";
                selif2 = "�ӂ��͂�...";
                //��O�ɂ���悤�A�|�W�V����������������
                position = new Vector2(-100, -100);
                alpha = 50;
            }
            if (name == "BlackSanta")
            {
                //�Z���t�̏�����
                selif = "�X�P�[�g�{�[�g�͂���" + "\n" + "���������܂����H";
                selif2 = "���x����";
                //��O�ɂ���悤�A�|�W�V����������������
                position = new Vector2(-100, -100);
                alpha = 50;
            }
            if (name == "Boss")
            {   //��O�ɂ���悤�A�|�W�V����������������
                position = new Vector2(-2630, -2400);
                alpha = 50;
                yesSelected = false;
                noSelected = false;
            }

        }

        #endregion

        #region �R���e���c�̓ǂݍ���
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //�Z���t�E�B���h�E�̓ǂݍ���
            selifWindowsImg = content.Load<Texture2D>("SerifWindow");

            //�t�H���g�̓ǂݍ���
            selifFont = content.Load<SpriteFont>("SelifFont");
            selifFont2 = content.Load<SpriteFont>("SelifFont2");

            base.LoadContent();
        }
        #endregion

        #region �X�V
        public override void Update(GameTime gameTime)
        {
            if (animatedTexture != null)
                //�e�N�X�`���A�j���V���[���̍X�V����
                animatedTexture.Update((float)gameTime.ElapsedGameTime.TotalSeconds);

            //�����蔻��p�����`�̍��W�X�V
            if (name == "Santa")
            {
                rectangle = new Rectangle((int)position.X, (int)position.Y + 10, 60, 80);
            }
            if (name == "BlackSanta")
            {
                rectangle = new Rectangle((int)position.X-30, (int)position.Y + 10, 60, 40);
            }
            base.Update(gameTime);
        }
        #endregion

        #region ���\�b�h
        public void ShowUp()
        {
            if (name == "Santa")
            {
                position = new Vector2(230, 410);
                if (alpha < 255)
                    alpha++;
            }
            if (name == "BlackSanta")
            {
                position = new Vector2(1220, 650);
                if (alpha < 255)
                    alpha++;
            }
            if (name == "Boss")
            {
                position = new Vector2(500, 500);
                //showSelifWindows = true;
                if (alpha < 255)
                    alpha++;
            }
        }
        public void CheckSelifShow()
        {
            if (hitAndEnter)
            {
                if (encounterCount == 1)
                    showSelifWindows = true;
                else if (encounterCount > 1)
                {
                    showSelifWindows = false;
                    showSelifWindows2 = true;
                }
            }
            else
            {
                showSelifWindows = false;
                showSelifWindows2 = false;
            }
        }
        public void Disapear()
        {
            if (name == "Santa")
                position = new Vector2(-100, -100);
            if (name == "BlackSanta")
                position = new Vector2(-100, -100);
        }
        #endregion

        #region �`��
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            if (name == "Santa" && showSelifWindows)
            {
                spriteBatch.Draw(selifWindowsImg, new Rectangle(150, 460, 150, 100), new Color(255, 255, 255, 100));
                spriteBatch.DrawString(selifFont, "�T���^", new Vector2(235, 475), Color.Black);
                spriteBatch.DrawString(selifFont2, selif, new Vector2(170, 500), Color.White);
            }
            if (name == "Santa" && showSelifWindows2)
            {
                spriteBatch.Draw(selifWindowsImg, new Rectangle(150, 460, 150, 100), new Color(255, 255, 255, 100));
                spriteBatch.DrawString(selifFont, "�T���^", new Vector2(235, 475), Color.Black);
                spriteBatch.DrawString(selifFont2, selif2, new Vector2(170, 500), Color.White);

            }
            //position = new Vector2(1220, 650);
            if (name == "BlackSanta" && showSelifWindows)
            {
                spriteBatch.Draw(selifWindowsImg, new Rectangle(1080, 700, 180, 120), new Color(255, 255, 255, 100));
                spriteBatch.DrawString(selifFont, "���T���^", new Vector2(1180, 720), Color.Black);
                spriteBatch.DrawString(selifFont2, selif, new Vector2(1105, 755), Color.White);
            }
            if (name == "BlackSanta" && showSelifWindows2)
            {
                spriteBatch.Draw(selifWindowsImg, new Rectangle(1080, 700, 180, 120), new Color(255, 255, 255, 100));
                spriteBatch.DrawString(selifFont, "���T���^", new Vector2(1180, 720), Color.Black);
                spriteBatch.DrawString(selifFont2, selif2, new Vector2(1135, 760), Color.White);

            }
            if (name == "Boss" && showSelifWindows)
            {

                spriteBatch.Draw(selifWindowsImg,
new Vector2(500, 400), null, Color.White,
MathHelper.ToRadians(180), new Vector2(500, 400),
0.30f, SpriteEffects.FlipHorizontally, 0.0f);
                spriteBatch.DrawString(selifFont, "�o�i�i��D������", new Vector2(450, 465), Color.Black, MathHelper.ToRadians(0), Vector2.Zero, 1.1f, SpriteEffects.None, 0.0f);

                if (!yesSelected && !noSelected && !giveNoneSelected)
                {
                    spriteBatch.DrawString(selifFont, "�o�i�i���悱���I", new Vector2(300, 380), Color.White, MathHelper.ToRadians(0), Vector2.Zero, 2.0f, SpriteEffects.None, 0.0f);
                }
                if (yesSelected && !noSelected && !giveNoneSelected)
                {
                    spriteBatch.DrawString(selifFont, "�n�n�n�A�p�ς݂̋��͏�\n���Ă��炤���I", new Vector2(250, 370), Color.White, MathHelper.ToRadians(0), Vector2.Zero, 2.0f, SpriteEffects.None, 0.0f);
                }
                if (!yesSelected && noSelected && !giveNoneSelected)
                {
                    spriteBatch.DrawString(selifFont, "����Ȃ��Ȃ�A�͂�����\n      �D���܂ł��I", new Vector2(265, 370), Color.White, MathHelper.ToRadians(0), Vector2.Zero, 2.0f, SpriteEffects.None, 0.0f);
                }
                if (giveNoneSelected && !yesSelected && !noSelected)
                {
                    spriteBatch.DrawString(selifFont, "���l���x���悤�Ȑ^����\n���āI�Ԃ���΂��I", new Vector2(250, 370), Color.White, MathHelper.ToRadians(0), Vector2.Zero, 2.0f, SpriteEffects.None, 0.0f);
                }
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }

        #endregion
    }
}
