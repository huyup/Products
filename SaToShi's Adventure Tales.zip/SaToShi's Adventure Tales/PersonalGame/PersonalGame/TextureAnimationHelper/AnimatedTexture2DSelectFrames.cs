﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace PersonalGame
{

    /// <summary>
    /// 
    /// </summary>
    public class AnimatedTexture2DSelectFrames:AnimatedTexture2D
    {

        #region Fields

        /// <summary>
        /// 
        /// </summary>
        private int[] FrameNumberArray;

        /// <summary>
        /// 
        /// </summary>
        private int CurrentNumberOfArray;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// 
        /// </summary>
        /// <param name="texture"></param>
        /// <param name="frameRow"></param>
        /// <param name="frameColumn"></param>
        /// <param name="framePerSecond"></param>
        public AnimatedTexture2DSelectFrames(Texture2D texture, int frameRow, int frameColumn, int framePerSecond)
            : this(texture, frameRow, frameColumn, framePerSecond, new int[]{})
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="texture"></param>
        /// <param name="frameRow"></param>
        /// <param name="frameColumn"></param>
        /// <param name="framePerSecond"></param>
        /// <param name="frameNumberList"></param>
        public AnimatedTexture2DSelectFrames(Texture2D texture, int frameRow, int frameColumn, int framePerSecond, List<int> frameNumbers)
            : this(texture,frameRow,frameColumn,framePerSecond,frameNumbers.ToArray())
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="texture"></param>
        /// <param name="frameRow"></param>
        /// <param name="frameColumn"></param>
        /// <param name="framePerSecond"></param>
        /// <param name="startFrameNumber"></param>
        /// <param name="endFrameNumber"></param>
        public AnimatedTexture2DSelectFrames(Texture2D texture, int frameRow, int frameColumn, int framePerSecond, int startFrameNumber, int endFrameNumber)
            : base(texture, frameRow, frameColumn, framePerSecond)
        {

            int margin = endFrameNumber - startFrameNumber;
            
            this.FrameNumberArray = new int[margin + 1];

            for (int i = 0; i <= margin; i++)
                this.FrameNumberArray[i] = startFrameNumber + i;
            
            OptimizeFrameNumbers(ref FrameNumberArray);

            //再生番号などの初期化
            this.Reset();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="texture"></param>
        /// <param name="frameRow"></param>
        /// <param name="frameColumn"></param>
        /// <param name="framePerSecond"></param>
        /// <param name="frameNumberArray"></param>
        public AnimatedTexture2DSelectFrames(Texture2D texture, int frameRow, int frameColumn, int framePerSecond, int[] frameNumbers)
            : base(texture, frameRow, frameColumn, framePerSecond)
        {

            //指定されていれば、再生するコマとして設定
            if (frameNumbers.Length != 0)
            {
                this.FrameNumberArray = frameNumbers;
                OptimizeFrameNumbers(ref FrameNumberArray);
            }
            //指定されていなければ、全てを再生するコマとして設定
            else
            {
                this.FrameNumberArray = new int[frameRow * frameColumn];
                for (int i = 0; i < FrameNumberArray.Length; i++)
                    FrameNumberArray[i] = i;
            }

            //再生番号などの初期化
            this.Reset();
        }

        #endregion Constructors

        #region Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="totalElapsedSecond"></param>
        public override void Update(float totalElapsedSecond)
        {
            //▼一時停止中ならUpdateを実行しない
            if (Paused)
                return;

            //合計時間を加算
            TotalElapsedSecond += totalElapsedSecond;

            //合計時間が1フレームあたりの時間を超えたら
            if (TotalElapsedSecond > SecondPerFrame)
            {
                
                //フレームを次のフレームへ
                CurrentNumberOfArray++;
                CurrentNumberOfArray = CurrentNumberOfArray % FrameNumberArray.Length;
                currentFrame = FrameNumberArray[CurrentNumberOfArray];

                //合計時間から、フレームあたりの時間を引く
                TotalElapsedSecond -= SecondPerFrame;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Reset()
        {
            this.currentFrame = FrameNumberArray[0];
            this.CurrentNumberOfArray = 0;
            this.TotalElapsedSecond = 0;
        }

        /// <summary>
        /// 
        /// </summary>
        public int[] GetFrames()
        {
            return this.FrameNumberArray;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="frameNumbers"></param>
        public void SetFrames(int[] frameNumbers)
        {
            this.FrameNumberArray = frameNumbers;
            OptimizeFrameNumbers(ref FrameNumberArray);
            this.Reset();
        }

        /// <summary>
        /// 複数のframeNumberを範囲内に収まるように調整します。
        /// </summary>
        /// <param name="frameNumbers"></param>
        private void OptimizeFrameNumbers(ref int[] frameNumbers)
        {
            for (int i = 0; i < frameNumbers.Length; i++)
                frameNumbers[i] = OptimizeFrameNumber(frameNumbers[i]);
        }

        #endregion Methods

    }
}
