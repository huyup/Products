﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace PersonalGame
{

    /// <summary>
    /// 
    /// </summary>
    public class AnimatedTexture2D
    {

        #region Fields

        /// <summary>
        /// アニメーションに対応する全てのフレームが1つになったテクスチャ
        /// </summary>
        private Texture2D texture;

        /// <summary>
        /// フレーム数
        /// </summary>
        protected int FrameCount;

        /// <summary>
        /// フレームの行数
        /// </summary>
        private int FrameRow;

        /// <summary>
        /// フレームの列数
        /// </summary>
        private int FrameColumn;

        /// <summary>
        /// テクスチャ中の1フレームに対応する領域の幅
        /// </summary>
        private int frameWidth;

        /// <summary>
        /// テクスチャ中の1フレームに対応する領域の高さ
        /// </summary>
        private int frameHeight;

        /// <summary>
        /// 1フレーム当たりに要する時間
        /// </summary>
        protected float SecondPerFrame;

        /// <summary>
        /// 現在のフレーム
        /// </summary>
        protected int currentFrame;

        /// <summary>
        /// 扱うアニメーション中の進行時間
        /// </summary>
        protected float TotalElapsedSecond;

        /// <summary>
        /// アニメーションの停止設定
        /// </summary>
        protected bool Paused;
        /// <summary>
        /// 停止中かどうかを返す.
        /// </summary>
        public bool IsPaused
        {
            get { return Paused; }
        }

        #endregion Fields

        #region Constructor

        /// <summary>
        /// 
        /// </summary>
        /// <param name="texture"></param>
        /// <param name="frameRow"></param>
        /// <param name="frameColumn"></param>
        /// <param name="framePerSecond"></param>
        public AnimatedTexture2D(Texture2D texture, int frameRow, int frameColumn, int framePerSecond)
        {
            //テクスチャを保持
            this.texture = texture;

            //1秒あたりに何フレーム表示するか、から1フレームあたり何秒表示するか、を逆算する
            this.SecondPerFrame = (float)1 / framePerSecond;

            this.FrameColumn = frameColumn;
            this.FrameRow = frameRow;

            //テクスチャに占める1つのフレームの幅は、テクスチャの幅/フレーム数で求められる
            this.frameWidth = texture.Width / frameColumn;
            this.frameHeight = texture.Height / frameRow;
            this.FrameCount = frameColumn * frameRow;

            //初期化
            this.currentFrame = 0;
            this.TotalElapsedSecond = 0;
            this.Paused = false;
        }

        #endregion Constructor

        /// <summary>
        /// 
        /// </summary>
        /// <param name="totalElapsedSecond"></param>
        public virtual void Update(float totalElapsedSecond)
        {
            //一時停止中ならUpdateを実行しない
            if (Paused)
                return;

            //合計時間を加算
            TotalElapsedSecond += totalElapsedSecond;

            //合計時間が1フレームあたりの時間を超えたら
            if (TotalElapsedSecond > SecondPerFrame)
            {
                //フレームを次のフレームへ
                currentFrame++;
                //フレームの値は、0~フレーム数で調整する(ifはなるべく使わない)
                currentFrame = currentFrame % FrameCount;
                //合計時間から、フレームあたりの時間を引く
                TotalElapsedSecond -= SecondPerFrame;
            }

        }

        #region Draw

        /// <summary>
        /// 
        /// </summary>
        /// <param name="batch"></param>
        /// <param name="screenPos"></param>
        public void DrawFrame(SpriteBatch spriteBatch, Vector2 position)
        {
            DrawFrame(spriteBatch, this.currentFrame, position, Color.White, 0, Vector2.Zero, 1, SpriteEffects.None, 0);
        }
        public void DrawFrame(SpriteBatch spriteBatch, Vector2 position,float scale, SpriteEffects spriteEffects)
        {
            DrawFrame(spriteBatch, this.currentFrame, position, Color.White, 0, Vector2.Zero, scale, spriteEffects, 0);
        }
        public void DrawFrame(SpriteBatch spriteBatch, Vector2 position, float scale, SpriteEffects spriteEffects, int alpha)
        {
            DrawFrame(spriteBatch, this.currentFrame, position, new Color(alpha, alpha, alpha, alpha), 0, Vector2.Zero, scale, spriteEffects, 0);
        }
        public void DrawFrame(SpriteBatch spriteBatch, Vector2 position,float scale)
        {
            DrawFrame(spriteBatch, this.currentFrame, position, Color.White, 0, Vector2.Zero, scale, SpriteEffects.None, 0);
        }
        public void DrawFrame(SpriteBatch spriteBatch, Vector2 position, float scale,int alpha)
        {
            DrawFrame(spriteBatch, this.currentFrame, position, new Color(alpha, alpha, alpha, alpha), 0, Vector2.Zero, scale, SpriteEffects.None, 0);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="spriteBatch"></param>
        /// <param name="frame"></param>
        /// <param name="position"></param>
        /// <param name="color"></param>
        /// <param name="rotation"></param>
        /// <param name="origin"></param>
        /// <param name="scale"></param>
        /// <param name="spriteEffects"></param>
        /// <param name="layerDepth"></param>
        public void DrawFrame(SpriteBatch spriteBatch, int frame, Vector2 position, Color color,
            float rotation, Vector2 origin, float scale, SpriteEffects spriteEffects, float layerDepth)
        {

            Rectangle sourceRect = new Rectangle(
                frameWidth * (frame % FrameColumn),//左上
                frameHeight * (frame / FrameColumn),//左上(ここが厄介)
                frameWidth,//幅
                frameHeight//高さ
                );

            spriteBatch.Draw(texture, position, sourceRect, color, rotation, origin, scale, spriteEffects, layerDepth);
        }

        #endregion Draw

        #region Control

        /// <summary>
        /// フレームと再生時間を初期化する．
        /// </summary>
        public virtual void Reset()
        {
            currentFrame = 0;
            TotalElapsedSecond = 0f;
        }

        /// <summary>
        /// 停止してフレームと再生時間を初期化する．
        /// </summary>
        public void Stop()
        {
            Pause();
            Reset();
        }

        /// <summary>
        /// 一時停止状態を解除する．
        /// </summary>
        public void Play()
        {
            this.Paused = false;
        }

        /// <summary>
        /// 一時停止状態にする．
        /// </summary>
        public void Pause()
        {
            this.Paused = true;
        }

        #endregion Control

        #region Getter & Setter

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int GetCurrentFrameNumber()
        {
            return this.currentFrame;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int GetFrameCount()
        {
            return this.FrameCount;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public float GetFramePerSecond()
        {
            return 1 / SecondPerFrame;
        }

        /// <summary>
        /// FPSを指定して再生速度を変更する
        /// </summary>
        /// <param name="framePerSecond"></param>
        public void SetFramePerSecond(float framePerSecond)
        {
            this.SecondPerFrame = 1 / framePerSecond;
        }

        /// <summary>
        /// 現在のフレームを設定する
        /// </summary>
        /// <param name="frameNumber"></param>
        public void SetCurrentFrameNumber(int frameNumber)
        {
            this.currentFrame = OptimizeFrameNumber(frameNumber);
        }

        /// <summary>
        /// フレームあたりの高さ
        /// </summary>
        /// <returns></returns>
        public int FrameHeight
        {
            get
            {
                return this.frameHeight;
            }
        }

        /// <summary>
        /// フレームあたりの幅
        /// </summary>
        /// <returns></returns>
        public int FrameWidth
        {
            get { return this.frameWidth; }
        }

        #endregion Get & Setter

        /// <summary>
        /// 引数frameNumberを0～FrameCountの範囲内に納めて返します。
        /// </summary>
        /// <param name="frameNumber"></param>
        /// <returns></returns>
        protected int OptimizeFrameNumber(int frameNumber)
        {
            if (frameNumber < 0)
                return 0;

            if (frameNumber >= this.FrameCount)
                return FrameCount - 1;

            return frameNumber;
        }

    }
}
