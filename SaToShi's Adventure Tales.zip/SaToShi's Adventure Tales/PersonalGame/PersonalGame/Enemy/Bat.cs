using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;
public enum BatType
{
    Type1A,
    Type1B,
    Type2,
}
namespace PersonalGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Bat : Microsoft.Xna.Framework.DrawableGameComponent
    {
        #region �t�B�[���h
        //�V�X�e���t�B�[���h
        private SpriteBatch spriteBatch;
        private ContentManager content;

        //���\�[�X
        public AnimatedTexture2D batA;
        private Texture2D TestRecImg;

        //�ړ���
        /*�ړ��\�ȍő吔*/
        private Vector2[] movePoint = new Vector2[6];
        public bool[] moveEnable = new bool[6];
        /*���݂̈ړ���*/
        public int PointCount;

        //�ړ����x
        public int x;
        public int y;

        //����
        public float angle = 0;

        //�ړ��R���g���[��
        public bool useMove = true;

        //���ԑ҂��R���g���[��
        public bool moveNextBat = false;
        public bool lastBatMoveEnd = false;
        public bool comeBackEnable = false;
        //�U���R���g���[��
        public bool attackEnable = false;

        //�z���R���g���[��
        public bool drainHitEnable = false;

        //�|�W�V����
        public Vector2 Pos;
        public Vector2 prevPos;

        //�`��R���g���[��
        public bool drawEnable = false;

        //����
        public Direction direction;

        //�A���t�@�l
        public int alpha=255;

        //�^�C�v
        public BatType type;

        //������p
        public Rectangle rectangle;

        //�������J�n����
        private DateTime disapear_StartTime = DateTime.MaxValue;
        private bool onceflag_DisaperTime = true;
        #endregion

        #region �R���X�g���N�^
        public Bat(Game game)
            : base(game)
        {
            content = new ContentManager(game.Services);
        }
        #endregion

        #region ������
        public override void Initialize()
        {
            //�C���v�b�g�}�l�[�W���N���X�̏�����
            InputManager.Initialize();

            base.Initialize();
        }
        #endregion

        #region �R���e���c�̓ǂݍ��ݏ���
        protected override void LoadContent()
        {
            // �V�K�� SpriteBatch ���쐬���܂��B����̓e�N�X�`���[�̕`��Ɏg�p�ł��܂��B
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //��
            batA = new AnimatedTexture2D(content.Load<Texture2D>(@"Content\Scene3\bat_2"), 1, 3, 6);

            //������p
            TestRecImg = content.Load<Texture2D>(@"Content\Scene3\TESTRect");
            base.LoadContent();
        }
        #endregion

        #region �R���e���c�̉������
        protected override void UnloadContent()
        {
            base.UnloadContent();
        }
        #endregion

        #region �Q�[���̍X�V����
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here

            if (InputManager.IsKeyDown(Keys.Escape))
                Game.Exit();

            //�����蔻��X�V
            rectangle = new Rectangle((int)Pos.X + 20 * (int)1.8,
        (int)Pos.Y + 30 * (int)1.8,
        20 * (int)1.8,
        30 * (int)1.8);

            //�A�j���[�V�����X�V
            batA.Play();
            batA.Update((float)gameTime.ElapsedGameTime.TotalSeconds);
            base.Update(gameTime);
        }

        #endregion

        #region ���\�b�h
        /// <summary>
        /// �ړ�/�ǐ�
        /// </summary>
        public void MoveToPoint(Vector2 Point, int count, ref Bat[] bat)
        {
            if (useMove)
            {
                for (int i = 0; i < moveEnable.GetLength(0); i++)
                {
                    //�|�W�V���������L�^
                    if (bat[count].moveEnable[i])
                    {
                        bat[count].movePoint[i] = Point;
                        bat[count].PointCount = i;
                        #region ���x�ɂ��킹�āA�ʒu�𒲐�����
                        if ((int)bat[count].movePoint[i].X % 4 == 0)
                        {
                            bat[count].x = (int)bat[count].movePoint[i].X;
                        }
                        else if ((int)bat[count].movePoint[i].X % 4 == 3)
                        {
                            bat[count].x = (int)bat[count].movePoint[i].X + 1;
                        }
                        else if ((int)movePoint[i].X % 4 == 2)
                        {
                            bat[count].x = (int)bat[count].movePoint[i].X + 2;
                        }
                        else if ((int)bat[count].movePoint[i].X % 4 == 1)
                        {
                            bat[count].x = (int)bat[count].movePoint[i].X + 3;
                        }
                        if ((int)bat[count].movePoint[i].Y % 4 == 0)
                        {
                            bat[count].y = (int)bat[count].movePoint[i].Y;
                        }
                        else if ((int)bat[count].movePoint[i].Y % 4 == 3)
                        {
                            bat[count].y = (int)bat[count].movePoint[i].Y + 1;
                        }
                        else if ((int)bat[count].movePoint[i].Y % 4 == 2)
                        {
                            bat[count].y = (int)bat[count].movePoint[i].Y + 2;
                        }
                        else if ((int)bat[count].movePoint[i].Y % 4 == 1)
                        {
                            bat[count].y = (int)bat[count].movePoint[i].Y + 3;
                        }
                        #endregion
                        bat[count].moveEnable[i] = false;
                    }
                    //����������A���̃t���O���J��
                    if (bat[count].Pos.X == bat[count].x && bat[count].Pos.Y == bat[count].y)
                    {
                        if (bat[count].PointCount + 1 < bat[count].moveEnable.GetLength(0))
                        {
                            bat[count].moveEnable[PointCount] = false;
                            bat[count].moveEnable[PointCount + 1] = true;
                        }
                    }
                }
                //�L�^�����|�W�V�����Ɍ����킹��
                if (bat[count].x > (int)bat[count].Pos.X)
                {
                    if ((int)bat[count].Pos.X % 4 == 0)
                    {
                        bat[count].Pos.X += 4;
                    }
                    else if ((int)bat[count].Pos.X % 4 == 1)
                    {
                        bat[count].Pos.X += 3;
                    }
                    else if ((int)bat[count].Pos.X % 4 == 2)
                    {
                        bat[count].Pos.X += 2;
                    }
                    else if ((int)bat[count].Pos.X % 4 == 3)
                    {
                        bat[count].Pos.X += 1;
                    }
                    bat[count].direction = Direction.Right;
                }
                else if (bat[count].x < (int)bat[count].Pos.X)
                {
                    bat[count].Pos.X -= 4;
                    bat[count].direction = Direction.Left;
                }
                else
                {
                    bat[count].Pos.X = bat[count].x;
                    bat[count].direction = Direction.Right;
                }
                if (bat[count].y > (int)bat[count].Pos.Y)
                {
                    if ((int)bat[count].Pos.Y % 4 == 0)
                    {
                        bat[count].Pos.Y += 4;
                    }
                    else if ((int)bat[count].Pos.Y % 4 == 1)
                    {
                        bat[count].Pos.Y += 3;
                    }
                    else if ((int)bat[count].Pos.Y % 4 == 2)
                    {
                        bat[count].Pos.Y += 2;
                    }
                    else if ((int)bat[count].Pos.Y % 4 == 3)
                    {
                        bat[count].Pos.Y += 1;
                    }
                }
                else if (bat[count].y < (int)bat[count].Pos.Y)
                {
                    bat[count].Pos.Y -= 4;
                }
                else
                {
                    bat[count].Pos.Y = y;
                }
            }
        }

        /// <summary>
        /// �t���O���Z�b�g
        /// </summary>
        public void ResetFlag()
        {
            for (int i = 0; i < moveEnable.GetLength(0); i++)
            {
                if (i == 0)
                {
                    moveEnable[0] = true;
                }
                else
                {
                    moveEnable[i] = false;
                }
                movePoint[i] = Vector2.Zero;
            }
            useMove = true;
            PointCount = 0;
            drainHitEnable = false;
        }

        /// <summary>
        /// ��_���[�W
        /// </summary>
        public void CheckSwordHit(Rectangle swordRec, ref int hp, ref bool swordHitEnable, bool attackEnable)
        {
            //�U����Ԃ̂Ƃ�
            if (attackEnable && swordHitEnable)
            {
                //���ɐU���
                if (swordRec.Intersects(rectangle) || swordRec.Contains(rectangle))
                {
                    //hp������������
                    hp -= 5;
                    drawEnable = false;
                    //XXX:�o�O���o�邩��
                    PointCount = 5;
                    //swordHitEnable = false;
                }
            }
        }
        public void CheckBombHit(Rectangle bombRec, ref int hp, ref bool bombHitEnable, bool explosionEnable, bool useBanana)
        {
            if (bombHitEnable && !explosionEnable && useBanana)
            {
                if (bombRec.Intersects(rectangle) || bombRec.Contains(rectangle))
                {
                    hp -= 5;
                    drawEnable = false;
                    //XXX:�o�O���o�邩��
                    PointCount = 5;
                }
            }
        }
        public void CheckSkateBoardHit(Rectangle skateBoardRec, ref int hp, ref bool SB_hitEnable, bool useSkateBoard, bool inroopCircle)
        {
            if (useSkateBoard && !inroopCircle && SB_hitEnable)
            {
                if (skateBoardRec.Intersects(rectangle))
                {
                    hp -= 5;
                    drawEnable = false;
                    //XXX:�o�O���o�邩��
                    PointCount = 5;
                }
            }
        }
        public void RevivalBat(BatType batType)
        {
            //�������Ƃ��A���Ԃ����L�^������
            if (batType == BatType.Type1A)
            {
                if (drawEnable == false && onceflag_DisaperTime)
                {
                    disapear_StartTime = DateTime.Now;
                    onceflag_DisaperTime = false;
                    alpha = 0;
                }
                //�i�������Ƃ��̂݁j1.0�b��@������x�����
                if ((DateTime.Now - disapear_StartTime).TotalSeconds > 5.0&&!drawEnable)
                {
                    drawEnable = true;
                    onceflag_DisaperTime = true;
                }
                if ((DateTime.Now - disapear_StartTime).TotalSeconds < 5.0 && !drawEnable)
                {
                    alpha += 1;
                }
            }
            //�������Ƃ��A���Ԃ����L�^������
            if (batType == BatType.Type1B)
            {
                if (drawEnable == false && onceflag_DisaperTime)
                {
                    disapear_StartTime = DateTime.Now;
                    onceflag_DisaperTime = false;
                    alpha = 0;
                }
                //�i�������Ƃ��̂݁j1.0�b��@������x�����
                if ((DateTime.Now - disapear_StartTime).TotalSeconds > 3.0 && !drawEnable)
                {
                    drawEnable = true;
                    onceflag_DisaperTime = true;
                }
                if ((DateTime.Now - disapear_StartTime).TotalSeconds < 3.0 && !drawEnable)
                {
                    alpha += 3;
                }
            }
        }
        #endregion

        #region �Q�[���̕`�揈��
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            //spriteBatch.Draw(TestRecImg, rectangle, Color.White);
            spriteBatch.End();
            base.Draw(gameTime);
        }
        #endregion
    }
}
