﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;
namespace PersonalGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Boss : Microsoft.Xna.Framework.DrawableGameComponent
    {
        //マネージャ変数
        public GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        ContentManager content;
        #region フィールド

        //バトルスタートのフラグ
        public bool battleStart;
        private bool onceFlag_recordMovePoint = true;
        private bool movePointEnable;
        #region 属性
        /// <summary>
        /// 属性
        /// </summary>
        //テクスチャ
        private Texture2D Img;
        private Texture2D Img_Teleport;
        private Texture2D Img_Change;
        private Texture2D TestRecImg;
        private Texture2D TestLineImg;
        private Texture2D HpImg;
        private Texture2D BananaBombImg;
        private AnimatedTexture2D AnimatedImg_Change;
        private AnimatedTexture2D AnimatedImg_formChange;
        public AnimatedTexture2D AnimatedImg_RaserAttack;
        private Texture2D BossCore1;
        private Texture2D BossCore2;
        private Texture2D BossCore2_2;
        private Texture2D BossCore2_3;
        private Texture2D BossCore2_4;


        /// <summary>
        /// 軸方向の速度＆＆加速度
        /// </summary>
        float VX = 0;
        float Accel_X = 0;
        float VY = 0;
        float Accel_Y = 0;

        //判定用正方形
        public Rectangle rectangle0;
        public Rectangle rectangle1;
        public Rectangle rectangle2;
        public Rectangle rectangle3;
        public Rectangle rectangle4;
        public Rectangle rectangle5;

        //被ダメージ
        public bool hitEnable0 = true;
        public bool hitEnable1 = true;
        public bool hitEnable2 = true;
        public bool hitEnable3 = true;
        public bool hitEnable4 = true;
        public bool hitEnable5 = true;

        public int hitCount = 0;

        //hp
        public int hpLength;

        //描画チェック
        public bool DrawEnable = true;

        //α値
        public int alpha = 255;

        //ポジション
        public Vector2 Position;

        //向き
        public Direction direction;
        #endregion

        #region 攻撃パターン
        /// <summary>
        /// 攻撃
        /// </summary>
        //攻撃可能かどうか
        public bool attackEnable = true;
        //乱数を使って攻撃パターんを決める
        public int randomCount;
        //出た乱数、重複チェック
        public int randomNow;

        /// <summary>
        /// 分身攻撃
        /// </summary>
        //蝙蝠
        private const int batCount_2 = 10;
        public Bat[] bat2 = new Bat[batCount_2];
        //使用コントロール
        public bool useAvatarAttack = false;
        public bool useAvatarAttack2 = false;
        //開始コントロール
        public bool avatarAttackEnable = false;
        public bool avatarAttackEnable2 = false;
        //帰ってきた蝙蝠の数
        public int batcount_ComeBack = 0;
        //吸血できる最大値
        private int drainMaxHp = 25;
        private int drainHpCount = 0;

        /// <summary>
        /// 変形攻撃
        /// </summary>
        //使ったどうか
        public bool useChangeAttack = false;
        public bool useChangeAttack2 = false;
        //開始したかどうか
        private bool changeAttackEnable = false;
        private bool changeAttackEnable2 = false;
        //壁にぶつかったとき、バナナが落ちる
        private const int itemMaxCount = 3;

        private Vector2[] fallenItemPos = new Vector2[itemMaxCount];
        public Rectangle[] item_Rectangle = new Rectangle[itemMaxCount];

        private float itemVY;
        private float item_Accel_Y;
        private float[] item_Ground_Y = new float[itemMaxCount];

        public bool[] itemEnable = new bool[itemMaxCount];
        public bool itemFallDownEnable = false;
        public bool IsitemFalling = false;

        /// <summary>
        /// 移動攻撃
        /// </summary>
        //開始したかどうかをチェック
        private bool moveAttackEnable = false;
        private bool moveAttackEnable2 = false;

        //使ったかどうかをチェック
        private bool useMoveAttack = false;
        private bool useMoveAttack2 = false;

        //特定の位置に移動する
        private bool movingToA = false;
        private bool movingToB = false;
        private bool movingToC = false;
        #endregion

        /// <summary>
        /// スタン
        /// </summary>
        public bool faintEnable = false;
        public DateTime faintStartTime = DateTime.MinValue;

        /// <summary>
        /// 消える
        /// </summary>
        private bool vanishEnable = false;
        //消えるときの時間
        DateTime vanishStartTime = DateTime.MaxValue;
        //現れるときの時間
        DateTime showUpStartTIme = DateTime.MaxValue;

        /// <summary>
        /// プレイヤーの参照
        /// </summary>
        public Monkey player;

        //test
        private const int batCount = 33;
        public Bat[] bat = new Bat[batCount];

        private DateTime waitTime;
        private bool onceFlag_RecordWaitTime;
        private bool onceFlag_UseCoreMove;

        //右下(950, 400);
        private Vector2 pointA = new Vector2(950, 400);
        private bool moveToPointAEnable;

        //右上(950, 50);
        private Vector2 pointB = new Vector2(950, 50);
        private bool moveToPointBEnable;

        //真ん中上(470, 50);
        private Vector2 pointC = new Vector2(500, 50);
        private bool MoveToPointCEnable;
        //左上(20, 50);
        private Vector2 pointD = new Vector2(20, 50);
        private bool moveToPointDEnable;
        //左下(20, 400);
        private Vector2 pointE = new Vector2(20, 400);
        private bool moveToPointEEnable;

        public bool formChangeEnable = false;
        public bool coreShowUpEnable = false;

        public bool core_BatAttackEnable = false;
        public bool useCore_BatAttack = false;
        private DateTime coreBatAttack_StartTime = DateTime.MaxValue;


        private float accelBat = 0;
        public int coreHp = 4;

        public Rectangle coreRec;
        private bool coreHitEnable;

        public Rectangle laserRec;
        private int laserRecWidth;
        public Vector2 laserPos = new Vector2(0, 170);
        public Vector2 laserPointSt = new Vector2(800, 170);
        public Vector2 laserPointEd = new Vector2(100, 858);
        public bool laserAttackEnable = false;
        public bool useLaserAttack = false;

        private DateTime formChange_StartTime = DateTime.MaxValue;
        #endregion

        #region コンストラクタ
        public Boss(Game game)
            : base(game)
        {
            this.content = Game.Content;
            // TODO: Construct any child components here

            //蝙蝠クラスの初期化
            for (int i = 0; i < bat2.GetLength(0); i++)
            {
                bat2[i] = new Bat(game);
                bat2[i].Initialize();
                bat2[i].type = BatType.Type2;
            }
            //魔王の分身初期化
            for (int i = 0; i < bat.GetLength(0); i++)
            {
                bat[i] = new Bat(game);
                bat[i].Initialize();

                bat[i].drawEnable = true;

                bat[i].angle = i * 30;
                float rad = bat[i].angle * (float)Math.PI * 2 * 0.003f;
                if (i < 11)
                {
                    bat[i].type = BatType.Type1A;
                    bat[i].Pos.X = 650 + (float)Math.Sin(rad) * 150;
                    bat[i].Pos.Y = 300 + (float)Math.Cos(rad) * 150;
                }
                if ((i >= 11 && i < 22))
                {
                    bat[i].type = BatType.Type1A;
                    bat[i].Pos.X = 650 + (float)Math.Sin(rad) * 210;
                    bat[i].Pos.Y = 300 + (float)Math.Cos(rad) * 210;
                }
                if (i < 33 && i >= 22)
                {
                    bat[i].type = BatType.Type1B;
                    bat[i].Pos.X = 650 + (float)Math.Sin(rad) * 100;
                    bat[i].Pos.Y = 300 + (float)Math.Cos(rad) * 100;
                }
            }
        }
        #endregion

        #region 初期化
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            Position = new Vector2(1050, 0);
            direction = Direction.Left;
            hpLength = 1;
            base.Initialize();
        }
        #endregion

        #region コンテンツの読み込み
        protected override void LoadContent()
        {
            this.spriteBatch = new SpriteBatch(GraphicsDevice);

            Img = content.Load<Texture2D>(@"Scene3\Boss_Core");
            Img_Teleport = content.Load<Texture2D>(@"Scene3\BossTeleport");
            Img_Change = content.Load<Texture2D>(@"Scene3\BossChange");

            TestRecImg = content.Load<Texture2D>(@"Scene3\TESTRect");
            TestLineImg = content.Load<Texture2D>(@"Scene3\TESTLine");
            HpImg = content.Load<Texture2D>(@"Scene3\BossHpImg");

            AnimatedImg_Change = new AnimatedTexture2D(content.Load<Texture2D>(@"Scene3\AnimatedChangeImg"), 3, 3, 18);

            BananaBombImg = content.Load<Texture2D>(@"Scene3\BananaBomb");

            BossCore1 = content.Load<Texture2D>(@"Scene3\core");
            BossCore2 = content.Load<Texture2D>(@"Scene3\Core2");
            BossCore2_2 = content.Load<Texture2D>(@"Scene3\Core2_2");
            BossCore2_3 = content.Load<Texture2D>(@"Scene3\Core2_3");
            BossCore2_4 = content.Load<Texture2D>(@"Scene3\Core2_4");

            AnimatedImg_RaserAttack = new AnimatedTexture2D(content.Load<Texture2D>(@"Scene3\laser"), 10, 3, 12);
            AnimatedImg_formChange = new AnimatedTexture2D(content.Load<Texture2D>(@"Scene3\FormChange_AnimatedImg"), 1, 10, 12);
            base.LoadContent();
        }
        #endregion

        #region 廃棄
        protected override void UnloadContent()
        {
            base.UnloadContent();
        }
        #endregion

        #region 更新
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            #region あたり判定の正方形更新
            if (changeAttackEnable || changeAttackEnable2)
            {
                if (direction == Direction.Left)
                {
                    //変身後
                    rectangle0 = Rectangle.Empty;
                    rectangle1 = new Rectangle((int)Position.X + 30, (int)Position.Y + 30, Img.Width * (int)5, Img.Height * (int)3 - 110);
                    rectangle2 = new Rectangle((int)Position.X + 300, (int)Position.Y + 180, Img.Width * (int)2.0 - 30, Img.Height * (int)2.0);
                    rectangle3 = new Rectangle((int)Position.X + 150, (int)Position.Y + 180, Img.Width * (int)2.0 - 50, Img.Height * (int)1.0);
                    rectangle4 = new Rectangle((int)Position.X + 280, (int)Position.Y - 50, Img.Width * (int)2.0 + 50, Img.Height * (int)1.0);
                    rectangle5 = Rectangle.Empty;
                }
                if (direction == Direction.Right)
                {
                    //変身後
                    rectangle0 = Rectangle.Empty;
                    rectangle1 = new Rectangle((int)Position.X + 150, (int)Position.Y + 30, Img.Width * (int)5, Img.Height * (int)3 - 110);
                    rectangle2 = new Rectangle((int)Position.X + 130, (int)Position.Y + 180, Img.Width * (int)2.0 - 30, Img.Height * (int)2.0);
                    rectangle3 = new Rectangle((int)Position.X + 300, (int)Position.Y + 180, Img.Width * (int)2.0 - 50, Img.Height * (int)1.0);
                    rectangle4 = new Rectangle((int)Position.X + 80, (int)Position.Y - 50, Img.Width * (int)2.0 + 50, Img.Height * (int)1.0);
                    rectangle5 = Rectangle.Empty;
                }
            }
            if (!changeAttackEnable && !changeAttackEnable2)
            {
                //変身前
                if (direction == Direction.Right)
                {
                    rectangle1 = new Rectangle((int)Position.X + 120, (int)Position.Y + 70, Img.Width * (int)4.5 - 170, Img.Height * (int)4.5 - 100);
                    if (alpha >= 255)
                    {
                        rectangle0 = new Rectangle((int)Position.X + 50, (int)Position.Y + 160, Img.Width * (int)2.0 - 90, Img.Height * (int)2.0 - 80);
                        rectangle2 = new Rectangle((int)Position.X + 260, (int)Position.Y + 20, Img.Width * (int)2.0 - 80, Img.Height * (int)2.0 - 80);
                        rectangle5 = new Rectangle((int)Position.X + 20, (int)Position.Y + 220, Img.Width * (int)2.0 - 100, Img.Height * (int)2.0 - 100);
                    }
                    else
                    {
                        rectangle0 = Rectangle.Empty;
                        rectangle2 = Rectangle.Empty;
                        rectangle5 = Rectangle.Empty;
                    }
                    rectangle3 = Rectangle.Empty;
                    rectangle4 = Rectangle.Empty;
                }
                if (direction == Direction.Left)
                {
                    rectangle1 = new Rectangle((int)Position.X + 110, (int)Position.Y + 70, Img.Width * (int)4.5 - 180, Img.Height * (int)4.5 - 120);
                    if (alpha >= 255)
                    {
                        rectangle0 = new Rectangle((int)Position.X + 250, (int)Position.Y + 160, Img.Width * (int)2.0 - 90, Img.Height * (int)2.0 - 80);
                        rectangle2 = new Rectangle((int)Position.X + 35, (int)Position.Y + 20, Img.Width * (int)2.0 - 80, Img.Height * (int)2.0 - 80);
                        rectangle5 = new Rectangle((int)Position.X + 300, (int)Position.Y + 220, Img.Width * (int)2.0 - 100, Img.Height * (int)2.0 - 100);
                    }
                    else
                    {
                        rectangle0 = Rectangle.Empty;
                        rectangle2 = Rectangle.Empty;
                        rectangle5 = Rectangle.Empty;
                    }
                    rectangle3 = Rectangle.Empty;
                    rectangle4 = Rectangle.Empty;
                }
            }
            #endregion

            #region 通常状態
            if (!coreShowUpEnable)
            {
                #region 攻撃の使用
                if (useMoveAttack)
                {
                    MoveAttack1();
                }
                if (useMoveAttack2)
                {
                    MoveAttack2();
                }
                if (useChangeAttack)
                {
                    ChangeAttack1();
                }
                if (useChangeAttack2)
                {
                    ChangeAttack2();
                }
                if (useAvatarAttack)
                {
                    AvaterAttack1();
                }
                if (useAvatarAttack2)
                {
                    AvaterAttack2();
                }
                #endregion

                //手下の判定更新
                for (int i = 0; i < bat2.GetLength(0); i++)
                {
                    bat2[i].Update(gameTime);
                }

                //アニメーション再生
                AnimatedImg_Change.Play();
                AnimatedImg_Change.Update((float)gameTime.ElapsedGameTime.TotalSeconds);

                AnimatedImg_formChange.Play();
                AnimatedImg_formChange.Update((float)gameTime.ElapsedGameTime.TotalSeconds);
            }
            #endregion

            if (battleStart&&!coreShowUpEnable)
            {
                ChoicAttackPattern();
            }

            if (hpLength <= 0)
            {
                if (!useChangeAttack && !useChangeAttack2 && !changeAttackEnable && !changeAttackEnable2)
                    Formchange();
            }
            if (coreShowUpEnable)
            {
                CoreBatAttack();
                CoreMovePattern();
                CoreLaserAttack();
            }

            #region コア状態
            if (coreShowUpEnable)
            {
                //hpが0以下だったら、ゲーム勝利
                if (coreHp < 0)
                {
                    Game.Exit();
                }
                //レーザー判定＆＆アニメの更新
                laserRec = new Rectangle((int)laserPos.X, (int)laserPos.Y + 300, laserRecWidth, 368);
                AnimatedImg_RaserAttack.Update((float)gameTime.ElapsedGameTime.TotalSeconds);

                #region コアのhpにより、あたり判定正方形更新
                switch (coreHp)
                {
                    case 4:
                        coreRec = new Rectangle((int)Position.X + 140, (int)Position.Y + 100, Img.Width * (int)2.0 - 10, Img.Height * (int)1.0 + 60);
                        break;
                    case 3:
                        coreRec = new Rectangle((int)Position.X + 140, (int)Position.Y + 100, Img.Width * (int)2.0 - 10, Img.Height * (int)1.0 + 20);
                        break;
                    case 2:
                        coreRec = new Rectangle((int)Position.X + 140, (int)Position.Y + 100, Img.Width * (int)2.0 - 55, Img.Height * (int)1.0 + 20);
                        break;
                    case 1:
                        coreRec = new Rectangle((int)Position.X + 190, (int)Position.Y + 110, Img.Width * (int)2.0 - 110, Img.Height * (int)1.0 - 25);
                        break;
                    default:
                        coreRec = new Rectangle((int)Position.X + 190, (int)Position.Y + 110, Img.Width * (int)2.0 - 110, Img.Height * (int)1.0 - 25);
                        break;
                }
                #endregion

                #region 周囲の蝙蝠更新
                for (int i = 0; i < bat.GetLength(0); i++)
                {
                    bat[i].Update(gameTime);
                    if (i < 11)
                    {
                        if (!core_BatAttackEnable)
                        {
                            bat[i].angle -= 0.5f;
                        }
                        float rad = bat[i].angle * (float)Math.PI * 2 * 0.003f;
                        bat[i].Pos.X = Position.X + (float)Math.Sin(rad) * (150 + 1 * accelBat) + 178;
                        bat[i].Pos.Y = Position.Y + (float)Math.Cos(rad) * (150 + 1 * accelBat) + 145;
                    }
                    if ((i >= 11 && i < 22))
                    {
                        if (!core_BatAttackEnable)
                        {
                            bat[i].angle -= 0.5f;
                        }
                        float rad = bat[i].angle * (float)Math.PI * 2 * 0.003f;
                        bat[i].Pos.X = Position.X + (float)Math.Sin(rad) * (210 + 1.5f * accelBat) + 178;
                        bat[i].Pos.Y = Position.Y + (float)Math.Cos(rad) * (210 + 1.5f * accelBat) + 145;
                    }
                    if (i < 33 && i >= 22)
                    {
                        bat[i].angle += 1.5f;
                        float rad = bat[i].angle * (float)Math.PI * 2 * 0.003f;
                        bat[i].Pos.X = Position.X + (float)Math.Sin(rad) * 100 + 178;
                        bat[i].Pos.Y = Position.Y + (float)Math.Cos(rad) * 100 + 145;
                    }
                }
                #endregion
            }

            #endregion

            base.Update(gameTime);
        }
        #endregion

        #region メソッド
        /// <summary>
        /// 攻撃パターンを決めるメソッド,
        /// 乱数で決める、前回の攻撃と違う攻撃を出す
        /// </summary>
        public void ChoicAttackPattern()
        {
            if (attackEnable)
            {
                Random a = new Random();
                randomNow = a.Next(0, 6);

                if (randomCount != randomNow)
                {
                    randomCount = randomNow;
                    switch (randomCount)
                    {
                        case 0:
                            useChangeAttack = true;
                            break;
                        case 1:
                            useChangeAttack2 = true;
                            break;
                        case 2:
                            useMoveAttack = true;
                            break;
                        case 3:
                            useMoveAttack2 = true;
                            break;
                        case 4:
                            useAvatarAttack = true;
                            break;
                        case 5:
                            useAvatarAttack2 = true;
                            break;
                    }
                    attackEnable = false;
                }
                else
                {
                    attackEnable = true;
                }
            }


        }

        /// <summary>
        /// 移動攻撃
        /// 例ルート１：右上->左真ん中->右下->左下
        /// </summary>
        public void MoveAttack1()
        {
            if (Position != new Vector2(1000, 100) && !moveAttackEnable)
            {
                if (DrawEnable)
                {
                    vanishStartTime = DateTime.Now;

                    DrawEnable = false;
                }

                if ((DateTime.Now - vanishStartTime).TotalSeconds > 1.5)
                {
                    Position = new Vector2(1000, 100);

                }
                else
                {
                    if (alpha > 80)
                    {
                        alpha -= 5;
                    }
                }
            }
            if (Position == new Vector2(1000, 100))
            {
                DrawEnable = true;
                moveAttackEnable = true;
                direction = Direction.Left;
                if (alpha < 255)
                {
                    alpha += 5;
                }
                else
                {
                    movingToA = true;
                    movingToB = false;
                    movingToC = false;
                }
            }
            if (moveAttackEnable)
            {
                if (movingToA)
                {
                    direction = Direction.Left;
                    if (Position.X > 5)
                    {

                        VX = -5.0f;
                        Accel_X = -0.5f;
                        VY = 0.5f;
                        Accel_Y = 0.1f;
                    }
                    else
                    {
                        movingToB = true;
                        movingToA = false;
                    }
                }
                if (movingToB)
                {
                    if (Position.X < 1000)
                    {
                        direction = Direction.Right;
                        VX = 7.0f;
                        Accel_X = 0.8f;
                        VY = 0.8f;
                        Accel_Y = 0.1f;

                    }
                    else
                    {
                        movingToB = false;
                        movingToC = true;
                    }
                }
                if (movingToC)
                {
                    if (Position.X > 5)
                    {
                        direction = Direction.Left;
                        VX = -10.0f;
                        Accel_X = -1.5f;
                        VY = 1.4f;
                        Accel_Y = 0.3f;
                    }
                    else
                    {
                        VX = 0;
                        VY = 0;
                        Accel_X = 0;
                        Accel_Y = 0;
                        movingToA = false;
                        movingToB = false;
                        movingToC = false;
                        faintEnable = true;
                        faintStartTime = DateTime.Now;

                    }
                }
                if (faintEnable)
                {
                    if ((DateTime.Now - faintStartTime).TotalSeconds > 1.5)
                    {
                        useMoveAttack = false;
                        attackEnable = true;
                        moveAttackEnable = false;
                        faintEnable = false;
                    }
                }
                VX += Accel_X;
                VY += Accel_Y;
                Position.X += VX;
                Position.Y += VY;
            }

        }
        public void MoveAttack2()
        {
            if (Position != new Vector2(100, 100) && !moveAttackEnable2)
            {
                if (DrawEnable)
                {
                    vanishStartTime = DateTime.Now;

                    DrawEnable = false;
                }

                if ((DateTime.Now - vanishStartTime).TotalSeconds > 1.5)
                {
                    Position = new Vector2(100, 100);
                }
                else
                {
                    if (alpha > 80)
                    {
                        alpha -= 5;
                    }
                }
            }
            if (Position == new Vector2(100, 100))
            {
                DrawEnable = true;
                moveAttackEnable2 = true;
                direction = Direction.Right;
                if (alpha < 255)
                {
                    alpha += 5;
                }
                else
                {
                    movingToA = true;
                    movingToB = false;
                    movingToC = false;
                }
            }
            if (moveAttackEnable2)
            {
                if (movingToA)
                {
                    if (Position.X < 1000)
                    {
                        VX = 5.0f;
                        Accel_X = 0.5f;
                        VY = 0.5f;
                        Accel_Y = 0.1f;
                    }
                    else
                    {
                        movingToB = true;
                        movingToA = false;
                    }
                }
                if (movingToB)
                {
                    if (Position.X > 5)
                    {
                        direction = Direction.Left;
                        VX = -7.0f;
                        Accel_X = -0.8f;
                        VY = 0.8f;
                        Accel_Y = 0.1f;

                    }
                    else
                    {
                        movingToB = false;
                        movingToC = true;
                    }
                }
                if (movingToC)
                {
                    if (Position.X < 1000)
                    {
                        direction = Direction.Right;
                        VX = 10.0f;
                        Accel_X = 1.5f;
                        VY = 1.4f;
                        Accel_Y = 0.3f;
                    }
                    else
                    {
                        VX = 0;
                        VY = 0;
                        Accel_X = 0;
                        Accel_Y = 0;
                        faintStartTime = DateTime.Now;
                        faintEnable = true;
                        movingToA = false;
                        movingToB = false;
                        movingToC = false;
                    }
                }
                if (faintEnable)
                {
                    if ((DateTime.Now - faintStartTime).TotalSeconds > 1.5)
                    {
                        moveAttackEnable2 = false;
                        attackEnable = true;
                        useMoveAttack2 = false;
                        faintEnable = false;
                    }
                }
                VX += Accel_X;
                VY += Accel_Y;
                Position.X += VX;
                Position.Y += VY;
            }
        }

        /// <summary>
        /// 変身攻撃
        /// 体型が大きい牛になり、左右に突っ込む
        /// </summary>
        public void ChangeAttack1()
        {
            //スタート Position = new Vector2(950, 450);
            if (!changeAttackEnable)
            {
                direction = Direction.Left;
                #region スタート位置まで移動させる
                if (Position.Y > 450)
                {
                    Position.Y = 450.0f;
                }
                if (Position.Y < 450)
                {
                    Position.Y += 5.0f;
                }
                if (Position.X > 950)
                {
                    Position.X = 950.0f;
                }
                if (Position.X < 950)
                {
                    Position.X += 5.0f;
                }
                #endregion
                if (Position == new Vector2(950, 450) && !vanishEnable)
                {
                    vanishStartTime = DateTime.Now;
                    vanishEnable = true;
                }
                if (vanishEnable)
                {
                    if (alpha > 0)
                        alpha -= 5;
                    else
                    {
                        changeAttackEnable = true;
                    }
                }
            }
            if (changeAttackEnable)
            {
                if (alpha < 255)
                {
                    alpha += 5;
                }
                else
                {
                    vanishEnable = false;
                }
                if (Position.X > 300 && !vanishEnable)
                {
                    VX = -10.0f;
                    Accel_X = -0.5f;
                }
                if (Position.X > 0 && Position.X <= 400 && !vanishEnable)
                {
                    Accel_X = -25f;
                }
                if (Position.X < 0 && !faintEnable)
                {
                    VX = 0;
                    Accel_X = 0;
                    itemFallDownEnable = true;
                    faintEnable = true;
                    faintStartTime = DateTime.Now;
                }
                #region アイテムが落ちる
                //落ちる前の値のセット
                if (itemFallDownEnable)
                {
                    itemVY = 0;
                    item_Accel_Y = 0.30f;
                    fallenItemPos[1].X = 670.0f;
                    fallenItemPos[1].Y = -100;
                    item_Ground_Y[1] = 370;

                    fallenItemPos[0].X = 260;
                    fallenItemPos[0].Y = -100;
                    item_Ground_Y[0] = 570;

                    fallenItemPos[2].X = 1080;
                    fallenItemPos[2].Y = -100;
                    item_Ground_Y[2] = 570;
                    for (int i = 0; i < itemMaxCount; i++)
                    {
                        itemEnable[i] = true;
                    }
                    itemFallDownEnable = false;
                    IsitemFalling = true;
                }
                //落下中
                if (IsitemFalling)
                {
                    itemVY += item_Accel_Y;
                    for (int i = 0; i < itemMaxCount; i++)
                    {
                        if (fallenItemPos[i].Y < item_Ground_Y[i])
                        {
                            item_Rectangle[i] = new Rectangle((int)fallenItemPos[i].X + 0 * (int)1.8,
        (int)fallenItemPos[i].Y + 30 * (int)1.8,
        20 * (int)1.8,
        50 * (int)1.8);
                            fallenItemPos[i].Y += itemVY;
                        }
                        else
                        {
                            item_Rectangle[i] = new Rectangle((int)fallenItemPos[i].X + 0 * (int)1.8,
        (int)fallenItemPos[i].Y + 40 * (int)1.8,
        50 * (int)1.8,
        20 * (int)1.8);
                            fallenItemPos[i].Y = item_Ground_Y[i];
                        }
                        if (fallenItemPos[2].Y == item_Ground_Y[2])
                        {
                            IsitemFalling = false;
                        }
                    }
                }
                #endregion
                if (faintEnable)
                {
                    if ((DateTime.Now - faintStartTime).TotalSeconds > 2)
                    {
                        useChangeAttack = false;
                        changeAttackEnable = false;
                        faintEnable = false;
                        attackEnable = true;
                    }
                }
            }
            VX += Accel_X;
            Position.X += VX;
        }
        public void ChangeAttack2()
        {
            //スタート Position = new Vector2(950, 450);
            if (!changeAttackEnable2)
            {
                direction = Direction.Right;
                #region スタート位置まで移動させる
                if (Position.Y > 450)
                {
                    Position.Y = 450.0f;
                }
                if (Position.Y < 450)
                {
                    Position.Y += 5.0f;
                }
                if (Position.X < -100)
                {
                    Position.X = -100.0f;
                }
                if (Position.X > -100)
                {
                    Position.X -= 5.0f;
                }
                #endregion
                if (Position == new Vector2(-100, 450) && !vanishEnable)
                {
                    vanishStartTime = DateTime.Now;
                    vanishEnable = true;
                }
                if (vanishEnable)
                {
                    if (alpha > 0)
                        alpha -= 5;
                    else
                    {
                        changeAttackEnable2 = true;
                    }
                }
            }
            if (changeAttackEnable2)
            {
                if (alpha < 255)
                {
                    alpha += 5;
                }
                else
                {
                    vanishEnable = false;
                }
                if (Position.X < 880 && !vanishEnable)
                {
                    VX = 10.0f;
                    Accel_X = 0.5f;
                }
                if (Position.X > 300 && Position.X < 880 && !vanishEnable)
                {
                    Accel_X = 25f;
                }
                if (Position.X > 880 && !faintEnable)
                {
                    VX = 0;
                    Accel_X = 0;
                    faintEnable = true;
                    itemFallDownEnable = true;
                    faintStartTime = DateTime.Now;
                }
                #region アイテムが落ちる
                //落ちる前の値のセット
                if (itemFallDownEnable)
                {
                    itemVY = 0;
                    item_Accel_Y = 0.30f;
                    fallenItemPos[1].X = 670.0f;
                    fallenItemPos[1].Y = -100;
                    item_Ground_Y[1] = 370;

                    fallenItemPos[0].X = 260;
                    fallenItemPos[0].Y = -100;
                    item_Ground_Y[0] = 570;

                    fallenItemPos[2].X = 1080;
                    fallenItemPos[2].Y = -100;
                    item_Ground_Y[2] = 570;
                    for (int i = 0; i < itemMaxCount; i++)
                    {
                        itemEnable[i] = true;
                    }
                    itemFallDownEnable = false;
                    IsitemFalling = true;
                }
                //落下中
                if (IsitemFalling)
                {
                    itemVY += item_Accel_Y;
                    for (int i = 0; i < itemMaxCount; i++)
                    {
                        if (fallenItemPos[i].Y < item_Ground_Y[i])
                        {
                            item_Rectangle[i] = new Rectangle((int)fallenItemPos[i].X + 0 * (int)1.8,
        (int)fallenItemPos[i].Y + 30 * (int)1.8,
        20 * (int)1.8,
        50 * (int)1.8);
                            fallenItemPos[i].Y += itemVY;
                        }
                        else
                        {
                            item_Rectangle[i] = new Rectangle((int)fallenItemPos[i].X + 0 * (int)1.8,
        (int)fallenItemPos[i].Y + 40 * (int)1.8,
        50 * (int)1.8,
        20 * (int)1.8);
                            fallenItemPos[i].Y = item_Ground_Y[i];
                        }
                        if (fallenItemPos[2].Y == item_Ground_Y[2])
                        {
                            IsitemFalling = false;
                        }
                    }
                }
                #endregion
                if (faintEnable)
                {
                    if ((DateTime.Now - faintStartTime).TotalSeconds > 2)
                    {
                        useChangeAttack2 = false;
                        changeAttackEnable2 = false;
                        faintEnable = false;
                        attackEnable = true;
                    }
                }
            }
            VX += Accel_X;
            Position.X += VX;
        }

        /// <summary>
        /// 分身攻撃
        /// 右上/左上に移動し、蝙蝠の群れを出す。蝙蝠が指定の位置に移動し、プレイヤーを追跡(5回)
        /// プレイヤーを攻撃したら、血をもって帰る、ボスを回復する
        /// </summary>
        public void AvaterAttack1()
        {
            if (!avatarAttackEnable)
            {
                //0番目の蝙蝠をPointXに向かわせる

                direction = Direction.Left;
                #region ボスをスタート位置まで移動させる
                if (Position.Y < 0)
                {
                    Position.Y = 0.0f;
                }
                if (Position.Y > 0)
                {
                    Position.Y -= 5.0f;
                }
                if (Position.X > 1050)
                {
                    Position.X = 1050.0f;
                }
                if (Position.X < 1050)
                {
                    Position.X += 5.0f;
                }
                #endregion
                if (Position == new Vector2(1050, 0))
                {
                    for (int i = 0; i < bat2.GetLength(0); i++)
                    {
                        bat2[i].Pos.X = 1250;
                        bat2[i].Pos.Y = 100;

                        bat2[i].ResetFlag();
                        bat2[i].drawEnable = true;
                    }
                    bat2[0].moveNextBat = true;
                    avatarAttackEnable = true;
                }

            }
            if (avatarAttackEnable)
            {
                for (int i = 0; i < bat2.GetLength(0); i++)
                {
                    #region 指定の位置に移動する
                    //インデックス内だったら
                    if (i + 1 <= bat2.GetLength(0) - 1)
                    {
                        //前の蝙蝠が50ピクセルを移動したら、次の蝙蝠の移動フラグをon
                        if (bat2[i + 1].Pos.X - bat2[i].Pos.X > 50 || bat2[i + 1].Pos.Y - bat2[i].Pos.Y > 50)
                        {
                            bat2[i + 1].moveNextBat = true;
                        }
                    }
                    //移動フラグがonの時、pointAに向かわせる
                    if (bat2[i].moveNextBat && !bat2[i].attackEnable)
                    {
                        bat2[i].MoveToPoint(new Vector2(800, 100), i, ref bat2);
                    }
                    //全員が到達したら
                    if (bat2[bat2.GetLength(0) - 1].Pos.X <= 1100)
                    {
                        bat2[bat2.GetLength(0) - 1].lastBatMoveEnd = true;
                    }
                    //指定の位置に到達したら、追跡を始める
                    if (bat2[i].Pos == new Vector2(800, 100))
                    {
                        if (i != 0 && bat2[bat2.GetLength(0) - 1].lastBatMoveEnd)
                        {
                            bat2[i].attackEnable = true;
                            bat2[i].moveNextBat = false;
                        }
                        else
                        {
                            bat2[i].attackEnable = true;
                            bat2[i].moveNextBat = false;
                        }
                    }
                    #endregion
                    #region 追跡開始
                    if (bat2[i].attackEnable && !bat2[i].comeBackEnable)
                    {
                        bat2[i].MoveToPoint(player.Position + new Vector2(20, 50), i, ref bat2);
                    }
                    if (bat2[i].PointCount == 5)
                    {
                        bat2[i].ResetFlag();
                        bat2[i].comeBackEnable = true;
                    }
                    #endregion
                    #region 吸血
                    if (bat2[i].drawEnable && bat2 != null)
                    {
                        if (bat2[i].rectangle.Intersects(player.rectangle))
                        {
                            bat2[i].drainHitEnable = true;
                        }
                    }
                    #endregion
                    #region ボスの位置に戻る
                    if (bat2[i].comeBackEnable)
                    {
                        bat2[i].MoveToPoint(new Vector2(1250, 100), i, ref bat2);
                    }
                    if (bat2[i].Pos.X > 1250 && bat2[i].Pos.Y < 110 && bat2[i].comeBackEnable)
                    {
                        if (bat2[i].drainHitEnable && bat2[i].drawEnable)
                        {
                            if (drainHpCount < drainMaxHp)
                            {
                                hpLength += 5;
                                drainHpCount += 5;
                            }
                        }
                        bat2[i].comeBackEnable = false;
                        bat2[i].attackEnable = false;
                        bat2[i].useMove = false;
                        batcount_ComeBack++;
                    }
                    #endregion
                }
                if (batcount_ComeBack >= bat2.GetLength(0))
                {
                    for (int i = 0; i < bat2.GetLength(0); i++)
                    {
                        bat2[i].ResetFlag();
                        bat2[i].moveNextBat = false;
                        bat2[i].drawEnable = false;
                    }
                    //フラグリセット
                    useAvatarAttack = false;
                    avatarAttackEnable = false;
                    drainHpCount = 0;
                    batcount_ComeBack = 0;

                    attackEnable = true;
                }

            }
        }
        public void AvaterAttack2()
        {
            if (!avatarAttackEnable2)
            {
                //0番目の蝙蝠をPointXに向かわせる

                direction = Direction.Right;
                #region ボスをスタート位置まで移動させる
                if (Position.Y < 0)
                {
                    Position.Y = 0.0f;
                }
                if (Position.Y > 0)
                {
                    Position.Y -= 5.0f;
                }
                if (Position.X > 0)
                {
                    Position.X -= 5.0f;
                }
                if (Position.X < 0)
                {
                    Position.X = 0.0f;
                }
                #endregion
                if (Position == new Vector2(0, 0))
                {
                    for (int i = 0; i < bat2.GetLength(0); i++)
                    {
                        bat2[i].Pos.X = 225;
                        bat2[i].Pos.Y = 50;

                        bat2[i].ResetFlag();
                        bat2[i].drawEnable = true;
                    }
                    bat2[0].moveNextBat = true;
                    avatarAttackEnable2 = true;
                }

            }
            if (avatarAttackEnable2)
            {
                for (int i = 0; i < bat2.GetLength(0); i++)
                {
                    #region 指定の位置に移動する
                    //インデックス内だったら
                    if (i + 1 <= bat2.GetLength(0) - 1)
                    {
                        //前の蝙蝠が50ピクセルを移動したら、次の蝙蝠の移動フラグをon
                        if (Math.Abs(bat2[i + 1].Pos.X - bat2[i].Pos.X) > 50 || Math.Abs(bat2[i + 1].Pos.Y - bat2[i].Pos.Y) > 50)
                        {
                            bat2[i + 1].moveNextBat = true;
                        }
                    }
                    //移動フラグがonの時、pointAに向かわせる
                    if (bat2[i].moveNextBat && !bat2[i].attackEnable)
                    {
                        bat2[i].MoveToPoint(new Vector2(500, 100), i, ref bat2);
                    }
                    //全員が到達したら
                    if (bat2[bat2.GetLength(0) - 1].Pos.X >= 450)
                    {
                        bat2[bat2.GetLength(0) - 1].lastBatMoveEnd = true;
                    }
                    //指定の位置に到達したら、追跡を始める
                    if (bat2[i].Pos == new Vector2(500, 100))
                    {
                        if (i != 0 && bat2[bat2.GetLength(0) - 1].lastBatMoveEnd)
                        {
                            bat2[i].attackEnable = true;
                            bat2[i].moveNextBat = false;
                        }
                        else
                        {
                            bat2[i].attackEnable = true;
                            bat2[i].moveNextBat = false;
                        }
                    }
                    #endregion
                    #region 追跡開始
                    if (bat2[i].attackEnable && !bat2[i].comeBackEnable)
                    {
                        bat2[i].MoveToPoint(player.Position + new Vector2(20, 50), i, ref bat2);
                    }

                    if (bat2[i].PointCount == 5)
                    {
                        bat2[i].ResetFlag();
                        bat2[i].comeBackEnable = true;
                    }

                    #endregion
                    #region 吸血
                    if (bat2[i].drawEnable)
                    {
                        if (bat2[i].rectangle.Intersects(player.rectangle))
                        {
                            bat2[i].drainHitEnable = true;
                        }
                    }
                    #endregion
                    #region ボスの位置に戻る
                    if (bat2[i].comeBackEnable)
                    {
                        bat2[i].MoveToPoint(new Vector2(225, 50), i, ref bat2);
                    }
                    if (bat2[i].Pos.X <= 228 && bat2[i].Pos.Y <= 55 && bat2[i].comeBackEnable)
                    {
                        if (bat2[i].drainHitEnable && bat2[i].drawEnable)
                        {
                            if (drainHpCount < drainMaxHp)
                            {
                                hpLength += 5;
                                drainHpCount += 5;
                            }
                        }
                        bat2[i].comeBackEnable = false;
                        bat2[i].attackEnable = false;
                        bat2[i].useMove = false;
                        batcount_ComeBack++;
                    }
                    #endregion
                }
                if (batcount_ComeBack >= bat2.GetLength(0))
                {
                    for (int i = 0; i < bat2.GetLength(0); i++)
                    {
                        bat2[i].moveNextBat = false;
                        bat2[i].ResetFlag();
                        bat2[i].drawEnable = false;
                    }
                    //フラグリセット
                    useAvatarAttack2 = false;
                    avatarAttackEnable2 = false;
                    drainHpCount = 0;
                    batcount_ComeBack = 0;
                    //次の攻撃を可能に
                    attackEnable = true;
                }

            }
        }

        /// <summary>
        /// コア
        /// 体力が0になるとき、ループ円に移動し、最終状態になる
        /// 外側の蝙蝠が打たれても、一定時間で復活するようになる
        /// </summary>
        public void Formchange()
        {
            //本体を消す
            if (alpha > 0 && !coreShowUpEnable)
            {
                alpha -= 5;
            }
            #region コアをスタート位置まで移動させる
            if (alpha <= 0 && !coreShowUpEnable)
            {
                ResetAttackFlag();
                MoveToPoint(new Vector2(470, 450));
            }
            if ((Position.X > 400 && Position.X < 600) &&
                (Position.Y > 400 && Position.Y < 600) && !formChangeEnable)
            {
                formChange_StartTime = DateTime.Now;
                formChangeEnable = true;
            }
            if ((DateTime.Now - formChange_StartTime).TotalSeconds > 1.3 && !coreShowUpEnable)
            {
                for (int i = 0; i < bat.GetLength(0); i++)
                {
                    bat[i].drawEnable = true;
                }
                Position = new Vector2(470, 450);
                coreShowUpEnable = true;
                onceFlag_UseCoreMove = true;
            }
            #endregion
        }
        private void MoveToPoint(Vector2 Point)
        {
            Position.X = (int)Position.X;
            Position.Y = (int)Position.Y;
            //移動先
            if (onceFlag_recordMovePoint)
            {
                int i = (int)Position.X % 5;
                switch (i)
                {
                    case 4:
                        Position.X -= 4;
                        break;
                    case 3:
                        Position.X -= 3;
                        break;
                    case 2:
                        Position.X -= 2;
                        break;
                    case 1:
                        Position.X -= 1;
                        break;
                    default:
                        Position.X = (int)Position.X;
                        break;
                }
                int y = (int)Position.Y % 5;
                switch (y)
                {
                    case 4:
                        Position.Y -= 4;
                        break;
                    case 3:
                        Position.Y -= 3;
                        break;
                    case 2:
                        Position.Y -= 2;
                        break;
                    case 1:
                        Position.Y -= 1;
                        break;
                    default:
                        Position.Y = (int)Position.Y;
                        break;
                }
                movePointEnable = true;
                onceFlag_recordMovePoint = false;
            }
            Debug.WriteLine(Position);
            if (movePointEnable)
            {
                if (Position.Y > Point.Y)
                {
                    Position.Y -= 5;
                }
                else if (Position.Y < Point.Y)
                {
                    Position.Y += 5;
                }
                else
                {
                    Position.Y = Point.Y;
                }
                if (Position.X > Point.X)
                {
                    Position.X -= 5;
                }
                else if (Position.X < Point.X)
                {
                    Position.X += 5;
                }
                else
                {
                    Position.X = Point.X;
                }
                if (Position == Point)
                {
                    movePointEnable = false;
                }
            }
        }
        private void ResetAttackFlag()
        {
            useAvatarAttack = false;
            useAvatarAttack2 = false;
            useMoveAttack = false;
            useMoveAttack2 = false;
            useChangeAttack = false;
            useChangeAttack2 = false;
            moveAttackEnable = false;
            moveAttackEnable2 = false;
            changeAttackEnable = false;
            changeAttackEnable2 = false;
            avatarAttackEnable = false;
            avatarAttackEnable2 = false;
        }
        /// <summary>
        /// コアの移動パターン
        /// 真ん中下からスタートしー＞右下ー＞右上ー＞真ん中上ー＞左上ー＞左下ー＞右下のループ
        /// </summary>
        public void CoreMovePattern()
        {
            if (onceFlag_UseCoreMove)
            {
                moveToPointAEnable = true;
                onceFlag_RecordWaitTime = true;
                onceFlag_UseCoreMove = false;
            }

            if (moveToPointAEnable)
            {
                if (Position.X < pointA.X)
                {
                    Position.X += 5;
                }
                else
                {
                    Position.X = pointA.X;
                }
                if (Position.Y < pointA.Y)
                {
                    Position.Y += 5;
                }
                else
                {
                    Position.Y = pointA.Y;
                }
                if (Position == pointA)
                {
                    if (onceFlag_RecordWaitTime)
                    {
                        useCore_BatAttack = true;
                        waitTime = DateTime.Now;
                        onceFlag_RecordWaitTime = false;
                    }
                    if ((DateTime.Now - waitTime).TotalSeconds > 5)
                    {
                        moveToPointAEnable = false;
                        moveToPointBEnable = true;
                        onceFlag_RecordWaitTime = true;
                    }
                }
            }
            if (moveToPointBEnable)
            {
                if (Position.X < pointB.X)
                {
                    Position.X += 5;
                }
                else
                {
                    Position.X = pointB.X;
                }
                if (Position.Y > pointB.Y)
                {
                    Position.Y -= 5;
                }
                else
                {
                    Position.Y = pointB.Y;
                }
                if (Position == pointB)
                {
                    if (onceFlag_RecordWaitTime)
                    {
                        useCore_BatAttack = true;
                        waitTime = DateTime.Now;
                        onceFlag_RecordWaitTime = false;
                    }
                    if ((DateTime.Now - waitTime).TotalSeconds > 5)
                    {
                        MoveToPointCEnable = true;
                        moveToPointBEnable = false;
                        onceFlag_RecordWaitTime = true;
                    }
                }
            }
            if (MoveToPointCEnable)
            {
                if (Position.X > pointC.X)
                {
                    Position.X -= 5;
                }
                else
                {
                    Position.X = pointC.X;
                }
                if (Position.Y < pointC.Y)
                {
                    Position.Y += 5;
                }
                else
                {
                    Position.Y = pointC.Y;
                }
                if (Position == pointC)
                {
                    if (onceFlag_RecordWaitTime)
                    {
                        useLaserAttack = true;
                        waitTime = DateTime.Now;
                        onceFlag_RecordWaitTime = false;
                    }
                    if ((DateTime.Now - waitTime).TotalSeconds > 5)
                    {
                        MoveToPointCEnable = false;
                        moveToPointDEnable = true;
                        onceFlag_RecordWaitTime = true;
                    }
                }
            }
            if (moveToPointDEnable)
            {
                if (Position.X > pointD.X)
                {
                    Position.X -= 5;
                }
                else
                {
                    Position.X = pointD.X;
                }
                if (Position.Y < pointD.Y)
                {
                    Position.Y += 5;
                }
                else
                {
                    Position.Y = pointD.Y;
                }
                if (Position == pointD)
                {
                    if (onceFlag_RecordWaitTime)
                    {
                        useCore_BatAttack = true;
                        waitTime = DateTime.Now;
                        onceFlag_RecordWaitTime = false;
                    }
                    if ((DateTime.Now - waitTime).TotalSeconds > 5)
                    {
                        moveToPointDEnable = false;
                        moveToPointEEnable = true;
                        onceFlag_RecordWaitTime = true;
                    }

                }
            }
            if (moveToPointEEnable)
            {
                if (Position.X < pointE.X)
                {
                    Position.X += 5;
                }
                else
                {
                    Position.X = pointE.X;
                }
                if (Position.Y < pointE.Y)
                {
                    Position.Y += 5;
                }
                else
                {
                    Position.Y = pointE.Y;
                }
                if (Position == pointE)
                {
                    if (onceFlag_RecordWaitTime)
                    {
                        useCore_BatAttack = true;
                        waitTime = DateTime.Now;
                        onceFlag_RecordWaitTime = false;
                    }
                    if ((DateTime.Now - waitTime).TotalSeconds > 5)
                    {
                        moveToPointEEnable = false;
                        moveToPointAEnable = true;
                        onceFlag_RecordWaitTime = true;
                    }
                }
            }
        }

        /// <summary>
        /// コアのレーザー攻撃
        ///vampire.laserPointEd.X += 12;
        /// </summary>
        public void CoreLaserAttack()
        {
            if (useLaserAttack)
            {
                laserPointEd = new Vector2(100, 858);
                laserPos = new Vector2(0, 170);
                laserRecWidth = 0;
                laserAttackEnable = true;
                AnimatedImg_RaserAttack.Play();
                AnimatedImg_RaserAttack.SetCurrentFrameNumber(0);
                useLaserAttack = false;
            }
            if (laserAttackEnable)
            {
                //あたり判定用の直線を右に移動させる
                if (laserPointEd.X < 1400)
                {
                    laserPointEd.X += 12;
                }
                if (laserRecWidth > 300)
                {
                    laserPos.X += 10;
                }
                if (laserRecWidth < 1400)
                {
                    laserRecWidth += 12;
                }
                if (AnimatedImg_RaserAttack.GetCurrentFrameNumber() > 15)
                {
                    laserAttackEnable = false;
                }
            }
            else
            {
                AnimatedImg_RaserAttack.Pause();
            }
        }

        /// <summary>
        /// コアの蝙蝠花火攻撃
        ///　画面のa,b,d,eにいると、波みたいに広がる
        /// </summary>
        public void CoreBatAttack()
        {
            if (useCore_BatAttack)
            {
                for (int i = 0; i < bat.GetLength(0); i++)
                {
                    bat[i].prevPos = bat[i].Pos;
                    if (bat[i].alpha < 200)
                        bat[i].alpha = 0;
                }
                coreBatAttack_StartTime = DateTime.Now;
                core_BatAttackEnable = true;
                useCore_BatAttack = false;
            }
            if (core_BatAttackEnable)
            {
                accelBat += 5;
                if ((DateTime.Now - coreBatAttack_StartTime).TotalSeconds > 4.0)
                {
                    for (int i = 0; i < bat.GetLength(0); i++)
                    {
                        bat[i].Pos = bat[i].prevPos;
                        accelBat = 0;
                        core_BatAttackEnable = false;
                        useCore_BatAttack = false;
                        coreBatAttack_StartTime = DateTime.MaxValue;
                    }
                }
            }
        }

        /// <summary>
        /// 被ダメージ
        /// </summary>
        public void CheckSwordDamage(Rectangle swordRec, ref bool swordHitEnable, bool attackEnable)
        {
            #region 通常状態
            if (!coreShowUpEnable)
            {
                if (swordHitEnable && attackEnable)
                {

                    if (rectangle0 != Rectangle.Empty)
                    {
                        if (rectangle0.Intersects(swordRec) && hitEnable0 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 25;
                            hitEnable0 = false;
                            swordHitEnable = false;
                        }
                    }
                    if (rectangle1 != Rectangle.Empty)
                    {
                        if (rectangle1.Intersects(swordRec) && hitEnable1 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 25;
                            hitEnable1 = false;
                            swordHitEnable = false;
                        }
                    }
                    if (rectangle2 != Rectangle.Empty)
                    {
                        if (rectangle2.Intersects(swordRec) && hitEnable2 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 25;
                            hitEnable2 = false;
                            swordHitEnable = false;
                        }

                    }
                    if (rectangle3 != Rectangle.Empty)
                    {
                        if (rectangle3.Intersects(swordRec) && hitEnable3 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 25;
                            hitEnable3 = false;
                            swordHitEnable = false;
                        }
                    }
                    if (rectangle4 != Rectangle.Empty)
                    {
                        if (rectangle4.Intersects(swordRec) && hitEnable4 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 25;
                            hitEnable4 = false;
                            swordHitEnable = false;
                        }
                    }
                    if (rectangle5 != Rectangle.Empty)
                    {
                        if (rectangle5.Intersects(swordRec) && hitEnable5 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 25;
                            hitEnable5 = false;
                            swordHitEnable = false;
                        }
                    }
                }
                if (!rectangle2.Contains(swordRec) && !rectangle1.Contains(swordRec) && !rectangle0.Contains(swordRec) && !rectangle3.Contains(swordRec) && !rectangle4.Contains(swordRec) && !rectangle5.Contains(swordRec))
                {
                    hitEnable0 = true;
                    hitEnable1 = true;
                    hitEnable2 = true;
                    hitEnable3 = true;
                    hitEnable4 = true;
                    hitEnable5 = true;
                    hitCount = 0;
                }
            }
            #endregion
            #region コア状態
            if (coreShowUpEnable)
            {
                if (swordHitEnable && attackEnable)
                {
                    if (coreRec != Rectangle.Empty)
                    {
                        if ((coreRec.Intersects(swordRec)) && coreHitEnable && hitCount == 0)
                        {
                            hitCount++;
                            coreHp--;
                            coreHitEnable = false;
                            swordHitEnable = false;
                        }
                    }
                }
                if (!coreRec.Contains(swordRec))
                {
                    coreHitEnable = true;
                    hitCount = 0;
                }
            }
            #endregion
        }
        public void CheckBombDamage(Rectangle bombRec, ref bool bombHitEnable, bool explosionEnable, bool useBanana)
        {
            #region 通常状態
            if (!coreShowUpEnable)
            {
                if (bombHitEnable && !explosionEnable && useBanana)
                {
                    if (rectangle0 != Rectangle.Empty)
                    {
                        if (rectangle0.Intersects(bombRec) && hitEnable0 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 50;
                            hitEnable0 = false;
                            bombHitEnable = false;
                        }
                    }
                    if (rectangle1 != Rectangle.Empty)
                    {
                        if (rectangle1.Intersects(bombRec) && hitEnable1 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 50;
                            hitEnable1 = false;
                            bombHitEnable = false;
                        }
                    }
                    if (rectangle2 != Rectangle.Empty)
                    {
                        if (rectangle2.Intersects(bombRec) && hitEnable2 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 50;
                            hitEnable2 = false;
                            bombHitEnable = false;
                        }

                    }
                    if (rectangle3 != Rectangle.Empty)
                    {
                        if (rectangle3.Intersects(bombRec) && hitEnable3 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 50;
                            hitEnable3 = false;
                            bombHitEnable = false;
                        }
                    }
                    if (rectangle4 != Rectangle.Empty)
                    {
                        if (rectangle4.Intersects(bombRec) && hitEnable4 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 50;
                            hitEnable4 = false;
                            bombHitEnable = false;
                        }
                    }
                    if (rectangle5 != Rectangle.Empty)
                    {
                        if (rectangle5.Intersects(bombRec) && hitEnable5 && hitCount == 0)
                        {
                            hitCount++;
                            hpLength -= 50;
                            hitEnable5 = false;
                            bombHitEnable = false;
                        }
                    }
                }
                if (!rectangle2.Contains(bombRec) && !rectangle1.Contains(bombRec) && !rectangle0.Contains(bombRec) && !rectangle3.Contains(bombRec) && !rectangle4.Contains(bombRec) && !rectangle5.Contains(bombRec))
                {
                    hitEnable0 = true;
                    hitEnable1 = true;
                    hitEnable2 = true;
                    hitEnable3 = true;
                    hitEnable4 = true;
                    hitEnable5 = true;
                    hitCount = 0;
                }
            }
            #endregion
            #region コア状態
            if (coreShowUpEnable)
            {
                if (bombHitEnable && !explosionEnable && useBanana)
                {
                    if (coreRec != Rectangle.Empty)
                    {
                        if ((coreRec.Intersects(bombRec)) && coreHitEnable && hitCount == 0)
                        {
                            hitCount++;
                            coreHp--;
                            coreHitEnable = false;
                            bombHitEnable = false;
                        }
                    }
                }
                if (!coreRec.Contains(bombRec))
                {
                    coreHitEnable = true;
                    hitCount = 0;
                }
            }
            #endregion
        }
        public void CheckSkateBoardDamage(Rectangle skateBoardRec, ref bool SB_hitEnable, bool boostEnable, bool useSkateBoard, bool inroopCircle)
        {
            #region 通常状態
            if (!coreShowUpEnable)
            {
                if (useSkateBoard && !inroopCircle && SB_hitEnable)
                {
                    if (rectangle1 != Rectangle.Empty)
                    {
                        if (rectangle1.Intersects(skateBoardRec) && hitEnable1 && hitCount == 0)
                        {
                            if (!boostEnable)
                            {
                                hpLength -= 25;
                            }
                            else
                            {
                                hpLength -= 50;
                            }
                            hitEnable1 = false;
                            SB_hitEnable = false;
                        }
                    }
                    if (rectangle2 != Rectangle.Empty)
                    {
                        if (rectangle2.Intersects(skateBoardRec) && hitEnable2 && hitCount == 0)
                        {
                            if (!boostEnable)
                            {
                                hpLength -= 25;
                            }
                            else
                            {
                                hpLength -= 50;
                            }
                            hitEnable2 = false;
                            SB_hitEnable = false;
                        }
                    }
                    if (rectangle3 != Rectangle.Empty)
                    {
                        if (rectangle3.Intersects(skateBoardRec) && hitEnable3 && hitCount == 0)
                        {
                            if (!boostEnable)
                            {
                                hpLength -= 25;
                            }
                            else
                            {
                                hpLength -= 50;
                            }
                            hitEnable3 = false;
                            SB_hitEnable = false;
                        }
                    }
                    if (rectangle4 != Rectangle.Empty)
                    {
                        if (rectangle4.Intersects(skateBoardRec) && hitEnable4 && hitCount == 0)
                        {
                            if (!boostEnable)
                            {
                                hpLength -= 25;
                            }
                            else
                            {
                                hpLength -= 50;
                            }
                            hitEnable4 = false;
                            SB_hitEnable = false;
                        }
                    }
                }
                if (!rectangle2.Intersects(skateBoardRec) && !rectangle1.Intersects(skateBoardRec) && !rectangle0.Intersects(skateBoardRec) && !rectangle3.Intersects(skateBoardRec) && !rectangle4.Intersects(skateBoardRec) && !rectangle5.Intersects(skateBoardRec))
                {
                    hitEnable0 = true;
                    hitEnable1 = true;
                    hitEnable2 = true;
                    hitEnable3 = true;
                    hitEnable4 = true;
                    hitEnable5 = true;
                    hitCount = 0;
                }
            }
            #endregion
            #region コア状態
            if (coreShowUpEnable)
            {
                if (useSkateBoard && !inroopCircle && SB_hitEnable)
                {
                    if (coreRec != Rectangle.Empty)
                    {
                        if (coreRec.Intersects(skateBoardRec) && coreHitEnable && hitCount == 0)
                        {
                            if (!boostEnable)
                            {
                                coreHp--;
                            }
                            else
                            {
                                coreHp -= 2;
                            }
                            coreHitEnable = false;
                            SB_hitEnable = false;
                        }
                    }
                }
                if (!coreRec.Contains(skateBoardRec))
                {
                    coreHitEnable = true;
                    hitCount = 0;
                }
            }
            #endregion
        }
        #endregion

        #region 描画処理
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            //spriteBatch.Draw(TestRecImg, laserRec, Color.White);
            //デバッグモード
            //if (rectangle0 != Rectangle.Empty)
            //    spriteBatch.Draw(TestRecImg, rectangle0, Color.White);
            //if (rectangle1 != Rectangle.Empty)
            //    spriteBatch.Draw(TestRecImg, rectangle1, Color.White);
            //if (rectangle2 != Rectangle.Empty)
            //    spriteBatch.Draw(TestRecImg, rectangle2, Color.White);
            //if (rectangle3 != Rectangle.Empty)
            //    spriteBatch.Draw(TestRecImg, rectangle3, Color.White);
            //if (rectangle4 != Rectangle.Empty)
            //    spriteBatch.Draw(TestRecImg, rectangle4, Color.White);

            //Test
            if ((DateTime.Now - formChange_StartTime).TotalSeconds < 0.5 && !coreShowUpEnable && !changeAttackEnable && !changeAttackEnable2 && !useChangeAttack && !useChangeAttack2)
            {
                if (direction == Direction.Right)
                {
                    spriteBatch.Draw(BossCore1, Position, null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 4.5f, SpriteEffects.None, 0.0f);
                }
                else
                {
                    spriteBatch.Draw(BossCore1, Position, null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 4.5f, SpriteEffects.FlipHorizontally, 0.0f);
                }
            }
            if ((DateTime.Now - formChange_StartTime).TotalSeconds > 0.5 && formChangeEnable && !coreShowUpEnable)
                AnimatedImg_formChange.DrawFrame(spriteBatch, new Vector2(450, 370), 2.0f, 255);

            if (coreShowUpEnable)
            {
                switch (coreHp)
                {
                    case 4:
                        spriteBatch.Draw(BossCore2, Position + new Vector2(140, 100), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.5f, SpriteEffects.FlipHorizontally, 0.0f);
                        break;
                    case 3:
                        spriteBatch.Draw(BossCore2_2, Position + new Vector2(140, 100), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.5f, SpriteEffects.FlipHorizontally, 0.0f);
                        break;
                    case 2:
                        spriteBatch.Draw(BossCore2_3, Position + new Vector2(140, 100), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.5f, SpriteEffects.FlipHorizontally, 0.0f);
                        break;
                    case 1:
                        spriteBatch.Draw(BossCore2_4, Position + new Vector2(140, 100), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.5f, SpriteEffects.FlipHorizontally, 0.0f);
                        break;
                    default:
                        spriteBatch.Draw(BossCore2_4, Position + new Vector2(140, 100), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 0.5f, SpriteEffects.FlipHorizontally, 0.0f);
                        break;
                }
                for (int i = 0; i < bat.GetLength(0); i++)
                {
                    if (bat[i].direction == Direction.Left)
                    {
                        bat[i].batA.DrawFrame(spriteBatch, bat[i].Pos, 2.0f, SpriteEffects.FlipHorizontally, bat[i].alpha);
                    }
                    else
                    {
                        bat[i].batA.DrawFrame(spriteBatch, bat[i].Pos, 2.0f, SpriteEffects.None, bat[i].alpha);
                    }
                    bat[i].Draw(gameTime);
                }
                if (laserAttackEnable)
                {
                    AnimatedImg_RaserAttack.DrawFrame(spriteBatch, new Vector2(Position.X - 500, Position.Y - 250), 9.0f, 255);
                }
            }
            //hpゲージ
            if (!coreShowUpEnable)
            {
                spriteBatch.Draw(HpImg, new Rectangle(500, 30, hpLength, 30), Color.White);
                if (player.haveBananaBomb)
                {
                    #region アイテム
                    for (int i = 0; i < itemMaxCount; i++)
                    {
                        if (fallenItemPos[i].Y < item_Ground_Y[i])
                        {
                            if (itemEnable[i])
                            {
                                spriteBatch.Draw(BananaBombImg, fallenItemPos[i], null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.0f, SpriteEffects.None, 0.0f);
                            }
                        }
                        else
                        {
                            if (itemEnable[i])
                            {
                                spriteBatch.Draw(BananaBombImg, fallenItemPos[i] + new Vector2(0, 65), null, Color.White, MathHelper.ToRadians(-90), Vector2.Zero, 1.0f, SpriteEffects.None, 0.0f);
                            }
                        }
                    }
                    #endregion
                }
                #region 蝙蝠
                for (int i = 0; i < bat2.GetLength(0); i++)
                {
                    if (bat2[i].drawEnable && alpha > 250)
                    {
                        if (bat2[i].direction == Direction.Left)
                        {
                            bat2[i].batA.DrawFrame(spriteBatch, bat2[i].Pos, 2.0f, SpriteEffects.FlipHorizontally);
                        }
                        else
                        {
                            bat2[i].batA.DrawFrame(spriteBatch, bat2[i].Pos, 2.0f, SpriteEffects.None);
                        }
                    }
                    //デバッグモード
                    //bat2[i].Draw(gameTime);
                }
                #endregion

                #region 魔王
                if (DrawEnable)
                {
                    if (direction == Direction.Left)
                    {
                        if (changeAttackEnable || changeAttackEnable2)
                        {
                            //牛
                            spriteBatch.Draw(Img_Change, new Vector2(Position.X, Position.Y - 65), null, new Color(alpha, alpha, alpha, alpha), MathHelper.ToRadians(0), Vector2.Zero, 7.8f, SpriteEffects.FlipHorizontally, 0.0f);
                        }
                        else
                        {
                            //ボス
                            spriteBatch.Draw(Img, Position, null, new Color(alpha, alpha, alpha, alpha), MathHelper.ToRadians(0), Vector2.Zero, 4.5f, SpriteEffects.FlipHorizontally, 0.0f);
                        }
                    }
                    if (direction == Direction.Right)
                    {
                        if (changeAttackEnable || changeAttackEnable2)
                        {
                            //牛
                            spriteBatch.Draw(Img_Change, new Vector2(Position.X, Position.Y - 65), null, new Color(alpha, alpha, alpha, alpha), MathHelper.ToRadians(0), Vector2.Zero, 7.8f, SpriteEffects.None, 0.0f);
                        }
                        else
                        {
                            //ボス
                            spriteBatch.Draw(Img, Position, null, new Color(alpha, alpha, alpha, alpha), MathHelper.ToRadians(0), Vector2.Zero, 4.5f, SpriteEffects.None, 0.0f);
                        }
                    }
                }
                else
                {
                    if (direction == Direction.Left)
                    {
                        //ボステレポート中
                        spriteBatch.Draw(Img_Teleport, Position, null, new Color(alpha, alpha, alpha, alpha), MathHelper.ToRadians(0), Vector2.Zero, 4.5f, SpriteEffects.FlipHorizontally, 0.0f);
                    }
                    if (direction == Direction.Right)
                    {
                        //ボステレポート中
                        spriteBatch.Draw(Img_Teleport, Position, null, new Color(alpha, alpha, alpha, alpha), MathHelper.ToRadians(0), Vector2.Zero, 4.5f, SpriteEffects.None, 0.0f);
                    }
                }

                if (vanishEnable)
                {
                    if (useChangeAttack)
                    {
                        AnimatedImg_Change.DrawFrame(spriteBatch, new Vector2(600, 100), 0.9f, 100);
                    }
                    if (useChangeAttack2)
                    {
                        AnimatedImg_Change.DrawFrame(spriteBatch, new Vector2(-400, 100), 0.9f, 100);
                    }
                }
                #endregion
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
        #endregion
    }
}
