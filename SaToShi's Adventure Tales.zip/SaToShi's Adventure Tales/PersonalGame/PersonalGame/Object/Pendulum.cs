﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;
namespace PersonalGame
{

    public class Pendulum
    {
        /// <summary>
        /// 空中の振り子
        /// </summary>
        //縄の角度
        public float PendulumAngle = 0;

        //最大角度
        float max_angle = 40;

        //増加量
        public float PendulumPrevAngle = 0.8f;

        //底部のポジション
        public Vector2 PendulumBottomPos;
        
        //一番高いポジション
        public Vector2 PendulumTopPos;

        //判定用正方形（底部）
        public Rectangle PendulumRec;

        //セカンドジャンプかどうかをチェックするフラグ
        public bool secondJump;

        //プレイヤーのジャンプカウントをリセット
        public bool resetJumpCount=true;

        //乗っているかどうかをチェック
        public bool onPendulum;

        //縄の長さ
        public float PendulumLength = 250;

        //座標更新
        public void UpdatePendulum( )
        {
            PendulumAngle += PendulumPrevAngle;

            //増加量反転
            if ( Math.Abs(PendulumAngle) >= max_angle )
                PendulumPrevAngle = -PendulumPrevAngle;

            float rad = -PendulumAngle * (float)Math.PI * 2 * 0.003f;

            PendulumBottomPos.X = PendulumTopPos.X + (float)Math.Sin(rad) * PendulumLength;
            PendulumBottomPos.Y = PendulumTopPos.Y + (float)Math.Cos(rad) * PendulumLength;

            PendulumRec = new Rectangle((int)PendulumBottomPos.X - 10, (int)PendulumBottomPos.Y + 50, 30, 30);

        }
    }

}
