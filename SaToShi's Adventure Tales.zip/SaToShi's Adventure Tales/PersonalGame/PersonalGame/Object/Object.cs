﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;
namespace PersonalGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Object : Microsoft.Xna.Framework.GameComponent
    {
        /// <summary>
        /// オブジェクトのテクスチャアニメ
        /// </summary>
        public AnimatedTexture2D animatedTexture;

        /// <summary>
        /// オブジェクトの名前
        /// </summary>
        public string Name
        {
            set { name =value;}
            get { return name; }
        }
        private string name;

        /// <summary>
        /// オブジェクトのα値
        /// </summary>
        public int Alpha
        {
            set { alpha = value; }
            get { return alpha; }
        }
        private int alpha;

        /// <summary>
        /// オブジェクトのポジション
        /// </summary>
        public Vector2 Position
        {
            set { position = value; }
            get { return position; }
        }
        private Vector2 position;

        public Object(Game game)
            : base(game)
        {
            // TODO: Construct any child components here
        }

        public override void Initialize()
        {
            //オブジェクトのポジション初期化
            position = new Vector2(-500,-500);
            alpha = 50;
            base.Initialize();
        }
        public override void Update(GameTime gameTime)
        {
            //テクスチャアニメショーンの更新処理
         
            animatedTexture.Update((float)gameTime.ElapsedGameTime.TotalSeconds);
            base.Update(gameTime);
        }

        #region メソッド
        public void ShowUp()
        {
            if(name=="teleportObj")
            {
                position = new Vector2(810, 180);
                if (alpha < 255)
                    alpha++;
            }
        }
        public void Disapear()
        {
            if (name == "teleportObj")
            {
                position = new Vector2(-500, -500);
            }
        }
        #endregion
    }
}
