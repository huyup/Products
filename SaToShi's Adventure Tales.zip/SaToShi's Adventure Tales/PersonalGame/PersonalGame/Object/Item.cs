using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace PersonalGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Item
    {
        public Texture2D itemWindowsImg;
        public Texture2D bannaImg;
        public Texture2D moneyImg;
        public Texture2D skateboardImg;

        /// <summary>
        /// �A�C�e���̖��O
        /// </summary>
        public String name;

        /// <summary>
        /// �A�C�e���̃|�W�V����
        /// </summary>
        public Vector2 position;

        /// <summary>
        /// �A�C�e���̃e�N�X�`��
        /// </summary>
        public Texture2D Img;

        public Item()
        {
        }
        public Item(string Name)
        {
            this.name = Name;
        }

    }
}
