﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;
public enum MOVERTYPE
{
    Type1,
    Type2,
    Type3,
    Type4,
}
namespace PersonalGame
{
    public class Mover
    {
        //床とのあたり判定
        public MOVERTYPE moverType;

        public Vector2 moverCenterPos;

        public float moverWidth = 192;

        public float mover_max_X;
        public float mover_max_Y;
        public float mover_min_Y;

        public void Initialize( )
        {
            if ( moverType == MOVERTYPE.Type1 )
            {
                mover_max_X = 100;
                mover_max_Y = 126;
                mover_min_Y = 125;
            }
            if ( moverType == MOVERTYPE.Type2 )
            {
                mover_max_X = 215;
                mover_max_Y = 136;
                mover_min_Y = 135;
            }
            if (moverType == MOVERTYPE.Type3)
            {
                mover_max_X = 100;
                mover_max_Y = 200;
                mover_min_Y = 150;
            }
            if (moverType == MOVERTYPE.Type4)
            {
                mover_max_X = 215;
                mover_max_Y = 160;
                mover_min_Y = 140;
            }
        }
    }
}
