using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;



namespace PersonalGame
{
    public enum Scene
    {
        Title,
        InGame_Scene1,
        InGame_Scene2,
        InGame_Scene3,
        End,
    }
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class MainScene : Microsoft.Xna.Framework.Game
    {

        #region �t�B�[���h
        public GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        ContentManager content;
        #region �V�[���R
        /// <summary>
        /// �e�X�g���[�h �p
        /// </summary>
        private bool testEnable = false;
        private Texture2D TestRecImg;
        private Rectangle TestRec;

        #region �V�[���̐؂�ւ�
        /// <summary>
        /// �V�[���̐؂�ւ������i��̐U�����������j
        /// </summary>
        //�V�[���Q���I���������
        private DateTime scene3StartTime = DateTime.MaxValue;

        /*�e�N�X�`��*/
        private Texture2D BlackImg;
        private Texture2D fangTopImg;
        private Texture2D fangBottomImg;

        /*�|�W�V����*/
        private Vector2 fangTopPos = new Vector2(300, 0);
        private Vector2 fangBottomPos = new Vector2(300, 400);

        /*�U���̑���*/
        private float fangPosAdd;
        #endregion

        #region �X�e�[�W
        /*�V�[���R�̔w�i*/
        private Texture2D sceen3BG;
        /*�{�X*/
        private Texture2D bossImg;

        /// <summary>
        /// ���[�v�~
        /// </summary>
        private Texture2D roopImg;
        /*�|�W�V����*/
        private Vector2 roopPos = new Vector2(500, 335);
        private float roopCircleRadius = 0;

        /// <summary>
        /// �󒆂̏�
        /// </summary>
        private Texture2D groundImg;
        private Texture2D setRopeImg;
        private Texture2D ropeImg;

        //�U��q
        private const int pendulumCount = 2;
        private Pendulum[] pendulum = new Pendulum[pendulumCount];

        //�󒆂̏�
        private const int moverCount = 3;
        private Mover[] mover = new Mover[moverCount];
        private Mover[] mover2 = new Mover[moverCount];
        #endregion

        //�T��
        private Monkey monkey;

        //����
        private Boss vampire;

        //���o��`�F�b�N
        private bool startFlag_Scene3;
        #endregion

        //���U���g
        private Texture2D resultImg_Win;
        private Texture2D resultImg_Lose;

        /// <summary>
        /// �V�[���̑I��ϐ�
        /// </summary>
        Scene whichScene;

        /// <summary>
        /// �E�B���h�E�Y�T�C�Y
        /// </summary>
        public const int windowsWidth = 1400;
        public const int windowsHeight = 900;

        /// <summary>
        /// �^�C�g���N���X
        /// </summary>
        private TitleScene titleScene;

        /// <summary>
        /// �Q�[���J�n�������ǂ������`�F�b�N����t���O
        /// </summary>
        private bool scene1StartEnable = false;
        private bool scene2StartEnable = false;

        /*�V�[���̏������t���O*/
        private bool scene2InitializeEnable = false;
        private bool scene3InitializeEnable = false;

        /// <summary>
        /// �w�i�}
        /// </summary>
        private Texture2D backgroundImg;
        private Texture2D backgroundImg2;


        /*�w�i�}�̕`��J�t���O*/
        private bool backgroundDrawEnable = false;
        private bool backgroundDrawEnable2 = false;
        /*�w�i���̕`��J�t���O*/
        private bool backgroundNameDrawEnable = true;
        private bool backgroundNameDrawEnable2 = false;
        /*�w�i�̓����x*/
        private int backgroundAlpha = 0;
        private int backgroundAlpha2 = 0;

        /// <summary>
        /// �w�i��
        /// </summary>
        private Object teleportObj;

        /// <summary>
        /// NPC
        /// </summary>
        private Npc santa;
        private Npc blackSanta;
        private Npc boss;

        /// <summary>
        /// �v���C���[
        /// </summary>
        private Player player;

        /// <summary>
        /// �A�C�e����
        /// </summary>
        private Item item;

        /// <summary>
        /// �V�[����bgm
        /// </summary>
        private Song scene1_bgm;
        private Song scene2_bgm;

        /// <summary>
        /// �V�[���Q�̑I��p�ϐ�
        /// </summary>
        /*�I�����̐F*/
        private Color selectedColor;
        private Color defaultColor;

        /*�I����������*/
        private bool rightSelected;
        private bool leftSelected;
        private int CheckItemCount = 0;

        /// <summary>
        /// �V�i���I
        /// </summary>
        private string scenarioLine1;
        private string scenarioLine2;
        private string scenarioLine3;
        private string scenarioLine4;
        private string scenarioLine5;
        private string scenarioLine6;
        private string scenarioLine7;
        private string scenarioLine8;

        /// <summary>
        /// �V�i���I�̃|�W�V�����A�s�̊Ԋu�A���l
        /// </summary>
        private int scenarioPosX = 550;
        private int scenarioPosY = -750;
        private int scenarioDiastance = 100;
        private int scenarioAlpha = 255;

        /*�V�i���I�X�L�b�v�J�t���O*/
        private bool scenarioSkipEnable = false;

        /// <summary>
        /// �t�H���g
        /// </summary>
        private SpriteFont scenarioFont;

        #endregion

        #region �R���X�g���N�^
        public MainScene()
        {
            graphics = new GraphicsDeviceManager(this);
            //�R���e���c�}�l�[�W�����擾
            content = new ContentManager(Services);

            //�E�B���h�E�Y�T�C�Y�̕ύX
            graphics.PreferredBackBufferWidth = windowsWidth;
            graphics.PreferredBackBufferHeight = windowsHeight;

            //�E�B���h�E�Y�^�C�g���̕ύX
            Window.Title = "���N�̖`���";

            Content.RootDirectory = "Content";
        }
        #endregion

        #region ������
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            //�C���v�b�g�}�l�[�W���N���X�̏�����
            InputManager.Initialize();

            if (!testEnable)
            {
                //�^�C�g���V�[���̃C���X�^���X����
                titleScene = new TitleScene(this);
                Components.Add(titleScene);

                //�V�[���̏�����
                whichScene = Scene.Title;

                //�F�̏�����
                defaultColor = Color.Azure;
                selectedColor = Color.Aqua;
            }
            else
            {
                whichScene = Scene.InGame_Scene3;
                scene3InitializeEnable = true;
            }

            //�V�i���I�̏�����
            scenarioLine8 = "  �l�����܂��̂�  ";
            scenarioLine7 = "    �����̎g����    ";
            scenarioLine6 = "  �ʂ������Ƃɂ���  ";
            scenarioLine5 = "   ������̎g����   ";
            scenarioLine4 = "  ������|�����Ƃ�  ";
            scenarioLine3 = "  ����̕��s���E��  ";
            scenarioLine2 = "������|���鑏�����";
            scenarioLine1 = " �����Ƃǂ����ɂ��� ";

            //�X�e�[�W�I�u�W�F�̏�����
            //�U��q 
            for (int i = 0; i < pendulumCount; i++)
            {
                pendulum[i] = new Pendulum();
            }
            pendulum[0].PendulumTopPos = new Vector2(260, 30);
            pendulum[1].PendulumTopPos = new Vector2(1140, 30);

            #region ��
            for (int i = 0; i < moverCount; i++)
            {
                mover[i] = new Mover();
            }
            mover[0].moverCenterPos = new Vector2(280, 645);
            mover[0].moverType = MOVERTYPE.Type1;
            mover[1].moverCenterPos = new Vector2(1100, 645);
            mover[1].moverType = MOVERTYPE.Type1;
            mover[2].moverCenterPos = new Vector2(685, 455);
            mover[2].moverType = MOVERTYPE.Type2;
            for (int i = 0; i < moverCount; i++)
            {
                mover[i].Initialize();
            }

            for (int i = 0; i < moverCount; i++)
            {
                mover2[i] = new Mover();
            }
            mover2[0].moverCenterPos = new Vector2(285, 800);
            mover2[0].moverType = MOVERTYPE.Type3;

            mover2[1].moverCenterPos = new Vector2(1100, 800);
            mover2[1].moverType = MOVERTYPE.Type3;

            mover2[2].moverCenterPos = new Vector2(685, 550);
            mover2[2].moverType = MOVERTYPE.Type4;
            for (int i = 0; i < moverCount; i++)
            {
                mover2[i].Initialize();
            }
            #endregion
            base.Initialize();
        }
        #endregion

        #region �ǂݍ���
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            #region �V�[���R�̃��\�[�X
            //�n�ʁ�����
            groundImg = Content.Load<Texture2D>(@"Scene3\Ground");

            //���[�v�~
            roopImg = Content.Load<Texture2D>(@"Scene3\Circle");
            //�U��q
            ropeImg = Content.Load<Texture2D>(@"Scene3\Rope");
            setRopeImg = Content.Load<Texture2D>(@"Scene3\SetRopeObj");
            //�{�X
            bossImg = Content.Load<Texture2D>(@"Scene3\Boss");
            //�V�[���؂�ւ��̉�}
            fangTopImg = Content.Load<Texture2D>(@"Scene3\Fang");
            fangBottomImg = Content.Load<Texture2D>(@"Scene3\Fang2");
            BlackImg = Content.Load<Texture2D>(@"Scene3\BlackGround");
            #endregion

            #region �A�C�e���N���X�̓ǂݍ��݁���������
            item = new Item();
            item.itemWindowsImg = Content.Load<Texture2D>(@"Item\ItemWindows");
            item.bannaImg = Content.Load<Texture2D>(@"Item\banna");
            item.moneyImg = Content.Load<Texture2D>(@"Item\money");
            item.skateboardImg = Content.Load<Texture2D>(@"Item\skateboard");

            #endregion

            #region �v���C���[�̓ǂݍ��݁���������
            player = new Player(this);
            player.Initialize();

            //�v���C���[�̃e�N�X�`���A�j���̓ǂݍ���
            player.animatedTexture = new AnimatedTexture2DSelectFrames(Content.Load<Texture2D>("player2"), 4, 3, 10, new int[] { 7, 8, 9, 8 });

            //�H�}�[�N�e�N�X�`��
            player.questionMarkImg = Content.Load<Texture2D>("QuestionMark");

            //�v���C���[�̑I���e�N�X�`��
            player.selectWindows = Content.Load<Texture2D>("SelectWindows");

            //�v���C���[�̏����A�C�e��
            player.item[0].name = "���N��";
            player.item[0].position = new Vector2(1300, 60);
            player.item[0].Img = item.moneyImg;

            //�����G�ɂ��Ă���
            player.animatedTexture.SetCurrentFrameNumber(8);

            #endregion

            #region Npc�̓ǂݍ��݁���������
            //�T���^
            santa = new Npc(this);

            santa.Name = "Santa";

            santa.Initialize();

            santa.animatedTexture = new AnimatedTexture2D(Content.Load<Texture2D>(@"Scene1\Santa"), 1, 3, 3);

            Components.Add(santa);
            //�u���b�N�T���^
            blackSanta = new Npc(this);

            blackSanta.Name = "BlackSanta";

            blackSanta.Initialize();

            blackSanta.animatedTexture = new AnimatedTexture2D(Content.Load<Texture2D>(@"Scene1\BlackSanta"), 1, 3, 3);

            Components.Add(blackSanta);
            //����
            boss = new Npc(this);

            boss.Name = "Boss";

            boss.Initialize();

            boss.Img = Content.Load<Texture2D>(@"Scene2\Boss");

            Components.Add(boss);
            #endregion

            #region �w�i���̓ǂݍ��݁���������
            teleportObj = new Object(this);

            teleportObj.Initialize();
            teleportObj.Name = "teleportObj";
            teleportObj.animatedTexture = new AnimatedTexture2D(Content.Load<Texture2D>(@"Scene1\TeleportObject"), 1, 10, 5);

            Components.Add(teleportObj);
            #endregion

            //���̏�����
            monkey = new Monkey(this, content);
            monkey.Initialize();
            Components.Add(monkey);

            //�����̏�����
            vampire = new Boss(this);
            vampire.Initialize();
            Components.Add(vampire);

            //�w�i�}�̓ǂݍ���
            backgroundImg = Content.Load<Texture2D>(@"Scene1\bg-sainokawara");
            backgroundImg2 = Content.Load<Texture2D>(@"Scene2\bg");
            sceen3BG = Content.Load<Texture2D>(@"Scene3\Bg");
            resultImg_Win = Content.Load<Texture2D>(@"Scene3\ResultImg_Win");
            resultImg_Lose = Content.Load<Texture2D>(@"Scene3\ResultImg_Lose");

            //bmg�̓ǂݍ���
            /*�V�[���P*/
            scene1_bgm = Content.Load<Song>(@"Scene1\Scene1_bgm");
            scene2_bgm = Content.Load<Song>(@"Scene2\Scene2_bgm");

            //�t�H���g�̓ǂݍ���
            scenarioFont = Content.Load<SpriteFont>("ScenarioFont");

            //�f�o�b�O���[�h
            TestRecImg = Content.Load<Texture2D>(@"Scene3\TESTRect");
            // TODO: use this.Content to load your game content here
        }
        #endregion

        #region �p��
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }
        #endregion

        #region �X�V
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || InputManager.IsKeyDown(Keys.Escape))
                this.Exit();

            // TODO: Add your update logic here

            #region �^�C�g�����
            if (whichScene == Scene.Title)
            {
                if (!testEnable)
                {
                    //�^�C�g���̕`��
                    whichScene = titleScene.SceneSelect();
                }
            }
            #endregion

            #region �Q�[�����
            #region �V�[���P
            if (whichScene == Scene.InGame_Scene1)
            {
                InputManager.Update();
                player.Update(gameTime);
                santa.Update(gameTime);
                blackSanta.Update(gameTime);
                teleportObj.Update(gameTime);
                //�ق��̃R���|�[�l���g�̍X�V���~�߂�
                vampire.Enabled = false;
                monkey.Enabled = false;
                #region �Q�[���J�n�܂ł̉��o
                //�P�|�V�i���I����
                if (scenarioPosY < 80)
                {
                    //�V�i���I�X�L�b�v�@�\
                    if (InputManager.IsKeyDown(Keys.X))
                    {
                        scenarioSkipEnable = true;
                    }
                    if (scenarioSkipEnable)
                    {
                        scenarioPosY = 100;
                        scenarioAlpha = 80;
                    }
                    scenarioPosY++;
                }
                else
                {
                    //�V�i���I�̃t�F�[�h�A�E�g
                    if (scenarioAlpha > 0)
                    {
                        scenarioAlpha--;
                    }
                    else if (scenarioAlpha <= 0)
                    {
                        //�Q�|�w�i�},Npc�̃t�F�[�h�C��
                        backgroundDrawEnable = true;
                    }
                }

                if (backgroundDrawEnable)
                {
                    if (backgroundAlpha < 255 && !player.isTeleport)
                    {
                        backgroundAlpha++;
                        if (backgroundAlpha > 50)
                        {
                            santa.ShowUp();
                            blackSanta.ShowUp();
                            teleportObj.ShowUp();
                        }
                    }
                    //�R�|�v���C���[�̓���A�V�[���P���J�n������
                    player.MoveIntoGame(ref scene1StartEnable, whichScene);

                }
                #endregion
                if (scene1StartEnable)
                {
                    backgroundNameDrawEnable = false;

                    //�Z���t�\���`�F�b�N
                    santa.CheckSelifShow();
                    blackSanta.CheckSelifShow();

                    //�T���^�ƑΘb������A�A�C�e�����Q�b�g
                    if (santa.showSelifWindows && player.getItem)
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            if (player.item[i].name == "��")
                            {
                                player.item[i].name = "�o�i�i";
                                player.item[i].position = new Vector2(1300, i * 60 + 60);
                                player.item[i].Img = item.bannaImg;
                                player.getItem = false;
                                break;
                            }
                        }
                    }

                    //�v���C���[�̈ړ�
                    player.PlayerMoveFunction();

                    //�v���C���[�̈ړ��͈͂��`�F�b�N
                    player.CheckMoveableEdge(windowsWidth - 100, windowsHeight);

                    ////Npc�Ƃ̐ڐG�`�F�b�N
                    //player.CheckEncounterNpc(santa.Name, item.bannaImg);

                    player.CheckRecEncounter(blackSanta.rectangle, ref blackSanta.hitAndEnter, blackSanta.Name, ref blackSanta.encounterCount);
                    player.CheckRecEncounter(santa.rectangle, ref santa.hitAndEnter, santa.Name, ref santa.encounterCount);

                    //bgm�Đ�
                    if (MediaPlayer.State != MediaState.Playing)
                        MediaPlayer.Play(scene1_bgm);

                    //�e���|�[�g�Ƃ̐ڐG�`�F�b�N
                    player.CheckTeleport();

                    //�e���|�[�g���́A�t�F�[�h�A�E�g�����Abgm���~�߂�
                    if (player.isTeleport)
                    {
                        santa.Disapear();
                        blackSanta.Disapear();
                        teleportObj.Disapear();
                        if (backgroundAlpha > 0)
                            backgroundAlpha -= 5;
                        if (player.Alpha <= -5)
                        {
                            player.Position = new Vector2(0, -1000);
                            MediaPlayer.Stop();
                        }
                        backgroundNameDrawEnable2 = true;
                    }
                    //�e���|�[�g���I�������A�V�[���Q�Ɉڂ�
                    if (backgroundAlpha <= 0)
                    {
                        whichScene = Scene.InGame_Scene2;
                        backgroundDrawEnable = false;
                        scene2InitializeEnable = true;
                    }
                }
            }
            #endregion

            #region �V�[���Q
            if (whichScene == Scene.InGame_Scene2)
            {
                InputManager.Update();
                player.Update(gameTime);
                //1-�V�[���Q�̊J�n��Value�̏����������p��
                if (scene2InitializeEnable)
                {
                    MediaPlayer.Play(scene2_bgm);

                    player.Disapear();
                    player.MovePlayerFlag = true;

                    santa.Dispose();
                    blackSanta.Dispose();
                    teleportObj.Dispose();

                    backgroundDrawEnable2 = true;
                    scene2InitializeEnable = false;
                }

                //�Q�|�w�i�}�̃t�F�[�h�C��
                if (backgroundDrawEnable2)
                {
                    if (backgroundAlpha2 < 255)
                    {

                        backgroundAlpha2++;
                        if (backgroundAlpha2 > 50)
                            boss.ShowUp();
                    }
                    else
                    {
                        //�R�|�v���C���[�̓���A�V�[��2���J�n������
                        player.MoveIntoGame(ref scene2StartEnable, whichScene);
                    }
                }
                if (scene2StartEnable)
                {
                    //�{�X�̃Z���t��\��������
                    boss.showSelifWindows = true;

                    if (boss.showSelifWindows)
                    {
                        #region �v���C���[�������ɑ΂���I����
                        if (InputManager.IsJustKeyDown(Keys.A))
                        {
                            leftSelected = true;
                            rightSelected = false;

                        }

                        if (InputManager.IsJustKeyDown(Keys.D))
                        {
                            leftSelected = false;
                            rightSelected = true;

                        }
                        if (InputManager.IsJustKeyDown(Keys.H))
                        {
                            if (leftSelected && !rightSelected)
                            {
                                for (int i = 0; i < 5; i++)
                                {

                                    if (player.item[i].name == "�o�i�i")
                                    {
                                        player.item[i].name = "��";
                                        player.item[i].Img = null;
                                        boss.yesSelected = true;
                                        boss.noSelected = false;
                                        boss.giveNoneSelected = false;
                                        scene3StartTime = DateTime.Now;
                                        break;
                                    }
                                    if (player.item[i].name != "�o�i�i")
                                    {
                                        CheckItemCount++;
                                    }
                                    if (CheckItemCount == 4)
                                    {
                                        boss.giveNoneSelected = true;
                                        boss.yesSelected = false;
                                        boss.noSelected = false;
                                        scene3StartTime = DateTime.Now;
                                    }
                                }
                            }
                            else if (rightSelected && !leftSelected)
                            {
                                boss.yesSelected = false;
                                boss.noSelected = true;
                                boss.giveNoneSelected = false;
                                scene3StartTime = DateTime.Now;
                            }
                        }
                        #endregion

                    }
                    //�I�����I�������A�Z���t�Q��1.5�b�\������
                    if ((DateTime.Now - scene3StartTime).TotalSeconds > 1.5)
                    {
                        boss.showSelifWindows = false;
                        boss.showSelifWindows2 = false;
                        //��̉摜��1.5�b�U�������A����������
                        if ((DateTime.Now - scene3StartTime).TotalSeconds < 3.0)
                        {
                            float fangTopPosMaxX = 310;
                            fangPosAdd = 5;
                            if (fangTopPos.X > fangTopPosMaxX)
                            {
                                fangPosAdd = -fangPosAdd;
                            }
                            fangTopPos.X += fangPosAdd;
                            fangBottomPos.X += fangPosAdd;

                        }
                        else
                        {
                            whichScene = Scene.InGame_Scene3;
                            scene3InitializeEnable = true;
                        }
                        fangPosAdd = 10;
                        if (fangTopPos.Y < 150)
                        {
                            fangTopPos.Y += fangPosAdd;
                        }
                        if (fangBottomPos.Y > 250)
                        {
                            fangBottomPos.Y -= fangPosAdd;
                        }
                        //
                    }
                }

            }
            #endregion

            #region �V�[���R
            if (whichScene == Scene.InGame_Scene3)
            {
                InputManager.Update();

                if (scene3InitializeEnable)
                {
                    monkey.Visible = true;
                    vampire.Visible = true;
                    vampire.Enabled = true;
                    monkey.Enabled = true;
                    for (int i = 0; i < player.item.GetLength(0); i++)
                    {
                        if (player.item[i].name == "�X�P�[�g�{�[�g")
                        {
                            monkey.haveSkateBoard = true;
                        }
                        if (player.item[i].name == "�o�i�i")
                        {
                            monkey.haveBananaBomb = true;
                        }
                    }
                    player.scale = 2.5f;
                    player.Position = new Vector2(0, 720);
                    scene3InitializeEnable = false;
                    //�{�X�Ƀv���C���[�̏���������
                    vampire.player = this.monkey;
                }
                if (!startFlag_Scene3)
                {

                    if (player.Position.X < 180)
                    {
                        player.Position += new Vector2(1, 0.3f);
                        player.scale -= 0.013f;
                    }
                    if (vampire.hpLength < 500)
                    {
                        vampire.hpLength += 3;
                    }
                    else
                    {
                        startFlag_Scene3 = true;
                        player.Alpha = 0;
                        monkey.monkeyImg = monkey.monkeyImg_Init;
                        monkey.battleStart = true;
                        vampire.battleStart = true;
                    }
                }
                if (startFlag_Scene3)
                {
                    //HACK:�������[�v�~�ɓ��������ǂ������`�F�b�N����t���O
                    monkey.CheckRoopCircle(roopPos, roopCircleRadius, roopImg.Width);

                    //��
                    monkey.CheckOnFloor(ref mover, moverCount);
                    monkey.CheckBananaOnFloor(ref mover2, moverCount);

                    //�U��q
                    for (int i = 0; i < pendulumCount; i++)
                    {
                        pendulum[i].UpdatePendulum();
                    }
                    monkey.CheckOnPendulum(ref pendulum, pendulumCount);

                    #region �ʏ���
                    if (!vampire.coreShowUpEnable)
                    {
                        //�{�X�̔�_���[�W����
                        vampire.CheckSwordDamage(monkey.swordRec, ref monkey.swordHitEnable, monkey.attackEnable);
                        vampire.CheckBombDamage(monkey.bananaBombRec, ref monkey.bananaBombHitEnable, monkey.bananaBombDrawEnable, monkey.useBananaBomb);
                        if (monkey.useSkateBoard)
                        {
                            vampire.CheckSkateBoardDamage(monkey.skateboardRec, ref monkey.skateBoardHitEnable, monkey.skateBoardBoost, monkey.useSkateBoard, monkey.inroopCircle);
                        }


                        //�v���C���[�ƃ{�X�̂����蔻��
                        if (vampire.alpha >= 255)
                        {
                            if (vampire.useChangeAttack || vampire.useChangeAttack2)
                            {
                                monkey.CheckHit(vampire.rectangle1, vampire.rectangle2, vampire.rectangle3, vampire.rectangle4);
                            }
                            if (!vampire.useChangeAttack2 && !vampire.useChangeAttack)
                            {
                                monkey.CheckHit(vampire.rectangle0, vampire.rectangle1, vampire.rectangle2, vampire.rectangle5);
                            }
                            //�啂̔�_���[�W����
                            for (int i = 0; i < vampire.bat2.GetLength(0); i++)
                            {
                                if (vampire.bat2[i].drawEnable)
                                {
                                    vampire.bat2[i].CheckSwordHit(monkey.swordRec, ref vampire.hpLength, ref monkey.swordHitEnable, monkey.attackEnable);
                                    vampire.bat2[i].CheckBombHit(monkey.bananaBombRec, ref vampire.hpLength, ref monkey.bananaBombHitEnable, monkey.bananaBombDrawEnable, monkey.useBananaBomb);
                                    vampire.bat2[i].CheckSkateBoardHit(monkey.skateboardRec, ref vampire.hpLength, ref monkey.skateBoardHitEnable, monkey.useSkateBoard, monkey.inroopCircle);
                                }
                            }
                        }
                        //�v���C���[�Ǝ艺�̂����蔻��
                        monkey.CheckHit(vampire.bat2);
                    }
                    #endregion

                    #region �R�A���
                    if (vampire.coreShowUpEnable)
                    {
                        //�{�X�̔�_���[�W����
                        vampire.CheckSwordDamage(monkey.swordRec, ref monkey.swordHitEnable, monkey.attackEnable);
                        vampire.CheckBombDamage(monkey.bananaBombRec, ref monkey.bananaBombHitEnable, monkey.bananaBombDrawEnable, monkey.useBananaBomb);
                        if (monkey.useSkateBoard)
                        {
                            vampire.CheckSkateBoardDamage(monkey.skateboardRec, ref monkey.skateBoardHitEnable, monkey.skateBoardBoost, monkey.useSkateBoard, monkey.inroopCircle);
                        }
                        //�啂̔�_���[�W����
                        for (int i = 0; i < vampire.bat.GetLength(0); i++)
                        {
                            if (vampire.bat[i].alpha > 200)
                            {
                                vampire.bat[i].CheckSwordHit(monkey.swordRec, ref vampire.hpLength, ref monkey.swordHitEnable, monkey.attackEnable);
                                vampire.bat[i].CheckBombHit(monkey.bananaBombRec, ref vampire.hpLength, ref monkey.bananaBombHitEnable, monkey.bananaBombDrawEnable, monkey.useBananaBomb);
                                vampire.bat[i].CheckSkateBoardHit(monkey.skateboardRec, ref vampire.hpLength, ref monkey.skateBoardHitEnable, monkey.useSkateBoard, monkey.inroopCircle);
                            }
                            vampire.bat[i].RevivalBat(vampire.bat[i].type);

                        }
                        //�v���C���[�ƃ{�X�̂����蔻��
                        monkey.CheckHit(vampire.coreRec);
                        //�v���C���[�Ǝ艺�̂����蔻��
                        monkey.CheckHit(vampire.bat);
                        //�v���C���[�ƃ��[�U�[�̂����蔻��
                        if (vampire.laserAttackEnable)
                        {
                            monkey.CircleLineCollisionFunction(vampire.laserPointSt, vampire.laserPointEd);
                            monkey.CheckHit(vampire.laserRec);
                        }
                    }
                    #endregion

                    //�v���C���[�̃A�C�e���Q�b�g�`�F�b�N
                    monkey.CheckItemGet(vampire.item_Rectangle, ref vampire.itemEnable);

                    if (monkey.hp <= 0 || vampire.coreHp <= 0)
                    {
                        whichScene = Scene.End;
                    }
                }
            }
            else
            {
                monkey.Visible = false;
                vampire.Visible = false;
            }
            #endregion
            if (whichScene == Scene.End)
            {
                InputManager.Update();
            }
            #endregion

            base.Update(gameTime);
        }
        #endregion

        #region �`�揈��
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            graphics.GraphicsDevice.BlendFactor = Color.Black;

            spriteBatch.Begin();
            #region �V�[���P�̕`��
            if (whichScene == Scene.InGame_Scene1)
            {
                #region �V�i���I�̕`��
                spriteBatch.DrawString(scenarioFont, scenarioLine1, new Vector2(scenarioPosX, scenarioPosY), new Color(scenarioAlpha, scenarioAlpha, scenarioAlpha, scenarioAlpha));
                spriteBatch.DrawString(scenarioFont, scenarioLine2, new Vector2(scenarioPosX, scenarioPosY + scenarioDiastance), new Color(scenarioAlpha, scenarioAlpha, scenarioAlpha, scenarioAlpha));
                spriteBatch.DrawString(scenarioFont, scenarioLine3, new Vector2(scenarioPosX, scenarioPosY + scenarioDiastance * 2), new Color(scenarioAlpha, scenarioAlpha, scenarioAlpha, scenarioAlpha));
                spriteBatch.DrawString(scenarioFont, scenarioLine4, new Vector2(scenarioPosX, scenarioPosY + scenarioDiastance * 3), new Color(scenarioAlpha, scenarioAlpha, scenarioAlpha, scenarioAlpha));
                spriteBatch.DrawString(scenarioFont, scenarioLine5, new Vector2(scenarioPosX, scenarioPosY + scenarioDiastance * 4), new Color(scenarioAlpha, scenarioAlpha, scenarioAlpha, scenarioAlpha));
                spriteBatch.DrawString(scenarioFont, scenarioLine6, new Vector2(scenarioPosX, scenarioPosY + scenarioDiastance * 5), new Color(scenarioAlpha, scenarioAlpha, scenarioAlpha, scenarioAlpha));
                spriteBatch.DrawString(scenarioFont, scenarioLine7, new Vector2(scenarioPosX, scenarioPosY + scenarioDiastance * 6), new Color(scenarioAlpha, scenarioAlpha, scenarioAlpha, scenarioAlpha));
                spriteBatch.DrawString(scenarioFont, scenarioLine8, new Vector2(scenarioPosX, scenarioPosY + scenarioDiastance * 7), new Color(scenarioAlpha, scenarioAlpha, scenarioAlpha, scenarioAlpha));

                if (!backgroundDrawEnable)
                    spriteBatch.DrawString(scenarioFont, "X�L�[�ŃX�L�b�v", new Vector2(1150, 850), Color.White);

                #endregion

                if (backgroundDrawEnable)
                {
                    //�w�i
                    if (backgroundNameDrawEnable)
                    {
                        spriteBatch.DrawString(scenarioFont, "������O", new Vector2(650, 100), Color.White);
                    }
                    spriteBatch.Draw(backgroundImg, new Rectangle(0, 0, 1300, 900), new Color(backgroundAlpha, backgroundAlpha, backgroundAlpha, backgroundAlpha));

                    //�A�C�e����
                    spriteBatch.Draw(item.itemWindowsImg, new Rectangle(1300, 0, 100, 900), Color.White);

                    //�w�i��
                    teleportObj.animatedTexture.DrawFrame(spriteBatch, teleportObj.Position, 0.8f, teleportObj.Alpha);

                    //npc
                    santa.animatedTexture.DrawFrame(spriteBatch, santa.Position, 2.1f, santa.Alpha);
                    blackSanta.animatedTexture.DrawFrame(spriteBatch, blackSanta.Position, 2.1f, blackSanta.Alpha);

                    //�v���C���[
                    player.animatedTexture.DrawFrame(spriteBatch, player.Position, 2.5f, player.Alpha);

                    #region ����������Ƃ��̕`�揈��
                    if (blackSanta.showSelifWindows)
                    {
                        spriteBatch.Draw(player.selectWindows, new Rectangle((int)player.Position.X - 150, (int)player.Position.Y - 100, 200, 120), new Color(255, 255, 255, 100));

                        player.LeftKeyEnable = false;
                        if (InputManager.IsJustKeyDown(Keys.A))
                        {
                            player.choiceSelection = ChoiceWhich.ChoiceLeft;
                        }
                        if (InputManager.IsJustKeyDown(Keys.D))
                        {
                            player.choiceSelection = ChoiceWhich.ChoiceRight;
                        }
                        if (player.choiceSelection == ChoiceWhich.Init)
                        {
                            //BUYSELECTIONS
                            if (InputManager.IsJustKeyDown(Keys.H))
                            {
                                player.buySelection = BUYSELECTIONS.Buy;
                                player.item[0].name = "�X�P�[�g�{�[�g";
                                player.item[0].position = new Vector2(1300, 60);
                                player.item[0].Img = item.skateboardImg;
                                blackSanta.showSelifWindows = false;
                            }
                            spriteBatch.DrawString(scenarioFont, "�����I", new Vector2(player.Position.X - 140, player.Position.Y - 70), Color.Black, MathHelper.ToRadians(0), Vector2.Zero, 1.1f, SpriteEffects.None, 0.0f);
                            spriteBatch.DrawString(scenarioFont, "����Ȃ�", new Vector2(player.Position.X - 40, player.Position.Y - 65), Color.Black, MathHelper.ToRadians(0), Vector2.Zero, 0.7f, SpriteEffects.None, 0.0f);
                        }
                        else if (player.choiceSelection == ChoiceWhich.ChoiceRight)
                        {
                            //noBUYSELECTIONS
                            if (InputManager.IsJustKeyDown(Keys.H))
                            {
                                player.buySelection = BUYSELECTIONS.NoToBuy;
                                blackSanta.selif2 = "�c�O";
                                blackSanta.showSelifWindows = false;
                            }
                            spriteBatch.DrawString(scenarioFont, "�����I", new Vector2(player.Position.X - 140, player.Position.Y - 65), Color.Black, MathHelper.ToRadians(0), Vector2.Zero, 0.7f, SpriteEffects.None, 0.0f);
                            spriteBatch.DrawString(scenarioFont, "����Ȃ�", new Vector2(player.Position.X - 68, player.Position.Y - 70), Color.Black, MathHelper.ToRadians(0), Vector2.Zero, 1.1f, SpriteEffects.None, 0.0f);
                        }
                        else if (player.choiceSelection == ChoiceWhich.ChoiceLeft)
                        {
                            //BUYSELECTIONS
                            if (InputManager.IsJustKeyDown(Keys.H))
                            {
                                player.buySelection = BUYSELECTIONS.Buy;
                                player.item[0].name = "�X�P�[�g�{�[�g";
                                player.item[0].position = new Vector2(1300, 60);
                                player.item[0].Img = item.skateboardImg;
                                blackSanta.showSelifWindows = false;
                            }
                            spriteBatch.DrawString(scenarioFont, "�����I", new Vector2(player.Position.X - 140, player.Position.Y - 70), Color.Black, MathHelper.ToRadians(0), Vector2.Zero, 1.1f, SpriteEffects.None, 0.0f);
                            spriteBatch.DrawString(scenarioFont, "����Ȃ�", new Vector2(player.Position.X - 40, player.Position.Y - 65), Color.Black, MathHelper.ToRadians(0), Vector2.Zero, 0.7f, SpriteEffects.None, 0.0f);
                        }


                    }
                    #endregion
                    //�A�C�e��
                    for (int i = 0; i < 5; i++)
                    {
                        if (player.item[i].name != "��")
                            spriteBatch.Draw(player.item[i].Img, new Rectangle((int)player.item[i].position.X, (int)player.item[i].position.Y, 100, 60), Color.White);
                    }

                    // spriteBatch.DrawString(scenarioFont, "Count" + Convert.ToString(player.encounterCount), new Vector2(400, 100), Color.Aqua);
                    //spriteBatch.DrawString(scenarioFont, "Rec" + Convert.ToString(blackSanta.rectangle), new Vector2(400, 150), Color.Aqua);
                    //spriteBatch.DrawString(scenarioFont, "Rec2" + Convert.ToString(santa.rectangle), new Vector2(400, 200), Color.Aqua);

                }
            }
            #endregion

            #region �V�[���Q�̕`��
            if (whichScene == Scene.InGame_Scene2)
            {
                if (backgroundNameDrawEnable2)
                {
                    spriteBatch.DrawString(scenarioFont, "������", new Vector2(600, 100), Color.White);
                }
                spriteBatch.Draw(backgroundImg2, new Rectangle(0, 0, 1300, 900), new Color(backgroundAlpha2, backgroundAlpha2, backgroundAlpha2, backgroundAlpha2));
                //�A�C�e����
                spriteBatch.Draw(item.itemWindowsImg, new Rectangle(1300, 0, 100, 900), Color.White);

                //�A�C�e��
                for (int i = 0; i < 5; i++)
                {
                    if (player.item[i].name != "��")
                        spriteBatch.Draw(player.item[i].Img, new Rectangle((int)player.item[i].position.X, (int)player.item[i].position.Y, 100, 60), Color.White);
                }

                //�v���C���[
                player.animatedTexture.DrawFrame(spriteBatch, player.Position, 2.5f, player.Alpha);

                //����
                spriteBatch.Draw(boss.Img, new Rectangle((int)boss.Position.X, (int)boss.Position.Y, 300, 150), new Color(boss.Alpha, boss.Alpha, boss.Alpha, boss.Alpha));

                //�v���C���[�̑I������
                if (boss.showSelifWindows)
                {
                    if (!rightSelected && !leftSelected)
                    {
                        spriteBatch.DrawString(scenarioFont, "������", new Vector2(450, 700), defaultColor);
                        spriteBatch.DrawString(scenarioFont, "�f��", new Vector2(810, 700), defaultColor);
                    }
                    else if (rightSelected && !leftSelected)
                    {
                        spriteBatch.DrawString(scenarioFont, "������", new Vector2(450, 700), defaultColor);
                        spriteBatch.DrawString(scenarioFont, "�f��", new Vector2(810, 700), selectedColor);
                    }
                    else if (!rightSelected && leftSelected)
                    {
                        spriteBatch.DrawString(scenarioFont, "������", new Vector2(450, 700), selectedColor);
                        spriteBatch.DrawString(scenarioFont, "�f��", new Vector2(810, 700), defaultColor);
                    }
                }

                //�V�[���̐؂�ւ�
                if ((DateTime.Now - scene3StartTime).TotalSeconds > 1.5)
                {
                    spriteBatch.Draw(BlackImg, Vector2.Zero, Color.Black);
                    spriteBatch.Draw(fangTopImg, fangTopPos, null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.0f, SpriteEffects.None, 0.0f);
                    spriteBatch.Draw(fangBottomImg, fangBottomPos, null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.0f, SpriteEffects.None, 0.0f);
                }
            }
            #endregion

            #region �V�[���R�̕`��
            if (whichScene == Scene.InGame_Scene3)
            {
                GraphicsDevice.Clear(Color.Black);

                //�w�i�}
                spriteBatch.Draw(sceen3BG, new Rectangle(0, 0, 1400, 900), Color.White);

                //��ɕ����Ă鏰
                spriteBatch.Draw(groundImg, new Rectangle(-100, 815, 1600, 100), Color.DarkGray);
                spriteBatch.Draw(groundImg, new Rectangle(180, 635, 200, 20), Color.White);
                spriteBatch.Draw(groundImg, new Rectangle(1000, 635, 200, 20), Color.White);

                //�v���C���[
                player.animatedTexture.DrawFrame(spriteBatch, player.Position, player.scale, player.Alpha);

                //�U��q
                spriteBatch.Draw(ropeImg, new Vector2(260, 30), null, Color.White, MathHelper.ToRadians(pendulum[0].PendulumAngle), new Vector2(0, 0), 1.3f, SpriteEffects.None, 0.0f);
                spriteBatch.Draw(setRopeImg, new Vector2(200, 00), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.3f, SpriteEffects.None, 0.0f);

                spriteBatch.Draw(ropeImg, new Vector2(1140, 30), null, Color.White, MathHelper.ToRadians(pendulum[1].PendulumAngle), new Vector2(0, 0), 1.3f, SpriteEffects.None, 0.0f);
                spriteBatch.Draw(setRopeImg, new Vector2(1080, 00), null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 1.3f, SpriteEffects.None, 0.0f);

                //���[�v�~
                spriteBatch.Draw(roopImg, roopPos, null, Color.White, MathHelper.ToRadians(0), Vector2.Zero, 2.0f, SpriteEffects.FlipHorizontally, 0.0f);


                if (!vampire.coreShowUpEnable)
                {
                    spriteBatch.DrawString(scenarioFont, "�z���S�̉�", new Vector2(350, 30), Color.IndianRed);
                }
                else
                {
                    spriteBatch.DrawString(scenarioFont, "�����o�i�i����", new Vector2(550, 30), Color.LightGoldenrodYellow);
                }
            }
            #endregion

            if (whichScene == Scene.End)
            {
                if (vampire.coreHp <= 0)
                {
                    spriteBatch.Draw(resultImg_Win, new Rectangle(0, 0, 1400, 900), Color.White);
                }
                if (monkey.hp <= 0)
                {
                    spriteBatch.Draw(resultImg_Lose, Vector2.Zero, Color.White);
                }
            }
            //�e�X�g���[�h�̕ϐ��\��
            if (testEnable)
            {
                //spriteBatch.DrawString(scenarioFont, "GetCurrentFrameNumber" + Convert.ToString(vampire.AnimatedImg_RaserAttack.GetCurrentFrameNumber()), new Vector2(200, 150), Color.Aqua);
                //spriteBatch.DrawString(scenarioFont, "core_BatAttackEnable" + Convert.ToString(vampire.core_BatAttackEnable), new Vector2(800, 200), Color.Aqua);
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
        #endregion
}