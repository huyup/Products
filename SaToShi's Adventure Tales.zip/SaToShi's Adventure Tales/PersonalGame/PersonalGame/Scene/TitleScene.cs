using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace PersonalGame
{
    enum MenuSelect
    {
        Start,
        Load,
        Exit,
    }
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class TitleScene : Microsoft.Xna.Framework.DrawableGameComponent
    {
        #region �t�B�[���h
        //�V�X�e���t�B�[���h
        private SpriteBatch spriteBatch;
        private ContentManager content;

        //���j���[�I����ԕϐ�
        private MenuSelect menuselect;
        
        //�w�i�}
        private Texture2D backgroundImg_Start;
        private Texture2D backgroundImg_Load;
        private Texture2D backgroundImg_Exit;

        //�^�C�g���̃��C��bgm
        private Song mainBgm;

        //�V�[���̑I��ϐ���
        private Scene scene=Scene.Title;

        //�I����Ԃ�se
        private SoundEffect se_select;

        private int alpha = 0;
        #endregion

        #region �R���X�g���N�^
        public TitleScene(Game game)
            : base(game)
        {
            content = new ContentManager(game.Services);
        }
        #endregion

        #region ������
        public override void Initialize()
        {
            //�C���v�b�g�}�l�[�W���N���X�̏�����
            InputManager.Initialize();

            //�ϐ��̏�����
            menuselect = MenuSelect.Start;

            base.Initialize();
        }
        #endregion

        #region �R���e���c�̓ǂݍ��ݏ���
        protected override void LoadContent()
        {
            // �V�K�� SpriteBatch ���쐬���܂��B����̓e�N�X�`���[�̕`��Ɏg�p�ł��܂��B
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //�e�N�X�`���̓ǂݍ���
            backgroundImg_Start = content.Load<Texture2D>(@"Content\Title\TitleBackgroundImg_Start");
            backgroundImg_Load = content.Load<Texture2D>(@"Content\Title\TitleBackgroundImg_Load");
            backgroundImg_Exit = content.Load<Texture2D>(@"Content\Title\TitleBackgroundImg_Exit");

            //�����̓ǂݍ���
            mainBgm = content.Load<Song>(@"Content\Title\TitleBgm");
            se_select = content.Load<SoundEffect>(@"Content\Title\TitleSe");


            base.LoadContent();
        }
        #endregion

        #region �R���e���c�̉������
        protected override void UnloadContent()
        {
            base.UnloadContent();
        }
        #endregion

        #region �Q�[���̍X�V����
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            InputManager.Update();

            //�^�C�g����bgm�Đ�
            if (MediaPlayer.State != MediaState.Playing)
                MediaPlayer.Play(mainBgm);


            if (InputManager.IsKeyDown(Keys.Escape))
                Game.Exit(); ;

            //�w�i�̃t�B�[�h�C��
            if (alpha <= 255)
                alpha = alpha + 1;
            
            //���j���[�I��
            if (InputManager.IsJustKeyDown(Keys.Down))
            {
                if(menuselect!=MenuSelect.Exit)
                    se_select.Play();
                if (menuselect == MenuSelect.Start)
                    menuselect = MenuSelect.Load;
                else if (menuselect == MenuSelect.Load)
                    menuselect = MenuSelect.Exit;
            }
            
            if (InputManager.IsJustKeyDown(Keys.Up))
            {
                if (menuselect != MenuSelect.Start)
                    se_select.Play();
                if (menuselect == MenuSelect.Exit)
                    menuselect = MenuSelect.Load;
                else if (menuselect == MenuSelect.Load)
                    menuselect = MenuSelect.Start;
            }
            /*�w�i���\�������܂őI�������Ȃ�*/
            //!test >120
            if (alpha > 0)
            {
                if (InputManager.IsJustKeyDown(Keys.Enter))
                {
                    if (menuselect == MenuSelect.Start)
                    {
                        this.Dispose();
                        this.scene = Scene.InGame_Scene1;
                        MediaPlayer.Stop();
                    }
                    if (menuselect == MenuSelect.Exit)
                        Game.Exit();
                }
            }
            base.Update(gameTime);
        }

        #endregion
 
        #region ���\�b�h
        public Scene SceneSelect()
        {
            return this.scene;
        }
        #endregion

        #region �Q�[���̕`�揈��
        public override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            
            spriteBatch.Begin();
            switch (menuselect)
            {
                case MenuSelect.Start:
                    spriteBatch.Draw(backgroundImg_Start, new Rectangle(0, 0, 1400, 900), new Color(alpha, alpha, alpha, alpha));
                    break;
                case MenuSelect.Load:
                    spriteBatch.Draw(backgroundImg_Load, new Rectangle(0, 0, 1400, 900), new Color(alpha, alpha, alpha, alpha));
                    break;
                case MenuSelect.Exit:
                    spriteBatch.Draw(backgroundImg_Exit, new Rectangle(0, 0, 1400, 900), new Color(alpha, alpha, alpha, alpha));
                    break;
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }
        #endregion
    }
}
