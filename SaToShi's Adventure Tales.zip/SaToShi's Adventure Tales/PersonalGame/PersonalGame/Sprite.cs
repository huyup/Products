﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace PersonalGame
{
    class Sprite
    {
        Texture2D m_texture;    // アニメーションを含んだ画像
        Vector2 m_position;     // 位置
        Point m_frameSize;      // １コマの大きさ
        Point m_currentFrame;   // 現在どのフレームかを表す
        Point m_sheetSize;      // アニメーションが縦横何コマあるか
        float m_timer;          // アニメーション用タイマー
        float m_updateInterval; // 何秒ごとに次のコマに進むか

        public Sprite(Texture2D tex, Vector2 pos, Point frameSize, Point sheetSize, float updateInterval)
        {
            m_timer = 0.0f;
            m_texture = tex;
            m_position = pos;
            m_frameSize = frameSize;
            m_currentFrame = new Point(0, 0);
            m_sheetSize = sheetSize;
            m_updateInterval = updateInterval;
        }

        public virtual void Update(float delta)
        {
            // タイマーを更新
            m_timer += delta;

            // もし次のコマに進む時間が過ぎたら
            if (m_timer > m_updateInterval)
            {
                // タイマーをリセット
                m_timer = 0.0f;

                // 右に１コマ進む
                m_currentFrame.X++;

                // もしX軸のコマ数が、画像にあるコマ数を超えていた場合
                if (m_currentFrame.X >= m_sheetSize.X)
                {

                    // 一番左のコマへ変更
                    m_currentFrame.X = 0;

                }
                if (m_currentFrame.Y >= m_sheetSize.Y)
                {

                    // 一番上の段に変更
                    m_currentFrame.Y = 0;
                }
            }
        }
        public virtual void Draw(SpriteBatch sp)
        {
            // 描画するコマを計算する
            Rectangle texRect = new Rectangle(m_currentFrame.X * m_frameSize.X,
            m_currentFrame.Y * m_frameSize.Y,
            m_frameSize.X,
            m_frameSize.Y);

            // 現在のコマを描画する
            sp.Draw(m_texture, m_position, texRect, Color.White,
            0.0f, Vector2.Zero, 1.5f, SpriteEffects.None, 0.0f);
        }
    }
}
