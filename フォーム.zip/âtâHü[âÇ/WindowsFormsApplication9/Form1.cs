﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.IO;
namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {
        public Form1 fm1;

        public bool delatePushed;

        public int deleteCount=0;

        public int count;
        public int upCount;
        public int downCount;

        public Form1()
        {
            InitializeComponent();

            //デフォルト
            button2.Enabled = true;
            button3.Enabled = true;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            //フォーム２の表示
            Form2 fm2 = new Form2();

            fm2.fm1 = this;

            fm2.ShowDialog();

        }
        //↑ボタン
        private void button2_Click(object sender, EventArgs e)
        {
            int idx = 0;
            if (listView1.SelectedItems.Count > 0)
            {
                idx = listView1.SelectedItems[0].Index;
                listView1.Items[idx - 1].Selected = true;

                string sub1;
                string sub2;
                string sub3;
                string sub4;
                string sub5;
                string sub6;

                sub1 = listView1.Items[idx-1].SubItems[1].Text;
                sub2 = listView1.Items[idx - 1].SubItems[2].Text;
                sub3 = listView1.Items[idx - 1].SubItems[3].Text;
                sub4 = listView1.Items[idx - 1].SubItems[4].Text;
                sub5 = listView1.Items[idx - 1].SubItems[5].Text;
                sub6 = listView1.Items[idx - 1].SubItems[6].Text;


                //ここに入れ替えの値を入れる
                listView1.Items[idx - 1].SubItems[1].Text = listView1.Items[idx].SubItems[1].Text;
                listView1.Items[idx - 1].SubItems[2].Text = listView1.Items[idx].SubItems[2].Text;
                listView1.Items[idx - 1].SubItems[3].Text = listView1.Items[idx].SubItems[3].Text;
                listView1.Items[idx - 1].SubItems[4].Text = listView1.Items[idx].SubItems[4].Text;
                listView1.Items[idx - 1].SubItems[5].Text = listView1.Items[idx].SubItems[5].Text;
                listView1.Items[idx - 1].SubItems[6].Text = listView1.Items[idx].SubItems[6].Text;

                listView1.Items[idx].SubItems[1].Text = sub1;
                listView1.Items[idx].SubItems[2].Text = sub2;
                listView1.Items[idx].SubItems[3].Text = sub3;
                listView1.Items[idx].SubItems[4].Text = sub4;
                listView1.Items[idx].SubItems[5].Text = sub5;
                listView1.Items[idx].SubItems[6].Text = sub6;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int idx = 0;
            if (listView1.SelectedItems.Count > 0)
            {
                idx = listView1.SelectedItems[0].Index;
                listView1.Items[idx + 1].Selected = true;

                string sub1;
                string sub2;
                string sub3;
                string sub4;
                string sub5;
                string sub6;

                sub1 = listView1.Items[idx+1].SubItems[1].Text;
                sub2 = listView1.Items[idx+1].SubItems[2].Text;
                sub3 = listView1.Items[idx+1].SubItems[3].Text;
                sub4 = listView1.Items[idx+1].SubItems[4].Text;
                sub5 = listView1.Items[idx+1].SubItems[5].Text;
                sub6 = listView1.Items[idx+1].SubItems[6].Text;


                //ここに入れ替えの値を入れる
                listView1.Items[idx+1].SubItems[1].Text = listView1.Items[idx].SubItems[1].Text;
                listView1.Items[idx+1].SubItems[2].Text = listView1.Items[idx].SubItems[2].Text;
                listView1.Items[idx+1].SubItems[3].Text = listView1.Items[idx].SubItems[3].Text;
                listView1.Items[idx+1].SubItems[4].Text = listView1.Items[idx].SubItems[4].Text;
                listView1.Items[idx+1].SubItems[5].Text = listView1.Items[idx].SubItems[5].Text;
                listView1.Items[idx+1].SubItems[6].Text = listView1.Items[idx].SubItems[6].Text;

                listView1.Items[idx].SubItems[1].Text = sub1;
                listView1.Items[idx].SubItems[2].Text = sub2;
                listView1.Items[idx].SubItems[3].Text = sub3;
                listView1.Items[idx].SubItems[4].Text = sub4;
                listView1.Items[idx].SubItems[5].Text = sub5;
                listView1.Items[idx].SubItems[6].Text = sub6;
            }
        }

        private void listView1_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            int idx = 0;
            if (listView1.SelectedItems.Count > 0)
            {
                idx = listView1.SelectedItems[0].Index;
                try
                {
                    listView1.Items[idx - 1].Checked = true;
                    button2.Enabled = true;
                }
                catch
                {
                    button2.Enabled = false;
                }
            }
            if (listView1.SelectedItems.Count > 0)
            {
                idx = listView1.SelectedItems[0].Index;
                try
                {
                    listView1.Items[idx + 1].Checked = true;
                    button3.Enabled = true;
                }
                catch
                {
                    button3.Enabled = false;
                }
            }
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Selected)
                {
                    textBox1.Text = listView1.Items[i].SubItems[1].Text;
                    textBox2.Text = listView1.Items[i].SubItems[2].Text;
                    textBox3.Text = listView1.Items[i].SubItems[3].Text;
                    textBox4.Text = listView1.Items[i].SubItems[4].Text;
                    textBox5.Text = listView1.Items[i].SubItems[5].Text;
                    textBox6.Text = listView1.Items[i].SubItems[6].Text;
                }
            }

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 開くOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XmlDocument r = new XmlDocument();

            //ファイル名指定で開く
            string fileName_Open;

            openFileDialog1.Filter = "C#(*.xml)|*.xml|" + "すべてのファイル(*.*)|*.*";


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileName_Open = openFileDialog1.FileName;

                listView1.Items.Clear();
            }
            else
            {
                return;
            }

            XElement doc_open = XElement.Load(fileName_Open);

            var dataElement = doc_open.Element("data");

            foreach (XElement mv in dataElement.Elements())
            {
                if (mv.Name == "BoudingBoxPosition")
                {
                    var number = mv.Attribute("番号");
                    var X1 = mv.Attribute("X1");
                    var Y1 = mv.Attribute("Y1");
                    var Z1 = mv.Attribute("Z1");
                    var X2 = mv.Attribute("X2");
                    var Y2 = mv.Attribute("Y2");
                    var Z2 = mv.Attribute("Z2");
                    int i = listView1.Items.Count;
                    ListViewItem itemx = new ListViewItem();

                    itemx.Text = Convert.ToString(number.Value);

                    itemx.SubItems.Add(X1.Value);
                    itemx.SubItems.Add(Y1.Value);
                    itemx.SubItems.Add(Z1.Value);
                    itemx.SubItems.Add(X2.Value);
                    itemx.SubItems.Add(Y2.Value);
                    itemx.SubItems.Add(Z2.Value);

                    Debug.WriteLine(X1.Value);

                    listView1.Items.Insert(i, itemx);
                }
            }
            MessageBox.Show("開く", "xml", MessageBoxButtons.OK);
        }

        private void 保存SToolStripMenuItem_Click(object sender, EventArgs e)
        {

            XDocument doc = new XDocument(
                     new XDeclaration("1.0", "utf-8", "yes"),
                     new XComment("This is a Comment"));

            //ファイル名指定で保存
            string fileName;

            saveFileDialog1.Filter = "C#(*.xml)|*.xml|" + "すべてのファイル(*.*)|*.*";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileName = saveFileDialog1.FileName;
            }
            else
            {
                return;
            }

            //TODO:ここにリストビューのアイテムを一個一個を追加していきます
            //Element project
            //Element name
            //Element title


            var project = new XElement("project");
            var nameElement = new XElement("name", "test_project");
            var titleElement = new XElement("title", "xmlwrite");

            var dataElement = new XElement("data");

            //Element data Attribute番号　AttributeX1 Attribute Y1 Attribute Z1 Attribute X2 Attribute Y2 Attribute Z2

            for (int i = 0; i < listView1.Items.Count; i++)
            {
                dataElement.Add(new XElement("BoudingBoxPosition",
                       new XAttribute("Z2", listView1.Items[i].SubItems[6].Text),
                       new XAttribute("Y2", listView1.Items[i].SubItems[5].Text),
                       new XAttribute("X2", listView1.Items[i].SubItems[4].Text),
                       new XAttribute("Z1", listView1.Items[i].SubItems[3].Text),
                       new XAttribute("Y1", listView1.Items[i].SubItems[2].Text),
                       new XAttribute("X1", listView1.Items[i].SubItems[1].Text),
                       new XAttribute("番号", listView1.Items[i].SubItems[0].Text)
                                 ));

            }

            project.Add(nameElement);
            project.Add(titleElement);
            project.Add(dataElement);

            doc.Add(project);

            doc.Save(fileName);

            MessageBox.Show("保存完了", "xml", MessageBoxButtons.OK);
        }

        private void 画像ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.form1 = this;
            form3.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;

            DialogResult result;

            if (listView1.Items.Count != 0)
            {
                result = MessageBox.Show("終了しますか", "確認ダイアログ", buttons);
            }
            else
            {
                return;
            }
            switch (result)
            {
                case DialogResult.No:
                    e.Cancel = true;
                    break;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Selected)
                {
                    //最後の一項が削除された場合
                    if (i == listView1.Items.Count - 1)
                    {
                        listView1.Items[i].Remove();
                    }
                    else
                    {
                        listView1.Items[i].Remove();
                        deleteCount++;
                        delatePushed = true;
                    }
                }
            }
            Debug.WriteLine(listView1.Items.Count);
        }

        public int IndexChangeFunction()
        {
            try
            {
                //最後の一項が削除された場合
                if (!delatePushed)
                {
                    if (listView1.Items.Count > 0)
                    {
                        Debug.WriteLine(listView1.Items[listView1.Items.Count - 1].Text);
                        return Convert.ToInt32(listView1.Items[listView1.Items.Count - 1].Text);
                    }
                    else
                    {
                        return listView1.Items.Count;
                    }
                }
                else
                {
                    if (listView1.Items.Count > 0)
                    {
                        Debug.WriteLine(listView1.Items[listView1.Items.Count - 1].Text);
                        return Convert.ToInt32(listView1.Items[listView1.Items.Count - 1].Text);
                    }
                    else
                    {
                        return listView1.Items.Count;
                    }
                }
            }
            catch
            {
                return listView1.Items.Count;
            }
        }

        private void 出力ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //ファイル名指定で保存
            string fileName;

            saveFileDialog2.Filter = "C#(*.cs)|*.cs|" + "すべてのファイル(*.*)|*.*";
            saveFileDialog2.FileName = "CollisionManager.cs";

            if (saveFileDialog2.ShowDialog() == DialogResult.OK)
            {
                fileName = saveFileDialog2.FileName;
            }
            else
            {
                return;
            }
            FileStream fs = new FileStream(fileName, FileMode.Create);

            StreamWriter textFile = new StreamWriter(fs);
            //TODO:ここにリストビューの項目をCollisionManager.csに入れる
            RuntimeTextTemplate1 tt = new RuntimeTextTemplate1();

            
            //ボックス数を指定
            tt.NumberOfBox = listView1.Items.Count;
            tt.boxes = new BoxData<float, float, float>(listView1.Items.Count);
            tt.boxesLength = new BoxLengthData<float, float, float>(listView1.Items.Count);

            //ボックスの中身を指定
            for(int i=0;i<tt.boxes.x.Length;i++)
            {
                //x1
                float x1=float.Parse(listView1.Items[i].SubItems[1].Text);
                //y1
                float y1=float.Parse(listView1.Items[i].SubItems[2].Text);
                //z1
                float z1=float.Parse(listView1.Items[i].SubItems[3].Text);
                //x2
                float x2=float.Parse(listView1.Items[i].SubItems[4].Text);
                //y2
                float y2=float.Parse(listView1.Items[i].SubItems[5].Text);
                //z2
                float z2=float.Parse(listView1.Items[i].SubItems[6].Text);


                //ここにセンターの座標を入れる
                tt.boxes.x[i] = (x2+x1)/2;
                tt.boxes.y[i] = -(y2+y1)/2;
                tt.boxes.z[i] = (z2+z1)/2;

                //ここにバウンディングボックスの辺の長さを入れる
                tt.boxesLength.x[i] = Math.Abs(x2 - x1);
                tt.boxesLength.y[i] = Math.Abs(y2 - y1);
                tt.boxesLength.z[i] = Math.Abs(z2 - z1);
            }


            //改造したテキスト
            string generatedText = tt.TransformText();

            //TODO:ここに改造したファイルを入れる
            textFile.Write(generatedText);

            textFile.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Selected)
                {
                    try
                    {
                        double x1;
                        double y1;
                        double z1;
                        double x2;
                        double y2;
                        double z2;
                        
                        x1 = Convert.ToDouble(textBox1.Text);
                        y1 = Convert.ToDouble(textBox2.Text);
                        z1 = Convert.ToDouble(textBox3.Text);
                        x2 = Convert.ToDouble(textBox4.Text);
                        y2 = Convert.ToDouble(textBox5.Text);
                        z2 = Convert.ToDouble(textBox6.Text);

                        listView1.Items[i].SubItems[1].Text = x1.ToString();
                        listView1.Items[i].SubItems[2].Text = y1.ToString();
                        listView1.Items[i].SubItems[3].Text = z1.ToString();
                        listView1.Items[i].SubItems[4].Text = x2.ToString();
                        listView1.Items[i].SubItems[5].Text = y2.ToString();
                        listView1.Items[i].SubItems[6].Text = z2.ToString();

                        errorProvider1.Clear();
                    }
                    catch
                    {
                        errorProvider1.SetError(label7, "数値のみです");
                    }
                }
            }

        }

        private void d画像ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

    }

    public class BoxData<T, U, W>
    {
        public T[] x;
        public U[] y;
        public W[] z;

        public BoxData(int i)
        {
            x = new T[i];
            y = new U[i];
            z = new W[i];
        }
    }

    public class BoxLengthData<T, U, W>
    {
        public T[] x;
        public U[] y;
        public W[] z;

        public BoxLengthData(int i)
        {
            x = new T[i];
            y = new U[i];
            z = new W[i];
        }
    }

    public partial class RuntimeTextTemplate1
    {
        public int NumberOfBox { set; get; }
        public BoxData<float, float, float> boxes;
        public BoxLengthData<float, float, float> boxesLength;
    }

}
