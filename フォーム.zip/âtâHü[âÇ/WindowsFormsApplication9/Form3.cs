﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
namespace WindowsFormsApplication9
{
    public partial class Form3 : Form
    {
        public Form1 form1;

        private bool drawFlag;
        private Point ptStart;
        private Point ptEnd;

        public Form3()
        {
            InitializeComponent();

            pictureBox2.BackColor = Color.Transparent;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label3.Text = "倍数: " + (0.5f + trackBar1.Value * 0.1f).ToString();

            comboBox1.Text = "すべての画像ファイル";
            comboBox1.Items.Add("*.*");
            comboBox1.Items.Add("*.bmp");
            comboBox1.Items.Add("*.png");
            comboBox1.Items.Add("*.jpg");
            comboBox1.Items.Add("*.gif");
            pictureBox2.Parent = pictureBox1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //名前.拡張子のパス
            if (folderBrowserDialog1.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            listBox1.Items.Clear();
            //ファイルの取得
            DirectoryInfo di = new DirectoryInfo(folderBrowserDialog1.SelectedPath);
            FileInfo[] files = di.GetFiles("*.*");

            foreach (FileInfo s in files)
            {
                listBox1.Items.Add(s.Name);
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Image = Image.FromFile(folderBrowserDialog1.SelectedPath + @"\" + listBox1.SelectedItem.ToString());

                label4.Text ="ImgHeight: "+pictureBox1.Image.Size.Height.ToString();
                label5.Text = "ImgWidth: " + pictureBox1.Image.Size.Width.ToString();

                float picW = pictureBox1.Width*(0.5f+trackBar1.Value*0.1f);
                float picH = pictureBox1.Height * (0.5f+trackBar1.Value*0.1f);

                Bitmap img = new Bitmap(pictureBox1.Image);
                int w = img.Width;
                int h = img.Height;

                float ratio = (float)picW / w;

                int nw = Convert.ToInt32(w * ratio);
                int nh = Convert.ToInt32(h * ratio);

                Bitmap bmp = new Bitmap(nw, nh);
                pictureBox1.Image = bmp;
                Graphics g = Graphics.FromImage(pictureBox1.Image);

                g.ScaleTransform(ratio, ratio);

                g.DrawImage(img, 0, 0, w, h);

                g.Dispose();
                img.Dispose();

                Graphics g2 = pictureBox1.CreateGraphics();

                g2.TranslateTransform(pictureBox1.Width / 2, pictureBox1.Height / 2);

                Pen blackPen = new Pen(Color.Black);
                blackPen.Width = 2;


                if (radioButton2.Checked)
                {
                    g2.DrawLine(Pens.Black, new Point(-50, 0), new Point(50, 0));
                    g2.DrawLine(Pens.Black, new Point(0, -50), new Point(0, 50));
                }
                if(radioButton1.Checked)
                {
                    g2.DrawLine(Pens.White, new Point(-50, 0), new Point(50, 0));
                    g2.DrawLine(Pens.White, new Point(0, -50), new Point(0, 50));
                }
                if (form1.listView1.Items.Count > 0)
                {
                    Debug.WriteLine(form1.listView1.Items.Count);
                    for (int i = 0; i < form1.listView1.Items.Count; i++)
                    {
                        int x1 = Convert.ToInt32(form1.listView1.Items[i].SubItems[1].Text);
                        int z1 = Convert.ToInt32(form1.listView1.Items[i].SubItems[3].Text);
                        int x2 = Convert.ToInt32(form1.listView1.Items[i].SubItems[4].Text);
                        int z2 = Convert.ToInt32(form1.listView1.Items[i].SubItems[6].Text);
                        int x;
                        int z;
                        if (x1 < x2 && z1 < z2)
                        {
                            x = x1;
                            z = z1;
                        }
                        else if (x2 < x1 && z2 < z1)
                        {
                            x = x2;
                            z = z2;
                        }
                        else
                        {
                            x = -1;
                            z = -1;
                        }

                        int width = Math.Abs(x2 - x1);
                        int height = Math.Abs(z2 - z1);
                        try
                        {
                            if (radioButton2.Checked)
                            {
                                g2.DrawRectangle(blackPen, x, z, width, height);
                            }
                            else
                            {
                                g2.DrawRectangle(Pens.White, x, z, width, height);
                            }
                        }
                        catch
                        {
                            Debug.WriteLine("不正なデータ");
                        }

                    }
                }
            }
            catch
            {
                MessageBox.Show("サポートされていないファイルです、もう一回選択してください");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedItem.ToString() == "*.png")
                {
                    listBox1.Items.Clear();

                    //ファイルの取得
                    DirectoryInfo di = new DirectoryInfo(folderBrowserDialog1.SelectedPath);
                    FileInfo[] files = di.GetFiles("*.png");

                    foreach (FileInfo s in files)
                    {
                        listBox1.Items.Add(s.Name);
                    }
                }

                if (comboBox1.SelectedItem.ToString() == "*.jpg")
                {
                    listBox1.Items.Clear();

                    //ファイルの取得
                    DirectoryInfo di = new DirectoryInfo(folderBrowserDialog1.SelectedPath);
                    FileInfo[] files = di.GetFiles("*.jpg");

                    foreach (FileInfo s in files)
                    {
                        listBox1.Items.Add(s.Name);
                    }
                }
                if (comboBox1.SelectedItem.ToString() == "*.bmp")
                {
                    listBox1.Items.Clear();

                    //ファイルの取得
                    DirectoryInfo di = new DirectoryInfo(folderBrowserDialog1.SelectedPath);
                    FileInfo[] files = di.GetFiles("*.bmp");

                    foreach (FileInfo s in files)
                    {
                        listBox1.Items.Add(s.Name);
                    }
                }
                if (comboBox1.SelectedItem.ToString() == "*.gif")
                {
                    listBox1.Items.Clear();

                    //ファイルの取得
                    DirectoryInfo di = new DirectoryInfo(folderBrowserDialog1.SelectedPath);
                    FileInfo[] files = di.GetFiles("*.gif");

                    foreach (FileInfo s in files)
                    {
                        listBox1.Items.Add(s.Name);
                    }
                }
                if (comboBox1.SelectedItem.ToString() == "*.*")
                {
                    listBox1.Items.Clear();

                    //ファイルの取得
                    DirectoryInfo di = new DirectoryInfo(folderBrowserDialog1.SelectedPath);
                    FileInfo[] files = di.GetFiles("*.*");

                    foreach (FileInfo s in files)
                    {
                        listBox1.Items.Add(s.Name);
                    }
                }
            }
            catch
            {
                MessageBox.Show("まずはパスを指定してください");
            }
        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.TranslateTransform((pictureBox2.Width / 2), pictureBox2.Height / 2);

            Pen blackPen = new Pen(Color.Black);
            blackPen.Width = 2;

            if (radioButton2.Checked)
            {
                e.Graphics.DrawLine(Pens.Black, new Point(-50, 0), new Point(50, 0));
                e.Graphics.DrawLine(Pens.Black, new Point(0, -50), new Point(0, 50));
            }
            if(radioButton1.Checked)
            {
                e.Graphics.DrawLine(Pens.White, new Point(-50, 0), new Point(50, 0));
                e.Graphics.DrawLine(Pens.White, new Point(0, -50), new Point(0, 50));
            }
            if (form1.listView1.Items.Count > 0)
            {
                Debug.WriteLine(form1.listView1.Items.Count);
                for (int i = 0; i < form1.listView1.Items.Count; i++)
                {
                    int x1 = Convert.ToInt32(form1.listView1.Items[i].SubItems[1].Text);
                    int z1 = Convert.ToInt32(form1.listView1.Items[i].SubItems[3].Text);
                    int x2 = Convert.ToInt32(form1.listView1.Items[i].SubItems[4].Text);
                    int z2 = Convert.ToInt32(form1.listView1.Items[i].SubItems[6].Text);
                    int x;
                    int z;
                    if (x1 < x2 && z1 < z2)
                    {
                        x = x1;
                        z = z1;
                    }
                    else if (x2 < x1 && z2 < z1)
                    {
                        x = x2;
                        z = z2;
                    }
                    else
                    {
                        x = -1;
                        z = -1;
                    }

                    float width = Math.Abs(x2 - x1);
                    float height = Math.Abs(z2 - z1);
                    try
                    {
                        if (radioButton2.Checked)
                        {
                            e.Graphics.DrawRectangle(blackPen, x, z, width, height);
                        }
                        if(radioButton1.Checked)
                        {
                            e.Graphics.DrawRectangle(Pens.White, x, z, width, height);
                        }
                    }
                    catch
                    {
                        Debug.WriteLine("不正なデータ");
                    }

                }
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            if (drawFlag == false)
            {
                ptStart.X = e.X;
                ptStart.Y = e.Y;

                drawFlag = true;

                ptEnd.X = -1;
                ptEnd.Y = -1;

            }
            else
            {

                if (ptEnd.X != -1)
                {
                    DrawRubberRectangle(ptStart, ptEnd);
                }

                if (e.Button == MouseButtons.Right)
                {
                    drawFlag = false;

                    return;
                }

                ptEnd.X = e.X;
                ptEnd.Y = e.Y;

                int x;

                if (ptStart.X < ptEnd.X)
                    x = ptStart.X;
                else
                    x = ptEnd.X;

                int y;

                if (ptStart.Y < ptEnd.Y)
                    y = ptStart.Y;
                else
                    y = ptEnd.Y;

                int w = Math.Abs(ptStart.X - ptEnd.X);
                int h = Math.Abs(ptStart.Y - ptEnd.Y);

                Graphics g = pictureBox2.CreateGraphics();
                g.DrawRectangle(Pens.Red, x, y, w, h);
                #region リストビューに正方形を追加
                //リストビューアイテムのインスタンス
                ListViewItem itemx = new ListViewItem();

                int i = form1.listView1.Items.Count;
                int index = form1.IndexChangeFunction();
                itemx.Text = Convert.ToString(index + 1);

                itemx.SubItems.Add(Convert.ToString(x-pictureBox2.Width/2));
                itemx.SubItems.Add(Convert.ToString(0));
                itemx.SubItems.Add(Convert.ToString(y-pictureBox2.Height/2));
                itemx.SubItems.Add(Convert.ToString((x - pictureBox2.Width / 2) + w));
                itemx.SubItems.Add(Convert.ToString(100));
                itemx.SubItems.Add(Convert.ToString((y - pictureBox2.Height / 2) + h));

                form1.listView1.Items.Insert(i, itemx);
                #endregion
                g.Dispose();

                drawFlag = false;


            }


        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            if (drawFlag == false)
            {
                return;
            }

            if (ptEnd.X != -1)
            {
                DrawRubberRectangle(ptStart, ptEnd);
            }

            ptEnd.X = e.X;
            ptEnd.Y = e.Y;

            DrawRubberRectangle(ptStart, ptEnd);
        }

        private void DrawRubberRectangle(Point pt1, Point pt2)
        {
            pt1 = pictureBox1.PointToScreen(pt1);
            pt2 = pictureBox1.PointToScreen(pt2);

            Rectangle rect = new Rectangle();

            if (pt1.X < pt2.X)
                rect.X = pt1.X;
            else
                rect.X = pt2.X;

            if (pt1.Y < pt2.Y)
                rect.Y = pt1.Y;
            else
                rect.Y = pt2.Y;

            rect.Width = Math.Abs(pt1.X - pt2.X);
            rect.Height = Math.Abs(pt1.Y - pt2.Y);

            ControlPaint.DrawReversibleFrame(rect, Color.White, FrameStyle.Dashed);

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label3.Text = "倍数: "+(0.5f + trackBar1.Value * 0.1f).ToString();
            try
            {
                pictureBox1.Image = Image.FromFile(folderBrowserDialog1.SelectedPath + @"\" + listBox1.SelectedItem.ToString());

                float picW = pictureBox1.Width * (0.5f + trackBar1.Value * 0.1f);
                float picH = pictureBox1.Height * (0.5f + trackBar1.Value * 0.1f);

                Bitmap img = new Bitmap(pictureBox1.Image);
                int w = img.Width;
                int h = img.Height;

                float ratio = (float)picW / w;

                int nw = Convert.ToInt32(w * ratio);
                int nh = Convert.ToInt32(h * ratio);

                Bitmap bmp = new Bitmap(nw, nh);
                pictureBox1.Image = bmp;
                Graphics g = Graphics.FromImage(pictureBox1.Image);

                g.ScaleTransform(ratio, ratio);

                g.DrawImage(img, 0, 0, w, h);

                g.Dispose();
                img.Dispose();

                Graphics g2 = pictureBox1.CreateGraphics();

                g2.TranslateTransform(pictureBox1.Width / 2, pictureBox1.Height / 2);

                Pen blackPen = new Pen(Color.Black);
                blackPen.Width = 2;

                g2.DrawLine(Pens.Black, new Point(-50, 0), new Point(50, 0));
                g2.DrawLine(Pens.Black, new Point(0, -50), new Point(0, 50));
                if (form1.listView1.Items.Count > 0)
                {
                    Debug.WriteLine(form1.listView1.Items.Count);
                    for (int i = 0; i < form1.listView1.Items.Count; i++)
                    {


                        int x1 = Convert.ToInt32(form1.listView1.Items[i].SubItems[1].Text);
                        int z1 = Convert.ToInt32(form1.listView1.Items[i].SubItems[3].Text);
                        int x2 = Convert.ToInt32(form1.listView1.Items[i].SubItems[4].Text);
                        int z2 = Convert.ToInt32(form1.listView1.Items[i].SubItems[6].Text);
                        int x;
                        int z;
                        if (x1 < x2 && z1 < z2)
                        {
                            x = x1;
                            z = z1;
                        }
                        else if (x2 < x1 && z2 < z1)
                        {
                            x = x2;
                            z = z2;
                        }
                        else
                        {
                            x = -1;
                            z = -1;
                        }

                        int width = Math.Abs(x2 - x1);
                        int height = Math.Abs(z2 - z1);
                        try
                        {
                            g2.DrawRectangle(blackPen, x, z, width, height);
                        }
                        catch
                        {
                            Debug.WriteLine("不正なデータ");
                        }

                    }
                }
            }
            catch
            {
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Graphics g2 = pictureBox2.CreateGraphics();

            g2.TranslateTransform(pictureBox2.Width / 2, pictureBox2.Height / 2);

            Pen blackPen = new Pen(Color.Black);
            blackPen.Width = 2;
            if (radioButton2.Checked)
            {
                g2.DrawLine(Pens.Black, new Point(-50, 0), new Point(50, 0));
                g2.DrawLine(Pens.Black, new Point(0, -50), new Point(0, 50));
            }
            if (radioButton1.Checked)
            {
                g2.DrawLine(Pens.White, new Point(-50, 0), new Point(50, 0));
                g2.DrawLine(Pens.White, new Point(0, -50), new Point(0, 50));
            }
            if (form1.listView1.Items.Count > 0)
            {
                Debug.WriteLine(form1.listView1.Items.Count);
                for (int i = 0; i < form1.listView1.Items.Count; i++)
                {


                    int x1 = Convert.ToInt32(form1.listView1.Items[i].SubItems[1].Text);
                    int z1 = Convert.ToInt32(form1.listView1.Items[i].SubItems[3].Text);
                    int x2 = Convert.ToInt32(form1.listView1.Items[i].SubItems[4].Text);
                    int z2 = Convert.ToInt32(form1.listView1.Items[i].SubItems[6].Text);
                    int x;
                    int z;
                    if (x1 < x2 && z1 < z2)
                    {
                        x = x1;
                        z = z1;
                    }
                    else if (x2 < x1 && z2 < z1)
                    {
                        x = x2;
                        z = z2;
                    }
                    else
                    {
                        x = -1;
                        z = -1;
                    }

                    int width = Math.Abs(x2 - x1);
                    int height = Math.Abs(z2 - z1);
                    try
                    {
                        if (radioButton2.Checked)
                        {
                            g2.DrawRectangle(blackPen, x, z, width, height);
                        }
                        else
                        {
                            g2.DrawRectangle(Pens.White, x, z, width, height);
                        }
                    }
                    catch
                    {
                        Debug.WriteLine("不正なデータ");
                    }

                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
