﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{

    public partial class Form2 : Form
    {
        public Form1 fm1;

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            String x1, y1, z1, x2, y2, z2;

            //デフォルト値
            x1 = Convert.ToString(100);
            y1 = Convert.ToString(0);
            z1 = Convert.ToString(-100);
            x2 = Convert.ToString(200);
            y2 = Convert.ToString(100);
            z2 = Convert.ToString(-200);

            textBox1.Text = x1;
            textBox2.Text = y1;
            textBox3.Text = z1;
            textBox4.Text = x2;
            textBox5.Text = y2;
            textBox6.Text = z2;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //リストビューアイテムのインスタンス
            ListViewItem itemx = new ListViewItem();

            int i = fm1.listView1.Items.Count;
            int y = fm1.IndexChangeFunction();
            itemx.Text = Convert.ToString(y+1);

            itemx.SubItems.Add(textBox1.Text);
            itemx.SubItems.Add(textBox2.Text);
            itemx.SubItems.Add(textBox3.Text);
            itemx.SubItems.Add(textBox4.Text);
            itemx.SubItems.Add(textBox5.Text);
            itemx.SubItems.Add(textBox6.Text);

            fm1.listView1.Items.Insert(i, itemx);

            fm1.listView1.Focus();
            fm1.listView1.Items[i].Selected = true;
            fm1.listView1.HideSelection = false;
            int idx = 0;
            if (fm1.listView1.Items.Count>0)
            {
                idx = fm1.listView1.SelectedItems[0].Index;
            }
            this.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TextBox target = sender as TextBox;
                Convert.ToDecimal(target.Text);
                button1.Enabled = true;
            }
            catch
            {
                button1.Enabled = false;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {


            try
            {
                TextBox target = sender as TextBox;
                Convert.ToDecimal(target.Text);
                button1.Enabled = true;
            }
            catch
            {
                button1.Enabled = false;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

            try
            {
                TextBox target = sender as TextBox;
                Convert.ToDecimal(target.Text);
                button1.Enabled = true;
            }
            catch
            {
                button1.Enabled = false;
            }

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

            try
            {
                TextBox target = sender as TextBox;
                Convert.ToDecimal(target.Text);
                button1.Enabled = true;
            }
            catch
            {
                button1.Enabled = false;
            }

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {


            try
            {
                TextBox target = sender as TextBox;
                Convert.ToDecimal(target.Text);
                button1.Enabled = true;
            }
            catch
            {
                button1.Enabled = false;
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TextBox target = sender as TextBox;
                Convert.ToDecimal(target.Text);
                button1.Enabled = true;
            }
            catch
            {
                button1.Enabled = false;
            }
        }

    }
}
